-- ============================================================
-- Shahin Travels - Hajj & Umrah Database Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS shahin_travels CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE shahin_travels;

-- Admin Users
CREATE TABLE IF NOT EXISTS admin_users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    last_login DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Categories
CREATE TABLE IF NOT EXISTS categories (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(120) NOT NULL UNIQUE,
    description TEXT,
    image VARCHAR(255),
    seo_title VARCHAR(200),
    seo_description TEXT,
    seo_og_image VARCHAR(255),
    noindex TINYINT(1) DEFAULT 0,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Hotels
CREATE TABLE IF NOT EXISTS hotels (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    city ENUM('Makkah','Madinah') NOT NULL,
    stars TINYINT DEFAULT 3,
    distance_haram INT COMMENT 'Distance from Haram in meters',
    description TEXT,
    amenities TEXT,
    image VARCHAR(255),
    gallery TEXT COMMENT 'JSON array of image paths',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Packages
CREATE TABLE IF NOT EXISTS packages (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    slug VARCHAR(220) NOT NULL UNIQUE,
    category_id INT UNSIGNED,
    departure_date DATE NOT NULL,
    return_date DATE NOT NULL,
    days INT NOT NULL,
    nights INT NOT NULL,
    departure_city VARCHAR(100) DEFAULT 'Delhi',
    airline VARCHAR(100),
    flight_details TEXT COMMENT 'JSON: departure/return flight info',
    makkah_hotel_id INT UNSIGNED,
    makkah_nights INT DEFAULT 0,
    madinah_hotel_id INT UNSIGNED,
    madinah_nights INT DEFAULT 0,
    short_description TEXT,
    overview TEXT,
    highlights TEXT COMMENT 'JSON array',
    inclusions TEXT COMMENT 'JSON array',
    exclusions TEXT COMMENT 'JSON array',
    important_info TEXT,
    cover_image VARCHAR(255),
    is_trending TINYINT(1) DEFAULT 0,
    status ENUM('published','draft') DEFAULT 'draft',
    seo_title VARCHAR(200),
    seo_description TEXT,
    seo_slug VARCHAR(220),
    og_title VARCHAR(200),
    og_description TEXT,
    og_image VARCHAR(255),
    noindex TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    FOREIGN KEY (makkah_hotel_id) REFERENCES hotels(id) ON DELETE SET NULL,
    FOREIGN KEY (madinah_hotel_id) REFERENCES hotels(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Package Prices
CREATE TABLE IF NOT EXISTS package_prices (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    package_id INT UNSIGNED NOT NULL,
    sharing_type ENUM('Quad','Triple','Double') NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (package_id) REFERENCES packages(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Package Itinerary
CREATE TABLE IF NOT EXISTS package_itinerary (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    package_id INT UNSIGNED NOT NULL,
    day_number INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    FOREIGN KEY (package_id) REFERENCES packages(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Package Images (Gallery)
CREATE TABLE IF NOT EXISTS package_images (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    package_id INT UNSIGNED NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    alt_text VARCHAR(200),
    sort_order INT DEFAULT 0,
    FOREIGN KEY (package_id) REFERENCES packages(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Blog Categories
CREATE TABLE IF NOT EXISTS blog_categories (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(120) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Blog Posts
CREATE TABLE IF NOT EXISTS blog_posts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(250) NOT NULL,
    slug VARCHAR(270) NOT NULL UNIQUE,
    category_id INT UNSIGNED,
    featured_image VARCHAR(255),
    excerpt TEXT,
    content LONGTEXT,
    author VARCHAR(100) DEFAULT 'Shahin Travels',
    status ENUM('published','draft') DEFAULT 'draft',
    published_at DATETIME,
    seo_title VARCHAR(200),
    seo_description TEXT,
    og_title VARCHAR(200),
    og_description TEXT,
    og_image VARCHAR(255),
    noindex TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES blog_categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Testimonials
CREATE TABLE IF NOT EXISTS testimonials (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    location VARCHAR(100),
    rating TINYINT DEFAULT 5,
    review TEXT NOT NULL,
    avatar VARCHAR(255),
    is_active TINYINT(1) DEFAULT 1,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Enquiries (Contact + Call Back)
CREATE TABLE IF NOT EXISTS enquiries (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    type ENUM('contact','callback','package') DEFAULT 'contact',
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(150),
    enquiry_type VARCHAR(100),
    preferred_month VARCHAR(50),
    message TEXT,
    package_id INT UNSIGNED NULL,
    status ENUM('new','done') DEFAULT 'new',
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (package_id) REFERENCES packages(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Static Pages
CREATE TABLE IF NOT EXISTS pages (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    page_key VARCHAR(50) NOT NULL UNIQUE COMMENT 'home, about, privacy, terms, cancellation',
    title VARCHAR(200),
    content LONGTEXT,
    seo_title VARCHAR(200),
    seo_description TEXT,
    og_title VARCHAR(200),
    og_description TEXT,
    og_image VARCHAR(255),
    noindex TINYINT(1) DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Settings
CREATE TABLE IF NOT EXISTS settings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `key` VARCHAR(100) NOT NULL UNIQUE,
    `value` TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 301 Redirects
CREATE TABLE IF NOT EXISTS redirects (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    from_url VARCHAR(500) NOT NULL,
    to_url VARCHAR(500) NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Media Library
CREATE TABLE IF NOT EXISTS media (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    filename VARCHAR(255) NOT NULL,
    original_name VARCHAR(255),
    file_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(50),
    file_size INT,
    alt_text VARCHAR(300),
    uploaded_by INT UNSIGNED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- Seed Data
-- ============================================================

-- Default admin user (password: Admin@123)
INSERT INTO admin_users (name, email, password) VALUES
('Super Admin', 'admin@shahin travels.in', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Categories
INSERT INTO categories (name, slug, description, sort_order) VALUES
('Budget', 'budget', 'Affordable Umrah packages with essential facilities', 1),
('Bronze', 'bronze', 'Better comfort and convenient stay', 2),
('Silver', 'silver', 'Premium hotels with great location', 3),
('Gold', 'gold', 'Best hotels, close to Haram with extra comfort', 4),
('Ramadan', 'ramadan', 'Special Ramadan Umrah packages', 5),
('Luxury', 'luxury', '5-star luxury Umrah experience', 6);

-- Hotels
INSERT INTO hotels (name, city, stars, distance_haram, description) VALUES
('Makkah Clock Royal Tower', 'Makkah', 5, 50, 'Iconic tower with direct view of Kaaba'),
('Dar Al Tawhid Intercontinental', 'Makkah', 5, 100, 'Premium hotel steps from Haram'),
('Al Safwah Royal Orchid', 'Makkah', 4, 200, 'Comfortable stay near Masjid Al Haram'),
('Hilton Suites Makkah', 'Makkah', 5, 150, 'Luxury suites with Haram views'),
('Al Ansar Grand Hotel', 'Makkah', 3, 350, 'Affordable hotel near Haram'),
('Anwar Al Madinah Movenpick', 'Madinah', 5, 30, 'Luxury hotel adjacent to Masjid Nabawi'),
('Pullman Zamzam Madinah', 'Madinah', 5, 50, 'Premium hotel with Nabawi views'),
('Al Shohada Hotel', 'Madinah', 4, 150, 'Comfortable hotel near Prophet\'s Mosque'),
('Al Eiman Royal Hotel', 'Madinah', 3, 300, 'Budget-friendly stay in Madinah');

-- Settings
INSERT INTO settings (`key`, `value`) VALUES
('site_name', 'Shahin Travels'),
('site_tagline', 'Your Trusted Partner for Hajj & Umrah'),
('logo', ''),
('favicon', ''),
('phone', '+91 99114 46919'),
('whatsapp', '919911446919'),
('email', 'info@shahintravels.in'),
('address', 'Shaheen Bagh, New Delhi - 110025'),
('office_hours', 'Mon-Sat: 10:00 AM – 8:00 PM | Sunday: Closed'),
('facebook', 'https://facebook.com/shahintravels'),
('instagram', 'https://instagram.com/shahintravels'),
('youtube', 'https://youtube.com/shahintravels'),
('google_analytics', ''),
('search_console', ''),
('wa_package_template', 'Assalamualaikum, I am interested in {package_name} (Departure {departure_date}, {price} per person, {sharing} Sharing). Please share more details.'),
('wa_general_template', 'Assalamualaikum, I would like to enquire about your Umrah packages. Please help me.'),
('wa_callback_template', 'Assalamualaikum, I would like a call back. My name is {name} and number is {phone}.'),
('footer_about', 'Shahin Travels is a Delhi-based travel agency providing reliable and affordable Hajj & Umrah services for pilgrims from India.'),
('hero_title', 'Your Spiritual Journey, <span>Our Commitment</span>'),
('hero_subtitle', 'Comfortable Packages | Premium Hotels | Direct Flights\nComplete Assistance from India'),
('hero_image', ''),
('meta_title_home', 'Shahin Travels – Hajj & Umrah Packages from India'),
('meta_desc_home', 'Book affordable and premium Umrah packages from India with direct flights, comfortable hotels near Haram, and complete assistance. Call +91 99114 46919.');

-- Static Pages
INSERT INTO pages (page_key, title, seo_title, seo_description) VALUES
('home', 'Home', 'Shahin Travels – Hajj & Umrah Packages from India', 'Book affordable Umrah packages from India with direct flights and hotels near Haram.'),
('about', 'About Us', 'About Shahin Travels – Trusted Hajj & Umrah Agency', 'Learn about Shahin Travels, your trusted Hajj & Umrah travel partner from India.'),
('privacy', 'Privacy Policy', 'Privacy Policy – Shahin Travels', 'Read our privacy policy for Shahin Travels Hajj & Umrah services.'),
('terms', 'Terms & Conditions', 'Terms & Conditions – Shahin Travels', 'Read our terms and conditions for booking Umrah packages with Shahin Travels.'),
('cancellation', 'Cancellation Policy', 'Cancellation Policy – Shahin Travels', 'Understand our cancellation and refund policy for Umrah package bookings.');

-- Sample Packages
INSERT INTO packages (title, slug, category_id, departure_date, return_date, days, nights, departure_city, airline, makkah_hotel_id, makkah_nights, madinah_hotel_id, madinah_nights, short_description, overview, status, is_trending, cover_image) VALUES
('12 Days Budget Umrah', '12-days-budget-umrah', 1, '2026-10-10', '2026-10-22', 12, 11, 'Delhi', 'Saudi Airlines', 5, 6, 9, 5, 'Affordable 12-day Umrah package with essential facilities', 'Experience a blessed Umrah journey with our affordable 12-day Budget package. Includes comfortable hotels near Haram, daily breakfast, and complete assistance.', 'published', 1, ''),
('14 Days Silver Umrah', '14-days-silver-umrah', 3, '2026-10-20', '2026-11-03', 14, 13, 'Delhi', 'Saudi Airlines', 3, 8, 8, 5, 'Premium 14-day Silver Umrah package with great hotels', 'Our 14-day Silver package offers premium hotels near Haram with daily breakfast and complete assistance for a spiritually fulfilling journey.', 'published', 1, ''),
('14 Days Gold Umrah', '14-days-gold-umrah', 4, '2026-10-20', '2026-11-03', 14, 13, 'Delhi', 'Saudi Airlines', 1, 8, 7, 5, 'Premium Gold Umrah package with 5-star hotels near Haram', 'Experience spiritual bliss with our 14 Days Gold Umrah Package. Stay in premium hotels near Haram with direct flights, comfortable transfers and complete assistance.', 'published', 1, ''),
('21 Days Ramadan Umrah', '21-days-ramadan-umrah', 5, '2027-01-01', '2027-01-22', 21, 20, 'Delhi', 'Saudi Airlines', 2, 14, 6, 6, 'Special 21-day Ramadan Umrah package', 'Perform Umrah in the blessed month of Ramadan with our premium 21-day package including 5-star hotels near Haram.', 'published', 1, ''),
('10 Days Budget Umrah Nov', '10-days-budget-umrah-nov', 1, '2026-11-05', '2026-11-15', 10, 9, 'Delhi', 'Saudi Airlines', 5, 5, 9, 4, 'Affordable 10-day November Umrah package', 'Budget-friendly Umrah package for November departures with comfortable stay near Haram.', 'published', 0, ''),
('15 Days Bronze Umrah Nov', '15-days-bronze-umrah-nov', 2, '2026-11-12', '2026-11-27', 15, 14, 'Delhi', 'Saudi Airlines', 3, 9, 8, 5, '15-day Bronze Umrah package with better comfort', 'Experience Umrah with better comfort and convenient stay with our 15-day Bronze package.', 'published', 0, ''),
('14 Days Gold Umrah Dec', '14-days-gold-umrah-dec', 4, '2026-12-15', '2026-12-29', 14, 13, 'Delhi', 'Saudi Airlines', 1, 8, 7, 5, 'December Gold Umrah package', 'Premium Gold Umrah package for December with 5-star hotels near Haram.', 'published', 0, ''),
('21 Days Silver Umrah Nov', '21-days-silver-umrah-nov', 3, '2026-11-10', '2026-12-01', 21, 20, 'Delhi', 'Saudi Airlines', 3, 14, 8, 6, '21-day Silver Umrah package November', 'Extended Silver Umrah package for a deeper spiritual experience.', 'published', 0, '');

-- Package Prices
INSERT INTO package_prices (package_id, sharing_type, price) VALUES
(1, 'Quad', 75786), (1, 'Triple', 85786), (1, 'Double', 99786),
(2, 'Quad', 110000), (2, 'Triple', 120000), (2, 'Double', 134786),
(3, 'Quad', 128000), (3, 'Triple', 136786), (3, 'Double', 146786),
(4, 'Quad', 165000), (4, 'Triple', 175000), (4, 'Double', 189786),
(5, 'Quad', 69500), (5, 'Triple', 79500), (5, 'Double', 89500),
(6, 'Quad', 99500), (6, 'Triple', 110000), (6, 'Double', 128500),
(7, 'Quad', 130000), (7, 'Triple', 140000), (7, 'Double', 158500),
(8, 'Quad', 115000), (8, 'Triple', 125000), (8, 'Double', 145000);

-- Testimonials
INSERT INTO testimonials (customer_name, location, rating, review) VALUES
('Abdul Faizan', 'Delhi, India', 5, 'Alhamdulillah, Shahin Travels made our Umrah journey beautiful. From hotel arrangements to local support, they were excellent. Highly recommended!'),
('Ayesha Khan', 'Faridabad, India', 5, 'Hotels were exactly as per the package arrangements. The staff was very supportive throughout our stay. Shahin Travels is truly professional.'),
('Imran Siddiqui', 'Meerut, India', 5, 'Shahin Travels is personally reliable. We had an amazing experience. Their arrangements were transparent and honest. Highly recommended for every pilgrim!');

-- Blog Categories
INSERT INTO blog_categories (name, slug) VALUES
('Umrah Guide', 'umrah-guide'),
('Travel Tips', 'travel-tips'),
('Hotels', 'hotels'),
('Visa Info', 'visa-info'),
('Ziyarat', 'ziyarat');

-- Blog Posts
INSERT INTO blog_posts (title, slug, category_id, excerpt, content, status, published_at, seo_title) VALUES
('Step by Step Guide for First Time Umrah Travellers', 'step-by-step-guide-first-time-umrah', 1, 'Planning your first Umrah? Read our complete step-by-step guide covering everything from visa to rituals.', '<p>Performing Umrah for the first time is a deeply spiritual experience. Here is everything you need to know...</p>', 'published', NOW(), 'First Time Umrah Guide – Shahin Travels'),
('What to Pack for Umrah – Complete Checklist', 'what-to-pack-for-umrah-complete-checklist', 2, 'Do not miss anything important for your Umrah journey. Our complete packing checklist covers everything you need.', '<p>Packing for Umrah requires careful planning. Here is our comprehensive checklist...</p>', 'published', NOW(), 'Umrah Packing Checklist – Shahin Travels'),
('Makkah and Madinah Hotel Guide – Which is Best?', 'makkah-madinah-hotel-guide', 3, 'Compare the best hotels in Makkah and Madinah near Haram. Find out which hotel suits your budget and needs.', '<p>Choosing the right hotel for your Umrah journey is crucial for a comfortable experience...</p>', 'published', NOW(), 'Best Hotels Near Haram – Shahin Travels'),
('Umrah Visa Process for Indian Travellers', 'umrah-visa-process-indian-travellers', 4, 'Complete guide to getting your Umrah visa from India. Documents required, process, and tips.', '<p>Getting an Umrah visa from India has become easier with the electronic visa system...</p>', 'published', NOW(), 'Umrah Visa from India – Shahin Travels');

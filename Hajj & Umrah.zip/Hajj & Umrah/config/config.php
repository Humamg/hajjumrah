<?php
define('SITE_URL', 'http://localhost/Hajj%20%26%20Umrah');
define('SITE_NAME', 'Shahin Travels');
define('UPLOAD_DIR', __DIR__ . '/../public/images/');
define('UPLOAD_URL', SITE_URL . '/public/images/');
define('ADMIN_EMAIL', 'admin@shahintr avels.in');
define('WHATSAPP_DEFAULT', '919911446919');

// Session start
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// CSRF Token
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_verify(): bool {
    $token = $_POST['csrf_token'] ?? '';
    return hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

// Sanitize output
function e(string $str): string {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

// Slugify
function slugify(string $text): string {
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9\-]/', '-', $text);
    $text = preg_replace('/-+/', '-', $text);
    return trim($text, '-');
}

// Format Indian currency
function formatINR(float $amount): string {
    return '₹' . number_format($amount, 0, '.', ',');
}

// WhatsApp URL builder
function waUrl(string $number, string $message): string {
    return 'https://wa.me/' . preg_replace('/\D/', '', $number) . '?text=' . rawurlencode($message);
}

// Redirect
function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}

// Flash messages
function setFlash(string $type, string $msg): void {
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}

function getFlash(): ?array {
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

// Get setting from DB
function getSetting(string $key, string $default = ''): string {
    static $settings = null;
    if ($settings === null) {
        try {
            $db = getDB();
            $stmt = $db->query("SELECT `key`, `value` FROM settings");
            $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        } catch (Exception $e) {
            $settings = [];
        }
    }
    return $settings[$key] ?? $default;
}

// Set setting in DB
function setSetting(string $key, string $value): bool {
    try {
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)");
        return $stmt->execute([$key, $value]);
    } catch (Exception $e) {
        return false;
    }
}

// Secure file upload helper
function handleUpload(array $file, string $subfolder = 'general'): array {
    $allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    $allowedExts  = ['jpg', 'jpeg', 'png', 'webp', 'gif'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'error' => 'File upload error code: ' . $file['error']];
    }

    if ($file['size'] > 5 * 1024 * 1024) { // 5MB limit
        return ['success' => false, 'error' => 'File size exceeds 5MB limit.'];
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime, $allowedTypes)) {
        return ['success' => false, 'error' => 'Invalid file type. Only JPG, PNG, WEBP, and GIF allowed.'];
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExts)) {
        return ['success' => false, 'error' => 'Invalid file extension.'];
    }

    $targetDir = UPLOAD_DIR . $subfolder . '/';
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }

    $newFilename = $subfolder . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $targetPath  = $targetDir . $newFilename;

    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        return ['success' => true, 'filename' => $subfolder . '/' . $newFilename, 'path' => $targetPath];
    }

    return ['success' => false, 'error' => 'Failed to move uploaded file. Check directory permissions.'];
}

// 301 Redirect handler
function checkRedirects(): void {
    if (php_sapi_name() === 'cli') return;
    try {
        $db = getDB();
        $requestUri = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
        // Normalize
        $base = '/Hajj%20%26%20Umrah';
        $relative = str_replace($base, '', $requestUri);
        if ($relative === '') $relative = '/';

        $stmt = $db->prepare("SELECT to_url FROM redirects WHERE (from_url = ? OR from_url = ?) AND is_active = 1 LIMIT 1");
        $stmt->execute([$relative, rtrim($relative, '/')]);
        $to = $stmt->fetchColumn();
        if ($to) {
            header("HTTP/1.1 301 Moved Permanently");
            header("Location: " . (strpos($to, 'http') === 0 ? $to : SITE_URL . '/' . ltrim($to, '/')));
            exit;
        }
    } catch (Exception $e) {}
}

// Check 301 redirects immediately on non-admin routes
if (strpos($_SERVER['REQUEST_URI'] ?? '', '/admin') === false) {
    checkRedirects();
}

// Image lazy load helper
function lazyImg(string $src, string $alt, string $class = ''): string {
    $src = e($src);
    $alt = e($alt);
    $class = $class ? ' class="' . e($class) . '"' : '';
    return '<img src="data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=" data-src="' . $src . '" alt="' . $alt . '" loading="lazy"' . $class . '>';
}


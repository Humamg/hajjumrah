<?php
// Header template
// Variables expected: $pageTitle, $metaDesc, $ogTitle, $ogDesc, $ogImage, $canonicalUrl, $bodyClass, $schema, $noindex
$siteName   = getSetting('site_name', 'Shahin Travels');
$siteTagline = getSetting('site_tagline', 'Hajj & Umrah Specialists');
$phone      = getSetting('phone', '+91 99114 46919');
$waNumber   = getSetting('whatsapp', '919911446919');
$waTemplate = getSetting('wa_general_template', 'Assalamualaikum, I would like to enquire about Umrah packages.');
$waUrl      = waUrl($waNumber, $waTemplate);
$logoPath   = getSetting('logo', '');
$gaCode     = getSetting('google_analytics', '');
$canonical  = $canonicalUrl ?? (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle ?? $siteName) ?></title>
    <meta name="description" content="<?= e($metaDesc ?? getSetting('meta_desc_home')) ?>">
    <?php if (!empty($noindex)): ?>
        <meta name="robots" content="noindex,nofollow"><?php else: ?>
        <meta name="robots" content="index,follow"><?php endif; ?>
    <link rel="canonical" href="<?= e($canonical) ?>">
    <!-- Open Graph -->
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?= e($ogTitle ?? $pageTitle ?? $siteName) ?>">
    <meta property="og:description" content="<?= e($ogDesc ?? $metaDesc ?? '') ?>">
    <meta property="og:url" content="<?= e($canonical) ?>">
    <meta property="og:image" content="<?= e($ogImage ?? SITE_URL . '/public/images/general/og-default.jpg') ?>">
    <meta property="og:site_name" content="<?= e($siteName) ?>">
    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= e($ogTitle ?? $pageTitle ?? $siteName) ?>">
    <meta name="twitter:description" content="<?= e($ogDesc ?? $metaDesc ?? '') ?>">
    <meta name="twitter:image" content="<?= e($ogImage ?? SITE_URL . '/public/images/general/og-default.jpg') ?>">
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?= SITE_URL ?>/public/images/general/favicon.ico">
    <!-- CSS -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="<?= SITE_URL ?>/public/css/style.css">
    <!-- Schema -->
    <?php if (!empty($schema)): ?>
        <script type="application/ld+json">
            <?= $schema ?>
        </script>
    <?php endif; ?>
    <!-- Organization Schema -->
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "TravelAgency",
            "name": "<?= e($siteName) ?>",
            "url": "<?= SITE_URL ?>",
            "logo": "<?= SITE_URL ?>/public/images/general/logo.png",
            "telephone": "<?= e($phone) ?>",
            "email": "<?= e(getSetting('email')) ?>",
            "address": {
                "@type": "PostalAddress",
                "streetAddress": "<?= e(getSetting('address')) ?>",
                "addressCountry": "IN"
            },
            "sameAs": [
                "<?= e(getSetting('facebook')) ?>",
                "<?= e(getSetting('instagram')) ?>"
            ]
        }
    </script>
    <?php if ($gaCode): ?><script async src="https://www.googletagmanager.com/gtag/js?id=<?= e($gaCode) ?>"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }
            gtag('js', new Date());
            gtag('config', '<?= e($gaCode) ?>');
        </script><?php endif; ?>
</head>

<body class="<?= e($bodyClass ?? '') ?>">

    <!-- Floating WhatsApp -->
    <a href="<?= e($waUrl) ?>" class="floating-wa" target="_blank" rel="noopener" aria-label="Chat on WhatsApp" title="Chat with us on WhatsApp">
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
        </svg>
    </a>

    <!-- Mobile Nav Overlay -->
    <div class="nav-overlay" aria-hidden="true"></div>

    <!-- Site Header -->
    <header class="site-header" id="site-header">
        <!-- Top Bar -->
        <!-- Main Header -->
        <div class="header-main">
            <div class="container">
                <!-- Logo -->
                <a href="<?= SITE_URL ?>/" class="logo">
                    <?php if ($logoPath): ?>
                        <img src="<?= e(SITE_URL . '/public/images/' . $logoPath) ?>" alt="<?= e($siteName) ?> Logo" width="50" height="50">
                    <?php else: ?>
                        <div style="width:46px;height:46px;background:var(--gold);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.5rem;">🕌</div>
                    <?php endif; ?>
                    <div class="logo-text">
                        <span class="name"><?= e($siteName) ?></span>
                        <span class="tagline"><?= e($siteTagline) ?></span>
                    </div>
                </a>
                <!-- Navigation -->
                <nav class="main-nav" id="main-nav" role="navigation" aria-label="Main Navigation">
                    <a href="<?= SITE_URL ?>/" <?= (($_SERVER['REQUEST_URI'] === '/' || $_SERVER['REQUEST_URI'] === '/index.php') ? 'class="active"' : '') ?>>Home</a>
                    <a href="<?= SITE_URL ?>/umrah-packages" <?= (strpos($_SERVER['REQUEST_URI'], '/umrah-packages') === 0 ? 'class="active"' : '') ?>>Umrah Packages</a>
                    <a href="<?= SITE_URL ?>/umrah-packages/month/<?= date('F-Y') ?>" <?= (strpos($_SERVER['REQUEST_URI'], '/umrah-packages/month/') === 0 ? 'class="active"' : '') ?>>By Month</a>
                    <a href="<?= SITE_URL ?>/umrah-packages/category/gold" <?= (strpos($_SERVER['REQUEST_URI'], '/umrah-packages/category/') === 0 ? 'class="active"' : '') ?>>By Category</a>
                    <a href="<?= SITE_URL ?>/blog" <?= (strpos($_SERVER['REQUEST_URI'], '/blog') === 0 ? 'class="active"' : '') ?>>Blog</a>
                    <a href="<?= SITE_URL ?>/about-us" <?= ($_SERVER['REQUEST_URI'] === '/about-us' ? 'class="active"' : '') ?>>About Us</a>
                    <a href="<?= SITE_URL ?>/contact-us" <?= ($_SERVER['REQUEST_URI'] === '/contact-us' ? 'class="active"' : '') ?>>Contact Us</a>
                </nav>
                <!-- Actions -->
                <div class="header-actions">
                    <a href="<?= e($waUrl) ?>" class="header-wa-btn" target="_blank" rel="noopener" aria-label="Chat on WhatsApp">
                        <svg viewBox="0 0 24 24" fill="currentColor">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                        </svg>
                        <?= e($phone) ?>
                    </a>
                    <button class="hamburger" id="hamburger-btn" aria-label="Toggle menu" aria-expanded="false">
                        <span></span><span></span><span></span>
                    </button>
                </div>
            </div>
        </div>
    </header>

    <div class="page-content">
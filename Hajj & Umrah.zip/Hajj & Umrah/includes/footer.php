<?php
// Footer template
$siteName = getSetting('site_name', 'Shahin Travels');
$phone    = getSetting('phone', '+91 99114 46919');
$email    = getSetting('email', 'info@shahintravels.in');
$address  = getSetting('address', 'Shaheen Bagh, New Delhi - 110025');
$hours    = getSetting('office_hours', 'Mon-Sat: 10:00 AM – 8:00 PM | Sunday: Closed');
$waNumber = getSetting('whatsapp', '919911446919');
$waMsg    = getSetting('wa_general_template', 'Assalamualaikum, I would like to enquire about Umrah packages.');
$waUrl    = waUrl($waNumber, $waMsg);
$about    = getSetting('footer_about', 'Shahin Travels is your trusted Hajj & Umrah partner from India.');
?>
</div><!-- .page-content -->

<!-- CTA Banner (Shared) -->
<section class="cta-banner">
    <div class="container">
        <h2 class="fade-up">Ready for Your Umrah Journey?</h2>
        <p class="fade-up">Get the best packages, hotel options and complete guidance from our team.</p>
        <div class="cta-actions fade-up">
            <a href="<?= e($waUrl) ?>" class="btn btn-wa btn-lg btn-wa-pulse" target="_blank" rel="noopener">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                Chat on WhatsApp
            </a>
            <a href="tel:<?= preg_replace('/\D/', '', $phone) ?>" class="btn btn-outline btn-lg">
                📞 <?= e($phone) ?>
            </a>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="site-footer">
    <div class="footer-main">
        <div class="container">
            <div class="footer-grid">
                <!-- Brand -->
                <div class="footer-brand">
                    <a href="<?= SITE_URL ?>/" class="logo" style="margin-bottom:14px;">
                        <div style="width:42px;height:42px;background:var(--gold);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1.4rem;">🕌</div>
                        <div class="logo-text">
                            <span class="name"><?= e($siteName) ?></span>
                            <span class="tagline">Hajj & Umrah Specialists</span>
                        </div>
                    </a>
                    <p><?= e($about) ?></p>
                    <div class="footer-social">
                        <?php if ($fb = getSetting('facebook')): ?>
                        <a href="<?= e($fb) ?>" target="_blank" rel="noopener" aria-label="Facebook">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg>
                        </a>
                        <?php endif; ?>
                        <?php if ($ig = getSetting('instagram')): ?>
                        <a href="<?= e($ig) ?>" target="_blank" rel="noopener" aria-label="Instagram">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5"/><path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
                        </a>
                        <?php endif; ?>
                        <?php if ($yt = getSetting('youtube')): ?>
                        <a href="<?= e($yt) ?>" target="_blank" rel="noopener" aria-label="YouTube">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M22.54 6.42a2.78 2.78 0 00-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46A2.78 2.78 0 001.46 6.42 29 29 0 001 12a29 29 0 00.46 5.58A2.78 2.78 0 003.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 001.95-1.95A29 29 0 0023 12a29 29 0 00-.46-5.58zM9.75 15.02V8.98L15.5 12l-5.75 3.02z"/></svg>
                        </a>
                        <?php endif; ?>
                        <a href="<?= e($waUrl) ?>" target="_blank" rel="noopener" aria-label="WhatsApp">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                        </a>
                    </div>
                </div>

                <!-- Quick Links -->
                <div class="footer-col">
                    <h4>Quick Links</h4>
                    <div class="footer-links">
                        <a href="<?= SITE_URL ?>/">Home</a>
                        <a href="<?= SITE_URL ?>/umrah-packages">Umrah Packages</a>
                        <a href="<?= SITE_URL ?>/umrah-packages/category/budget">Budget Packages</a>
                        <a href="<?= SITE_URL ?>/umrah-packages/category/gold">Gold Packages</a>
                        <a href="<?= SITE_URL ?>/blog">Blog</a>
                        <a href="<?= SITE_URL ?>/about-us">About Us</a>
                        <a href="<?= SITE_URL ?>/contact-us">Contact Us</a>
                    </div>
                </div>

                <!-- Our Services -->
                <div class="footer-col">
                    <h4>Our Services</h4>
                    <div class="footer-links">
                        <a href="<?= SITE_URL ?>/umrah-packages">Hajj Packages</a>
                        <a href="<?= SITE_URL ?>/umrah-packages">Umrah Packages</a>
                        <a href="<?= SITE_URL ?>/umrah-packages">Visa Assistance</a>
                        <a href="<?= SITE_URL ?>/umrah-packages">Hotel Booking</a>
                        <a href="<?= SITE_URL ?>/umrah-packages">Group & Family Packages</a>
                        <a href="<?= SITE_URL ?>/umrah-packages">Ramadan Umrah</a>
                        <a href="<?= SITE_URL ?>/blog">Travel Guidance</a>
                    </div>
                </div>

                <!-- Contact Info -->
                <div class="footer-col">
                    <h4>Contact Information</h4>
                    <div class="footer-contact-item">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-3.07-8.67A2 2 0 012 1h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.09 8.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg>
                        <div><a href="tel:<?= preg_replace('/\D/', '', $phone) ?>"><?= e($phone) ?></a><br><small style="color:rgba(255,255,255,0.4);">WhatsApp / Call</small></div>
                    </div>
                    <div class="footer-contact-item">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                        <a href="mailto:<?= e($email) ?>"><?= e($email) ?></a>
                    </div>
                    <div class="footer-contact-item">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        <span><?= e($address) ?></span>
                    </div>
                    <div class="footer-contact-item">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/></svg>
                        <span><?= e($hours) ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Bottom -->
    <div class="container">
        <div class="footer-bottom">
            <span>© <?= date('Y') ?> <?= e($siteName) ?>. All Rights Reserved.</span>
            <div class="footer-policy-links">
                <a href="<?= SITE_URL ?>/privacy-policy">Privacy Policy</a>
                <a href="<?= SITE_URL ?>/terms-and-conditions">Terms & Conditions</a>
                <a href="<?= SITE_URL ?>/cancellation-policy">Cancellation Policy</a>
            </div>
        </div>
    </div>
</footer>

<!-- Scripts -->
<script src="<?= SITE_URL ?>/public/js/main.js" defer></script>
<?php if (!empty($pageScripts)): ?>
<script><?= $pageScripts ?></script>
<?php endif; ?>
</body>
</html>

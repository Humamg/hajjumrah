<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
$db = getDB();

$month = $_GET['month'] ?? '';
if (!$month) redirect(SITE_URL . '/umrah-packages');

// Parse month
[$mName, $mYear] = array_pad(explode('-', $month, 2), 2, '');
$monthLabel = ucfirst($mName) . ' ' . strtoupper($mYear);
if (!$mYear) $monthLabel = ucfirst($mName);

$sortBy = $_GET['sort'] ?? 'departure_date';
$page   = max(1, (int)($_GET['page'] ?? 1));
$perPage= 12;
$offset = ($page-1)*$perPage;

$orderClause = match($sortBy) {
    'price_asc'  => 'MIN(pp.price) ASC',
    'price_desc' => 'MIN(pp.price) DESC',
    default      => 'p.departure_date ASC',
};

$total = $db->prepare("SELECT COUNT(DISTINCT p.id) FROM packages p LEFT JOIN package_prices pp ON pp.package_id=p.id WHERE p.status='published' AND DATE_FORMAT(p.departure_date,'%M-%Y')=?");
$total->execute([$month]);
$totalItems = (int)$total->fetchColumn();
$totalPages = max(1, ceil($totalItems/$perPage));

$stmt = $db->prepare("
    SELECT p.*, c.name AS cat_name, c.slug AS cat_slug, MIN(pp.price) AS min_price,
           (SELECT pp2.price FROM package_prices pp2 WHERE pp2.package_id=p.id AND pp2.sharing_type='Double' LIMIT 1) AS double_price
    FROM packages p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN package_prices pp ON pp.package_id=p.id
    WHERE p.status='published' AND DATE_FORMAT(p.departure_date,'%M-%Y')=?
    GROUP BY p.id ORDER BY $orderClause LIMIT $perPage OFFSET $offset
");
$stmt->execute([$month]);
$packages = $stmt->fetchAll();

// Available months
$allMonths = $db->query("SELECT DISTINCT DATE_FORMAT(departure_date,'%M %Y') AS label, DATE_FORMAT(departure_date,'%M-%Y') AS val FROM packages WHERE status='published' AND departure_date>=CURDATE() ORDER BY departure_date")->fetchAll();

$waNumber = getSetting('whatsapp','919911446919');
$pageTitle  = "$monthLabel Umrah Packages – Shahin Travels";
$metaDesc   = "Browse Umrah packages departing in $monthLabel. Book affordable packages with direct flights from India.";
$canonicalUrl = SITE_URL . '/umrah-packages/month/' . $month;
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-banner">
    <div class="container">
        <nav class="breadcrumb"><a href="<?=SITE_URL?>/">Home</a><span class="sep">›</span><a href="<?=SITE_URL?>/umrah-packages">Packages</a><span class="sep">›</span><span class="current"><?=e($monthLabel)?></span></nav>
        <h1><?=e($monthLabel)?> Umrah Packages</h1>
        <p>Explore the best Umrah packages departing in <?=e($monthLabel)?>.</p>
    </div>
</div>
<section class="section-sm">
    <div class="container">
        <!-- Month Tabs -->
        <div style="overflow-x:auto;margin-bottom:28px;">
            <div style="display:flex;gap:10px;padding-bottom:4px;white-space:nowrap;">
                <?php foreach ($allMonths as $m): ?>
                <a href="<?=SITE_URL?>/umrah-packages/month/<?=e($m['val'])?>" style="padding:8px 20px;border-radius:50px;font-size:.875rem;font-weight:600;border:2px solid <?=$m['val']===$month?'var(--green)':'var(--gray-200)'?>;background:<?=$m['val']===$month?'var(--green)':'transparent'?>;color:<?=$m['val']===$month?'#fff':'var(--gray-800)'?>;"><?=e($m['label'])?></a>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="listing-toolbar">
            <div class="results-count">Showing <strong><?=$totalItems?></strong> packages for <?=e($monthLabel)?></div>
            <select class="sort-select" onchange="window.location.href='<?=SITE_URL?>/umrah-packages/month/<?=$month?>?sort='+this.value">
                <option value="departure_date" <?=$sortBy==='departure_date'?'selected':''?>>Departure Date</option>
                <option value="price_asc"      <?=$sortBy==='price_asc'?'selected':''?>>Price: Low to High</option>
                <option value="price_desc"     <?=$sortBy==='price_desc'?'selected':''?>>Price: High to Low</option>
            </select>
        </div>
        <div class="packages-grid" style="margin-top:20px;">
            <?php foreach ($packages as $pkg):
                $price = $pkg['double_price'] ?? $pkg['min_price'] ?? 0;
                $badge = 'badge-'.strtolower($pkg['cat_name']??'budget');
            ?>
            <div class="package-card">
                <div class="package-card-image">
                    <img src="<?=$pkg['cover_image']?e(SITE_URL.'/public/images/packages/'.$pkg['cover_image']):'https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?w=600&q=70'?>" alt="<?=e($pkg['title'])?>" loading="lazy">
                    <span class="badge <?=e($badge)?>"><?=e($pkg['cat_name']??'Package')?></span>
                </div>
                <div class="package-card-body">
                    <h3><?=e($pkg['title'])?></h3>
                    <div class="package-meta">
                        <div class="package-meta-item">📅 <?=date('d M Y',strtotime($pkg['departure_date']))?></div>
                        <div class="package-meta-item">🌙 <?=$pkg['days']?> Days / <?=$pkg['nights']?> Nights</div>
                    </div>
                </div>
                <div class="package-card-footer">
                    <div>
                        <div class="price-label">From</div>
                        <div class="price-amount"><?=formatINR((float)$price)?></div>
                        <div class="price-per">per person</div>
                    </div>
                    <a href="<?=SITE_URL?>/umrah-packages/<?=e($pkg['slug'])?>" class="btn btn-primary btn-sm">View Details →</a>
                </div>
            </div>
            <?php endforeach; ?>
            <?php if(empty($packages)): ?>
            <div style="grid-column:1/-1;text-align:center;padding:60px;"><h3>No packages for <?=e($monthLabel)?></h3><a href="<?=SITE_URL?>/umrah-packages" class="btn btn-primary" style="margin-top:16px;">Browse All Packages</a></div>
            <?php endif; ?>
        </div>
        <?php if($totalPages>1): ?>
        <nav class="pagination" style="margin-top:30px;">
            <?php for($p=1;$p<=$totalPages;$p++): ?>
            <a href="?page=<?=$p?>&sort=<?=$sortBy?>" <?=$p===$page?'class="active"':''?>><?=$p?></a>
            <?php endfor; ?>
        </nav>
        <?php endif; ?>
    </div>
</section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
$db = getDB();

$page    = max(1, (int)($_GET['page']??1));
$perPage = 9;
$offset  = ($page-1)*$perPage;
$catSlug = $_GET['cat'] ?? '';

$where  = ["bp.status='published'"];
$params = [];
if ($catSlug) { $where[] = 'bc.slug=?'; $params[] = $catSlug; }
$whereStr = implode(' AND ', $where);

$total = $db->prepare("SELECT COUNT(bp.id) FROM blog_posts bp LEFT JOIN blog_categories bc ON bc.id=bp.category_id WHERE $whereStr");
$total->execute($params);
$totalItems = (int)$total->fetchColumn();
$totalPages = max(1, ceil($totalItems/$perPage));

$stmt = $db->prepare("SELECT bp.*, bc.name AS cat_name, bc.slug AS cat_slug FROM blog_posts bp LEFT JOIN blog_categories bc ON bc.id=bp.category_id WHERE $whereStr ORDER BY bp.published_at DESC LIMIT $perPage OFFSET $offset");
$stmt->execute($params);
$posts = $stmt->fetchAll();

$blogCats = $db->query("SELECT bc.*, COUNT(bp.id) AS post_count FROM blog_categories bc LEFT JOIN blog_posts bp ON bp.category_id=bc.id AND bp.status='published' GROUP BY bc.id ORDER BY bc.name")->fetchAll();

$pageTitle  = 'Umrah Travel Blog – Tips, Guides & Updates | Shahin Travels';
$metaDesc   = 'Read our blog for Umrah travel tips, packing guides, visa information, and latest updates on Hajj & Umrah from India.';
$canonicalUrl = SITE_URL . '/blog';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-banner">
    <div class="container">
        <nav class="breadcrumb"><a href="<?=SITE_URL?>/">Home</a><span class="sep">›</span><span class="current">Blog</span></nav>
        <h1>Travel Blog & Guides</h1>
        <p>Tips, guides and updates for your Umrah & Hajj journey.</p>
    </div>
</div>
<section class="section-sm">
    <div class="container">
        <div class="listing-layout">
            <div>
                <?php if(!empty($blogCats)): ?>
                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:24px;">
                    <a href="<?=SITE_URL?>/blog" style="padding:6px 16px;border-radius:50px;font-size:.8rem;font-weight:600;border:2px solid <?=!$catSlug?'var(--green)':'var(--gray-200)'?>;background:<?=!$catSlug?'var(--green)':'transparent'?>;color:<?=!$catSlug?'#fff':'var(--gray-800)'?>;">All</a>
                    <?php foreach($blogCats as $bc): ?>
                    <a href="<?=SITE_URL?>/blog?cat=<?=e($bc['slug'])?>" style="padding:6px 16px;border-radius:50px;font-size:.8rem;font-weight:600;border:2px solid <?=$bc['slug']===$catSlug?'var(--green)':'var(--gray-200)'?>;background:<?=$bc['slug']===$catSlug?'var(--green)':'transparent'?>;color:<?=$bc['slug']===$catSlug?'#fff':'var(--gray-800)'?>;"><?=e($bc['name'])?> <span style="opacity:.7;">(<?=$bc['post_count']?>)</span></a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                <div class="blog-grid">
                    <?php foreach($posts as $post): ?>
                    <article class="blog-card">
                        <div class="blog-card-image">
                            <img src="<?=$post['featured_image']?e(SITE_URL.'/public/images/blog/'.$post['featured_image']):'https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?w=400&q=70'?>" alt="<?=e($post['title'])?>" loading="lazy">
                            <?php if($post['cat_name']): ?><span class="blog-card-category"><?=e($post['cat_name'])?></span><?php endif; ?>
                        </div>
                        <div class="blog-card-body">
                            <div class="blog-card-date">📅 <?=date('d M Y',strtotime($post['published_at']??'now'))?></div>
                            <h2 style="font-size:1rem;"><?=e($post['title'])?></h2>
                            <p><?=e(mb_strimwidth($post['excerpt']??'',0,120,'...'))?></p>
                            <a href="<?=SITE_URL?>/blog/<?=e($post['slug'])?>" class="blog-read-more">Read More →</a>
                        </div>
                    </article>
                    <?php endforeach; ?>
                    <?php if(empty($posts)): ?><div style="grid-column:1/-1;text-align:center;padding:60px;"><h3>No blog posts yet.</h3></div><?php endif; ?>
                </div>
                <?php if($totalPages>1): ?><nav class="pagination" style="margin-top:30px;"><?php for($p=1;$p<=$totalPages;$p++): ?><a href="?page=<?=$p?><?=$catSlug?'&cat='.$catSlug:''?>" <?=$p===$page?'class="active"':''?>><?=$p?></a><?php endfor; ?></nav><?php endif; ?>
            </div>
            <!-- Blog Sidebar -->
            <aside style="width:260px;">
                <div class="card" style="margin-bottom:20px;">
                    <h3 style="font-size:.95rem;margin-bottom:14px;">🕌 Quick Links</h3>
                    <div style="display:flex;flex-direction:column;gap:8px;">
                        <a href="<?=SITE_URL?>/umrah-packages" style="color:var(--green);font-size:.875rem;">→ All Umrah Packages</a>
                        <a href="<?=SITE_URL?>/contact-us" style="color:var(--green);font-size:.875rem;">→ Contact & Enquiry</a>
                    </div>
                </div>
                <div class="card">
                    <h3 style="font-size:.95rem;margin-bottom:14px;">📚 Categories</h3>
                    <?php foreach($blogCats as $bc): ?>
                    <a href="<?=SITE_URL?>/blog?cat=<?=e($bc['slug'])?>" style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--gray-100);font-size:.875rem;color:<?=$bc['slug']===$catSlug?'var(--green)':'#444'?>;"><?=e($bc['name'])?><span style="color:var(--gray-400);"><?=$bc['post_count']?></span></a>
                    <?php endforeach; ?>
                </div>
            </aside>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

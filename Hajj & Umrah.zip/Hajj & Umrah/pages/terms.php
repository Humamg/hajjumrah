<?php
// ============================================================
// Shahin Travels – Terms & Conditions (pages/terms.php)
// ============================================================
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

$db = getDB();
$pageData = $db->query("SELECT * FROM pages WHERE page_key = 'terms'")->fetch();

$pageTitle    = $pageData['seo_title'] ?? 'Terms and Conditions – Shahin Travels';
$metaDesc     = $pageData['seo_description'] ?? 'Terms and conditions for booking Hajj and Umrah tour packages with Shahin Travels. Read our booking procedures, pilgrim responsibilities, and guidelines.';
$canonicalUrl = SITE_URL . '/terms-and-conditions';
$noindex      = !empty($pageData['noindex']);

$schema = json_encode([
    '@context' => 'https://schema.org',
    '@type'    => 'WebPage',
    'name'     => $pageTitle,
    'url'      => $canonicalUrl,
    'breadcrumb' => [
        '@type' => 'BreadcrumbList',
        'itemListElement' => [
            ['@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => SITE_URL . '/'],
            ['@type' => 'ListItem', 'position' => 2, 'name' => 'Terms and Conditions', 'item' => $canonicalUrl]
        ]
    ]
], JSON_UNESCAPED_SLASHES);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-banner">
    <div class="container">
        <nav class="breadcrumb" aria-label="Breadcrumb">
            <a href="<?= SITE_URL ?>/">Home</a>
            <span class="sep">/</span>
            <span class="current">Terms & Conditions</span>
        </nav>
        <h1>Terms and Conditions</h1>
        <p>Guidelines and terms for Hajj & Umrah pilgrimage bookings with Shahin Travels.</p>
    </div>
</div>

<section class="section">
    <div class="container" style="max-width:860px;">
        <div style="background:var(--white); border-radius:16px; padding:40px; box-shadow:var(--shadow-sm); line-height:1.8; color:var(--gray-700);">
            
            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">1. Agreement to Terms</h2>
            <p style="margin-bottom:20px;">
                By booking any Hajj, Umrah, or Ziyarat package with Shahin Travels, the pilgrim ("traveler") confirms that they have read, understood, and agreed to these Terms and Conditions in full.
            </p>

            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">2. Booking & Confirmation</h2>
            <ul style="margin-left:24px; margin-bottom:20px;">
                <li>Bookings are initiated via our website enquiry forms, direct WhatsApp communication, or authorized office representatives.</li>
                <li>A booking is officially confirmed only upon receipt of the designated booking advance payment along with valid passport copies.</li>
                <li>Passports must have a minimum validity of <strong>6 months</strong> from the scheduled date of travel.</li>
            </ul>

            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">3. Visa Regulations</h2>
            <ul style="margin-left:24px; margin-bottom:20px;">
                <li>Umrah visa approvals and issuance are solely at the discretion of the Ministry of Hajj & Umrah, Kingdom of Saudi Arabia.</li>
                <li>Shahin Travels acts as a facilitator and cannot be held liable for any visa delay, rejection, or policy revisions instituted by the Saudi Embassy or Ministry authorities.</li>
                <li>Pilgrims must comply strictly with the duration of stay authorized on their visa and adhere to Saudi immigration regulations.</li>
            </ul>

            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">4. Accommodation & Room Sharing</h2>
            <ul style="margin-left:24px; margin-bottom:20px;">
                <li>Hotel check-in and check-out timings in Makkah and Madinah adhere strictly to international hotel policies (generally 4:00 PM check-in and 12:00 PM check-out).</li>
                <li>Room types (Quad, Triple, Double) reflect the number of beds provided in a standard room. In quad sharing, four pilgrims share one room; in triple sharing, three pilgrims share; in double sharing, two pilgrims share.</li>
                <li>Distances stated from the Haram courtyards are approximations based on regular pedestrian routes.</li>
            </ul>

            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">5. Flights and Baggage</h2>
            <ul style="margin-left:24px; margin-bottom:20px;">
                <li>Flight schedules, terminals, and aircraft types are under the control of the respective airlines. Any schedule changes or delays enforced by airlines are beyond Shahin Travels' direct control.</li>
                <li>Baggage allowance strictly follows airline regulations (typically 2 pieces of 23kg each + 7kg cabin baggage + 5 Liters Zamzam water if approved by carrier). Excess luggage fees are the sole responsibility of the traveler.</li>
            </ul>

            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">6. Health, Conduct & Pilgrim Etiquette</h2>
            <p style="margin-bottom:20px;">
                All pilgrims are expected to maintain the utmost religious decorum, patience, and brotherhood while in the sacred territories. Travelers must disclose any pre-existing medical conditions or mobility constraints prior to travel so suitable assistance can be arranged.
            </p>

            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">7. Amendments and Force Majeure</h2>
            <p style="margin-bottom:20px;">
                In rare events of unforeseen natural disasters, geopolitical disruptions, flight suspensions, or government-mandated travel restrictions (Force Majeure), Shahin Travels will work diligently to rearrange arrangements or secure credits, but cannot accept financial liability for third-party service provider non-performance.
            </p>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

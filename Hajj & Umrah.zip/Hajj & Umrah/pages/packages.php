<?php
// Package Listing Page
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

$db = getDB();

// Filters
$filterMonth    = $_GET['month']   ?? '';
$filterCat      = $_GET['cat']     ?? '';
$filterDuration = $_GET['duration']?? '';
$filterSharing  = $_GET['sharing'] ?? '';
$sortBy         = $_GET['sort']    ?? 'departure_date';
$page           = max(1, (int)($_GET['page'] ?? 1));
$perPage        = 12;
$offset         = ($page - 1) * $perPage;

// Build query
$where  = ["p.status = 'published'", "p.departure_date >= CURDATE()"];
$params = [];

if ($filterMonth) {
    $where[]  = "DATE_FORMAT(p.departure_date, '%M-%Y') = ?";
    $params[] = $filterMonth;
}
if ($filterCat) {
    $where[]  = "c.slug = ?";
    $params[] = $filterCat;
}
if ($filterDuration) {
    switch ($filterDuration) {
        case '7-10':  $where[] = "p.days BETWEEN 7 AND 10"; break;
        case '11-14': $where[] = "p.days BETWEEN 11 AND 14"; break;
        case '15-20':
        case '15-21': $where[] = "p.days BETWEEN 15 AND 21"; break;
        case '21+':   $where[] = "p.days >= 21"; break;
    }
}
if ($filterSharing) {
    $where[]  = "EXISTS (SELECT 1 FROM package_prices pp2 WHERE pp2.package_id = p.id AND pp2.sharing_type = ?)";
    $params[] = $filterSharing;
}

$whereClause = implode(' AND ', $where);
$orderClause = match($sortBy) {
    'price_asc'  => 'MIN(pp.price) ASC',
    'price_desc' => 'MIN(pp.price) DESC',
    default      => 'p.departure_date ASC',
};

// Count
$countStmt = $db->prepare("
    SELECT COUNT(DISTINCT p.id) FROM packages p
    LEFT JOIN categories c ON c.id = p.category_id
    LEFT JOIN package_prices pp ON pp.package_id = p.id
    WHERE $whereClause
");
$countStmt->execute($params);
$totalItems = (int)$countStmt->fetchColumn();
$totalPages = max(1, ceil($totalItems / $perPage));

// Packages
$stmt = $db->prepare("
    SELECT p.*, c.name AS cat_name, c.slug AS cat_slug,
           MIN(pp.price) AS min_price,
           (SELECT pp_q.price FROM package_prices pp_q WHERE pp_q.package_id = p.id AND pp_q.sharing_type = 'Quad' LIMIT 1) AS quad_price,
           (SELECT pp_t.price FROM package_prices pp_t WHERE pp_t.package_id = p.id AND pp_t.sharing_type = 'Triple' LIMIT 1) AS triple_price,
           (SELECT pp_d.price FROM package_prices pp_d WHERE pp_d.package_id = p.id AND pp_d.sharing_type = 'Double' LIMIT 1) AS double_price,
           mh.distance_haram AS makkah_dist, mah.distance_haram AS madinah_dist,
           mh.name AS makkah_hotel, mah.name AS madinah_hotel
    FROM packages p
    LEFT JOIN categories c ON c.id = p.category_id
    LEFT JOIN package_prices pp ON pp.package_id = p.id
    LEFT JOIN hotels mh ON mh.id = p.makkah_hotel_id
    LEFT JOIN hotels mah ON mah.id = p.madinah_hotel_id
    WHERE $whereClause
    GROUP BY p.id
    ORDER BY $orderClause
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$packages = $stmt->fetchAll();

// Available months for filter
$availMonths = $db->query("
    SELECT DISTINCT DATE_FORMAT(departure_date, '%M %Y') AS label, DATE_FORMAT(departure_date, '%M-%Y') AS val
    FROM packages WHERE status = 'published' AND departure_date >= CURDATE()
    ORDER BY departure_date ASC
")->fetchAll();

// Categories for filter
$categories = $db->query("SELECT * FROM categories ORDER BY sort_order")->fetchAll();

// Active filters list for chips and badges
$activeChips = [];
if ($filterMonth) {
    $monthLabel = $filterMonth;
    foreach ($availMonths as $m) {
        if ($m['val'] === $filterMonth) {
            $monthLabel = $m['label'];
            break;
        }
    }
    $query = $_GET;
    unset($query['month'], $query['page']);
    $activeChips[] = [
        'key'   => 'month',
        'label' => 'Month: ' . $monthLabel,
        'url'   => !empty($query) ? '?' . http_build_query($query) : SITE_URL . '/umrah-packages'
    ];
}

if ($filterCat) {
    $catName = $filterCat;
    foreach ($categories as $c) {
        if ($c['slug'] === $filterCat) {
            $catName = $c['name'];
            break;
        }
    }
    $query = $_GET;
    unset($query['cat'], $query['page']);
    $activeChips[] = [
        'key'   => 'cat',
        'label' => 'Category: ' . $catName,
        'url'   => !empty($query) ? '?' . http_build_query($query) : SITE_URL . '/umrah-packages'
    ];
}

if ($filterDuration) {
    $durationLabels = [
        '7-10'  => '7 – 10 Days',
        '11-14' => '11 – 14 Days',
        '15-20' => '15 – 20 Days',
        '15-21' => '15 – 21 Days',
        '21+'   => '21+ Days',
    ];
    $durLabel = $durationLabels[$filterDuration] ?? $filterDuration;
    $query = $_GET;
    unset($query['duration'], $query['page']);
    $activeChips[] = [
        'key'   => 'duration',
        'label' => 'Duration: ' . $durLabel,
        'url'   => !empty($query) ? '?' . http_build_query($query) : SITE_URL . '/umrah-packages'
    ];
}

if ($filterSharing) {
    $sharingLabels = [
        'Quad'   => 'Quad Sharing',
        'Triple' => 'Triple Sharing',
        'Double' => 'Double Sharing',
    ];
    $shareLabel = $sharingLabels[$filterSharing] ?? $filterSharing;
    $query = $_GET;
    unset($query['sharing'], $query['page']);
    $activeChips[] = [
        'key'   => 'sharing',
        'label' => 'Room: ' . $shareLabel,
        'url'   => !empty($query) ? '?' . http_build_query($query) : SITE_URL . '/umrah-packages'
    ];
}

$activeFilterCount = count($activeChips);

$waNumber = getSetting('whatsapp', '919911446919');

$pageTitle  = 'All Umrah Packages – Shahin Travels';
$metaDesc   = 'Browse all Umrah packages from Shahin Travels. Filter by month, category, duration and sharing type. Best packages with direct flights from India.';
$canonicalUrl = SITE_URL . '/umrah-packages';

$schema = json_encode([
    '@context' => 'https://schema.org',
    '@type'    => 'ItemList',
    'name'     => 'Umrah Packages',
    'url'      => $canonicalUrl,
    'numberOfItems' => $totalItems,
]);

require_once __DIR__ . '/../includes/header.php';
?>
<!-- Page Banner -->
<div class="page-banner">
    <div class="container">
        <nav class="breadcrumb" aria-label="Breadcrumb">
            <a href="<?= SITE_URL ?>/">Home</a>
            <span class="sep">›</span>
            <span class="current">All Umrah Packages</span>
        </nav>
        <h1>All Umrah Packages</h1>
        <p>Find the best Umrah packages with comfortable hotels and complete assistance.</p>
    </div>
</div>

<section class="section-sm">
    <div class="container">
        <!-- Mobile filter button -->
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;flex-wrap:wrap;gap:10px;">
            <button class="filter-toggle-btn" id="filter-toggle">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="4" y1="6" x2="20" y2="6"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="11" y1="18" x2="13" y2="18"/></svg>
                Filter Packages
                <?php if ($activeFilterCount > 0): ?>
                <span class="filter-count-badge" style="background:#fff;color:var(--green);border-color:#fff;"><?= $activeFilterCount ?></span>
                <?php endif; ?>
            </button>
            <?php if ($activeFilterCount > 0): ?>
            <a href="<?= SITE_URL ?>/umrah-packages" class="filter-reset-link" style="font-size:0.85rem;">Clear All Filters</a>
            <?php endif; ?>
        </div>

        <div class="listing-layout">
            <!-- Sidebar Filters (Desktop) -->
            <aside class="filter-sidebar">
                <div class="filter-sidebar-header">
                    <h3>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="6" x2="20" y2="6"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="11" y1="18" x2="13" y2="18"/></svg>
                        Filter Packages
                        <?php if ($activeFilterCount > 0): ?>
                        <span class="filter-count-badge"><?= $activeFilterCount ?> active</span>
                        <?php endif; ?>
                    </h3>
                    <?php if ($activeFilterCount > 0): ?>
                    <a href="<?= SITE_URL ?>/umrah-packages" class="filter-reset-link">Reset</a>
                    <?php endif; ?>
                </div>

                <form id="filter-form" method="GET" action="<?= SITE_URL ?>/umrah-packages">
                    <div class="filter-group">
                        <label for="f-month" class="filter-label">Month</label>
                        <select name="month" id="f-month" class="filter-select">
                            <option value="">All Months</option>
                            <?php foreach ($availMonths as $m): ?>
                            <option value="<?= e($m['val']) ?>" <?= $filterMonth === $m['val'] ? 'selected' : '' ?>><?= e($m['label']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label class="filter-label">Category</label>
                        <div class="filter-options">
                            <label class="filter-option <?= !$filterCat ? 'active' : '' ?>">
                                <input type="radio" name="cat" value="" <?= !$filterCat ? 'checked' : '' ?>>
                                <span class="filter-option-text">All Categories</span>
                            </label>
                            <?php foreach ($categories as $cat): ?>
                            <label class="filter-option <?= $filterCat === $cat['slug'] ? 'active' : '' ?>">
                                <input type="radio" name="cat" value="<?= e($cat['slug']) ?>" <?= $filterCat === $cat['slug'] ? 'checked' : '' ?>>
                                <span class="filter-option-text"><?= e($cat['name']) ?></span>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="filter-group">
                        <label for="f-duration" class="filter-label">Duration</label>
                        <select name="duration" id="f-duration" class="filter-select">
                            <option value="">All Durations</option>
                            <option value="7-10"  <?= $filterDuration === '7-10'  ? 'selected' : '' ?>>7 – 10 Days</option>
                            <option value="11-14" <?= $filterDuration === '11-14' ? 'selected' : '' ?>>11 – 14 Days</option>
                            <option value="15-21" <?= in_array($filterDuration, ['15-20', '15-21']) ? 'selected' : '' ?>>15 – 21 Days</option>
                            <option value="21+"   <?= $filterDuration === '21+'   ? 'selected' : '' ?>>21+ Days</option>
                        </select>
                    </div>

                    <div class="filter-group">
                        <label class="filter-label">Room Sharing</label>
                        <div class="filter-options">
                            <label class="filter-option <?= !$filterSharing ? 'active' : '' ?>">
                                <input type="radio" name="sharing" value="" <?= !$filterSharing ? 'checked' : '' ?>>
                                <span class="filter-option-text">All Types</span>
                            </label>
                            <label class="filter-option <?= $filterSharing === 'Quad' ? 'active' : '' ?>">
                                <input type="radio" name="sharing" value="Quad" <?= $filterSharing === 'Quad' ? 'checked' : '' ?>>
                                <span class="filter-option-text">Quad Sharing</span>
                            </label>
                            <label class="filter-option <?= $filterSharing === 'Triple' ? 'active' : '' ?>">
                                <input type="radio" name="sharing" value="Triple" <?= $filterSharing === 'Triple' ? 'checked' : '' ?>>
                                <span class="filter-option-text">Triple Sharing</span>
                            </label>
                            <label class="filter-option <?= $filterSharing === 'Double' ? 'active' : '' ?>">
                                <input type="radio" name="sharing" value="Double" <?= $filterSharing === 'Double' ? 'checked' : '' ?>>
                                <span class="filter-option-text">Double Sharing</span>
                            </label>
                        </div>
                    </div>

                    <input type="hidden" name="sort" value="<?= e($sortBy) ?>">

                    <div class="filter-actions">
                        <button type="submit" class="btn btn-primary btn-sm">Apply Filters</button>
                        <a href="<?= SITE_URL ?>/umrah-packages" class="btn btn-outline-green btn-sm">Reset</a>
                    </div>
                </form>
            </aside>

            <!-- Package Results -->
            <div>
                <!-- Active Filters Chips -->
                <?php if (!empty($activeChips)): ?>
                <div class="active-filters-wrap">
                    <span class="active-filters-label">Active:</span>
                    <?php foreach ($activeChips as $chip): ?>
                    <a href="<?= e($chip['url']) ?>" class="active-filter-chip" title="Remove <?= e($chip['label']) ?>">
                        <span><?= e($chip['label']) ?></span>
                        <span class="chip-remove" aria-hidden="true">✕</span>
                    </a>
                    <?php endforeach; ?>
                    <a href="<?= SITE_URL ?>/umrah-packages" class="active-filters-clear-all">Clear All</a>
                </div>
                <?php endif; ?>

                <!-- Toolbar -->
                <div class="listing-toolbar">
                    <div class="results-count">
                        Showing <strong><?= $totalItems ?></strong> Umrah Package<?= $totalItems !== 1 ? 's' : '' ?>
                        <?php if ($activeFilterCount > 0): ?> (filtered)<?php endif; ?>
                    </div>
                    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                        <label for="sort-select" style="font-size:.8rem;color:#666;">Sort by:</label>
                        <select id="sort-select" class="sort-select" onchange="const p = new URLSearchParams(window.location.search); p.set('sort', this.value); p.delete('page'); window.location.search = p.toString();">
                            <option value="departure_date" <?= $sortBy === 'departure_date' ? 'selected' : '' ?>>Departure Date</option>
                            <option value="price_asc"      <?= $sortBy === 'price_asc'      ? 'selected' : '' ?>>Price: Low to High</option>
                            <option value="price_desc"     <?= $sortBy === 'price_desc'     ? 'selected' : '' ?>>Price: High to Low</option>
                        </select>
                    </div>
                </div>

                <!-- Cards -->
                <div class="packages-grid">
                    <?php foreach ($packages as $pkg):
                        $badgeClass = 'badge-' . strtolower($pkg['cat_name'] ?? 'budget');
                        
                        // Select accurate price and sharing label according to active filter
                        if ($filterSharing === 'Quad') {
                            $cardPrice = $pkg['quad_price'] ?? $pkg['min_price'] ?? 0;
                            $sharingLabel = 'Quad Sharing';
                        } elseif ($filterSharing === 'Triple') {
                            $cardPrice = $pkg['triple_price'] ?? $pkg['min_price'] ?? 0;
                            $sharingLabel = 'Triple Sharing';
                        } elseif ($filterSharing === 'Double') {
                            $cardPrice = $pkg['double_price'] ?? $pkg['min_price'] ?? 0;
                            $sharingLabel = 'Double Sharing';
                        } else {
                            $cardPrice = $pkg['quad_price'] ?? $pkg['min_price'] ?? 0;
                            $sharingLabel = 'Quad Sharing';
                        }

                        $waMsg = strtr(getSetting('wa_package_template', ''), [
                            '{package_name}'   => $pkg['title'],
                            '{departure_date}' => date('d M Y', strtotime($pkg['departure_date'])),
                            '{price}'          => formatINR((float)$cardPrice),
                            '{sharing}'        => $sharingLabel
                        ]);
                    ?>
                    <div class="package-card">
                        <div class="package-card-image">
                            <img src="<?= $pkg['cover_image'] ? e(SITE_URL . '/public/images/packages/' . $pkg['cover_image']) : 'https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?w=600&q=70' ?>" alt="<?= e($pkg['title']) ?>" loading="lazy">
                            <span class="badge <?= e($badgeClass) ?>"><?= e($pkg['cat_name'] ?? 'Package') ?></span>
                            <?php if ($pkg['is_trending']): ?><span class="trending-badge">🔥 Trending</span><?php endif; ?>
                        </div>
                        <div class="package-card-body">
                            <h3><?= e($pkg['title']) ?></h3>
                            <div class="package-meta">
                                <?php if ($pkg['makkah_dist']): ?>
                                <div class="package-meta-item">📍 Makkah <?= $pkg['makkah_dist'] ?>m + Madinah <?= $pkg['madinah_dist'] ?? '?' ?>m from Haram</div>
                                <?php endif; ?>
                                <div class="package-meta-item">📅 Departure: <?= date('d M Y', strtotime($pkg['departure_date'])) ?></div>
                                <div class="package-meta-item">🌙 <?= $pkg['days'] ?> Days / <?= $pkg['nights'] ?> Nights</div>
                            </div>
                        </div>
                        <div class="package-card-footer">
                            <div>
                                <div class="price-label">From</div>
                                <div class="price-amount"><?= formatINR((float)$cardPrice) ?></div>
                                <div class="price-per">per person (<?= e($sharingLabel) ?>)</div>
                            </div>
                            <a href="<?= SITE_URL ?>/umrah-packages/<?= e($pkg['slug']) ?>" class="btn btn-primary btn-sm">View Details →</a>
                        </div>
                    </div>
                    <?php endforeach; ?>

                    <?php if (empty($packages)): ?>
                    <div style="grid-column:1/-1;text-align:center;padding:60px 20px;">
                        <div style="font-size:3rem;margin-bottom:12px;">🔍</div>
                        <h3 style="color:var(--green-dark);margin-bottom:8px;">No Packages Found</h3>
                        <p style="color:#666;margin-bottom:20px;">Try adjusting your filters to see more packages.</p>
                        <a href="<?= SITE_URL ?>/umrah-packages" class="btn btn-primary">Clear All Filters</a>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                <nav class="pagination" aria-label="Pagination">
                    <?php if ($page > 1): ?>
                    <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>" class="prev-next">← Prev</a>
                    <?php endif; ?>
                    <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                        <?php if ($p === 1 || $p === $totalPages || abs($p - $page) <= 2): ?>
                        <a href="?<?= http_build_query(array_merge($_GET, ['page' => $p])) ?>" <?= $p === $page ? 'class="active"' : '' ?>><?= $p ?></a>
                        <?php elseif (abs($p - $page) === 3): ?>
                        <span class="dots">…</span>
                        <?php endif; ?>
                    <?php endfor; ?>
                    <?php if ($page < $totalPages): ?>
                    <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>" class="prev-next">Next →</a>
                    <?php endif; ?>
                </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- Mobile Filter Drawer -->
<div class="filter-drawer-overlay" id="filter-overlay"></div>
<div class="filter-drawer" id="filter-drawer">
    <div class="filter-drawer-header">
        <div style="display:flex;align-items:center;gap:8px;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="6" x2="20" y2="6"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="11" y1="18" x2="13" y2="18"/></svg>
            <h3 style="margin:0;font-size:1.1rem;color:var(--green-dark);">Filter Packages</h3>
            <?php if ($activeFilterCount > 0): ?>
            <span class="filter-count-badge"><?= $activeFilterCount ?></span>
            <?php endif; ?>
        </div>
        <button class="filter-drawer-close" id="filter-close" aria-label="Close filters">✕</button>
    </div>
    <form method="GET" action="<?= SITE_URL ?>/umrah-packages">
        <div class="filter-group">
            <label class="filter-label">Month</label>
            <select name="month" class="filter-select">
                <option value="">All Months</option>
                <?php foreach ($availMonths as $m): ?>
                <option value="<?= e($m['val']) ?>" <?= $filterMonth === $m['val'] ? 'selected' : '' ?>><?= e($m['label']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="filter-group">
            <label class="filter-label">Category</label>
            <div class="filter-options">
                <label class="filter-option <?= !$filterCat ? 'active' : '' ?>">
                    <input type="radio" name="cat" value="" <?= !$filterCat ? 'checked' : '' ?>>
                    <span class="filter-option-text">All Categories</span>
                </label>
                <?php foreach ($categories as $cat): ?>
                <label class="filter-option <?= $filterCat === $cat['slug'] ? 'active' : '' ?>">
                    <input type="radio" name="cat" value="<?= e($cat['slug']) ?>" <?= $filterCat === $cat['slug'] ? 'checked' : '' ?>>
                    <span class="filter-option-text"><?= e($cat['name']) ?></span>
                </label>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="filter-group">
            <label class="filter-label">Duration</label>
            <select name="duration" class="filter-select">
                <option value="">All Durations</option>
                <option value="7-10"  <?= $filterDuration === '7-10'  ? 'selected' : '' ?>>7 – 10 Days</option>
                <option value="11-14" <?= $filterDuration === '11-14' ? 'selected' : '' ?>>11 – 14 Days</option>
                <option value="15-21" <?= in_array($filterDuration, ['15-20', '15-21']) ? 'selected' : '' ?>>15 – 21 Days</option>
                <option value="21+"   <?= $filterDuration === '21+'   ? 'selected' : '' ?>>21+ Days</option>
            </select>
        </div>
        <div class="filter-group">
            <label class="filter-label">Room Sharing</label>
            <div class="filter-options">
                <label class="filter-option <?= !$filterSharing ? 'active' : '' ?>">
                    <input type="radio" name="sharing" value="" <?= !$filterSharing ? 'checked' : '' ?>>
                    <span class="filter-option-text">All Types</span>
                </label>
                <label class="filter-option <?= $filterSharing === 'Quad' ? 'active' : '' ?>">
                    <input type="radio" name="sharing" value="Quad" <?= $filterSharing === 'Quad' ? 'checked' : '' ?>>
                    <span class="filter-option-text">Quad Sharing</span>
                </label>
                <label class="filter-option <?= $filterSharing === 'Triple' ? 'active' : '' ?>">
                    <input type="radio" name="sharing" value="Triple" <?= $filterSharing === 'Triple' ? 'checked' : '' ?>>
                    <span class="filter-option-text">Triple Sharing</span>
                </label>
                <label class="filter-option <?= $filterSharing === 'Double' ? 'active' : '' ?>">
                    <input type="radio" name="sharing" value="Double" <?= $filterSharing === 'Double' ? 'checked' : '' ?>>
                    <span class="filter-option-text">Double Sharing</span>
                </label>
            </div>
        </div>
        <input type="hidden" name="sort" value="<?= e($sortBy) ?>">
        <div class="filter-actions">
            <button type="submit" class="btn btn-primary btn-sm">Apply Filters</button>
            <a href="<?= SITE_URL ?>/umrah-packages" class="btn btn-outline-green btn-sm">Reset</a>
        </div>
    </form>
</div>

<?php
$pageScripts = "document.addEventListener('DOMContentLoaded', initFilterDrawer);";
require_once __DIR__ . '/../includes/footer.php';
?>

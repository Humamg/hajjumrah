<?php
// Package Detail Page
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

$db   = getDB();
$slug = $_GET['slug'] ?? '';

if (!$slug) { header('Location: ' . SITE_URL . '/umrah-packages'); exit; }

// Fetch package
$stmt = $db->prepare("
    SELECT p.*, c.name AS cat_name, c.slug AS cat_slug,
           mh.name AS makkah_hotel, mh.stars AS makkah_stars, mh.distance_haram AS makkah_dist, mh.description AS makkah_desc, mh.image AS makkah_img,
           mdh.name AS madinah_hotel, mdh.stars AS madinah_stars, mdh.distance_haram AS madinah_dist, mdh.description AS madinah_desc, mdh.image AS madinah_img
    FROM packages p
    LEFT JOIN categories c ON c.id = p.category_id
    LEFT JOIN hotels mh  ON mh.id  = p.makkah_hotel_id
    LEFT JOIN hotels mdh ON mdh.id = p.madinah_hotel_id
    WHERE p.slug = ? AND p.status = 'published'
");
$stmt->execute([$slug]);
$pkg = $stmt->fetch();

if (!$pkg) {
    http_response_code(404);
    $pageTitle = 'Package Not Found';
    require_once __DIR__ . '/../includes/header.php';
    echo '<div class="container" style="padding:100px 20px;text-align:center;"><h1>Package Not Found</h1><p>This package may have expired or does not exist.</p><a href="' . SITE_URL . '/umrah-packages" class="btn btn-primary" style="margin-top:20px;">Browse All Packages</a></div>';
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

// Prices
$prices = $db->prepare("SELECT * FROM package_prices WHERE package_id = ? ORDER BY FIELD(sharing_type,'Quad','Triple','Double')");
$prices->execute([$pkg['id']]);
$priceRows = $prices->fetchAll();
$priceMap  = array_column($priceRows, 'price', 'sharing_type');

// Gallery
$galleryStmt = $db->prepare("SELECT * FROM package_images WHERE package_id = ? ORDER BY sort_order, id");
$galleryStmt->execute([$pkg['id']]);
$gallery = $galleryStmt->fetchAll();

// Itinerary
$itinStmt = $db->prepare("SELECT * FROM package_itinerary WHERE package_id = ? ORDER BY day_number");
$itinStmt->execute([$pkg['id']]);
$itinerary = $itinStmt->fetchAll();

// Related packages
$related = $db->prepare("
    SELECT p.*, c.name AS cat_name, MIN(pp.price) AS min_price
    FROM packages p
    LEFT JOIN categories c ON c.id = p.category_id
    LEFT JOIN package_prices pp ON pp.package_id = p.id
    WHERE p.category_id = ? AND p.id != ? AND p.status = 'published' AND p.departure_date >= CURDATE()
    GROUP BY p.id ORDER BY p.departure_date ASC LIMIT 4
");
$related->execute([$pkg['category_id'], $pkg['id']]);
$relatedPkgs = $related->fetchAll();

// WhatsApp message
$waNumber = getSetting('whatsapp', '919911446919');
$basePrice = $priceMap['Double'] ?? $priceMap['Triple'] ?? $priceMap['Quad'] ?? 0;
$waTemplate = getSetting('wa_package_template', 'Assalamualaikum, I am interested in {package_name} (Departure {departure_date}, {price} per person, {sharing} Sharing). Link: {url}');
$waMsg = strtr($waTemplate, [
    '{package_name}'   => $pkg['title'],
    '{departure_date}' => date('d M Y', strtotime($pkg['departure_date'])),
    '{price}'          => formatINR((float)$basePrice),
    '{sharing}'        => 'Double',
    '{url}'            => SITE_URL . '/umrah-packages/' . $pkg['slug'],
]);
$waUrl    = waUrl($waNumber, $waMsg);
$cbWaMsg  = 'Assalamualaikum, I would like a call back regarding ' . $pkg['title'] . '. Please contact me.';
$cbWaUrl  = waUrl($waNumber, $cbWaMsg);

// SEO
$pageTitle   = $pkg['seo_title'] ?: ($pkg['title'] . ' – Shahin Travels');
$metaDesc    = $pkg['seo_description'] ?: $pkg['short_description'];
$ogTitle     = $pkg['og_title'] ?: $pageTitle;
$ogDesc      = $pkg['og_description'] ?: $metaDesc;
$ogImage     = $pkg['og_image'] ? SITE_URL . '/public/images/' . $pkg['og_image'] : SITE_URL . '/public/images/general/og-default.jpg';
$canonicalUrl= SITE_URL . '/umrah-packages/' . $pkg['slug'];
$noindex     = $pkg['noindex'];

// Handle callback form submission
$callbackMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['callback_submit'])) {
    if (csrf_verify()) {
        $name  = htmlspecialchars(trim($_POST['cb_name'] ?? ''), ENT_QUOTES, 'UTF-8');
        $phone = htmlspecialchars(trim($_POST['cb_phone'] ?? ''), ENT_QUOTES, 'UTF-8');
        if ($name && $phone) {
            $ins = $db->prepare("INSERT INTO enquiries (type, name, phone, package_id, ip_address) VALUES ('callback', ?, ?, ?, ?)");
            $ins->execute([$name, $phone, $pkg['id'], $_SERVER['REMOTE_ADDR']]);
            $callbackMsg = 'success';
        } else {
            $callbackMsg = 'error';
        }
    }
}

// Schema
$schemaData = [
    '@context'    => 'https://schema.org',
    '@type'       => 'Product',
    'name'        => $pkg['title'],
    'description' => $pkg['short_description'],
    'url'         => $canonicalUrl,
    'offers'      => [
        '@type'         => 'Offer',
        'price'         => $basePrice,
        'priceCurrency' => 'INR',
        'availability'  => 'https://schema.org/InStock',
        'validFrom'     => $pkg['departure_date'],
    ],
    'seller'  => ['@type' => 'Organization', 'name' => 'Shahin Travels'],
    'image'   => $ogImage,
];
$schema = json_encode($schemaData, JSON_UNESCAPED_SLASHES);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-banner">
    <div class="container">
        <nav class="breadcrumb" aria-label="Breadcrumb">
            <a href="<?= SITE_URL ?>/">Home</a>
            <span class="sep">›</span>
            <a href="<?= SITE_URL ?>/umrah-packages">Umrah Packages</a>
            <span class="sep">›</span>
            <span class="current"><?= e($pkg['title']) ?></span>
        </nav>
        <h1><?= e($pkg['title']) ?></h1>
    </div>
</div>

<section class="section-sm">
    <div class="container">
        <div class="detail-layout">
            <!-- Main Content -->
            <div class="detail-main">
                <!-- Gallery -->
                <div class="gallery-main" id="gallery-main">
                    <?php $mainImg = !empty($gallery) ? SITE_URL . '/public/images/packages/' . $gallery[0]['image_path'] : 'https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?w=900&q=80'; ?>
                    <img src="<?= e($mainImg) ?>" alt="<?= e($pkg['title']) ?>" id="gallery-main-img">
                </div>
                <?php if (count($gallery) > 1): ?>
                <div class="gallery-thumbs" id="gallery-thumbs">
                    <?php foreach ($gallery as $i => $img): ?>
                    <div class="gallery-thumb <?= $i === 0 ? 'active' : '' ?>">
                        <img src="<?= e(SITE_URL . '/public/images/packages/' . $img['image_path']) ?>" alt="<?= e($img['alt_text'] ?: $pkg['title']) ?>" loading="lazy">
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <!-- Lightbox -->
                <div class="lightbox" id="lightbox" role="dialog" aria-modal="true">
                    <button class="lightbox-close" aria-label="Close">✕</button>
                    <button class="lightbox-prev" aria-label="Previous">‹</button>
                    <img class="lightbox-img" src="" alt="<?= e($pkg['title']) ?>">
                    <button class="lightbox-next" aria-label="Next">›</button>
                </div>

                <!-- Tabs -->
                <div class="detail-tabs">
                    <div class="tab-nav" role="tablist">
                        <button class="tab-btn active" data-tab="overview" role="tab">Overview</button>
                        <button class="tab-btn" data-tab="itinerary" role="tab">Itinerary</button>
                        <button class="tab-btn" data-tab="hotels" role="tab">Hotels</button>
                        <button class="tab-btn" data-tab="inclusions" role="tab">Inclusions</button>
                        <button class="tab-btn" data-tab="info" role="tab">Important Info</button>
                    </div>

                    <div id="tab-overview" class="tab-content active" role="tabpanel">
                        <h2 style="font-size:1.3rem;margin-bottom:16px;">Package Overview</h2>
                        <?php if ($pkg['overview']): ?>
                        <div style="color:#444;line-height:1.8;"><?= nl2br(e($pkg['overview'])) ?></div>
                        <?php endif; ?>

                        <?php $highlights = json_decode($pkg['highlights'] ?? '[]', true); ?>
                        <?php if (!empty($highlights)): ?>
                        <h3 style="margin:24px 0 12px;font-size:1.1rem;">✨ Package Highlights</h3>
                        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px;">
                            <?php foreach ($highlights as $h): ?>
                            <div style="display:flex;align-items:center;gap:10px;background:var(--green-bg);padding:12px 14px;border-radius:8px;font-size:.875rem;color:var(--green-dark);">
                                <span style="color:var(--green);">✓</span> <?= e($h) ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>

                        <!-- Flight Details -->
                        <?php $flightData = json_decode($pkg['flight_details'] ?? '{}', true); ?>
                        <?php if (!empty($flightData)): ?>
                        <h3 style="margin:24px 0 12px;font-size:1.1rem;">✈️ Flight Details</h3>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                            <?php if (!empty($flightData['departure'])): ?>
                            <div style="background:#f9f9f7;border:1px solid #e8e8e8;border-radius:10px;padding:16px;">
                                <strong style="color:var(--green);display:block;margin-bottom:8px;">🛫 Departure Flight</strong>
                                <p style="font-size:.875rem;color:#444;"><?= nl2br(e($flightData['departure'])) ?></p>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($flightData['return'])): ?>
                            <div style="background:#f9f9f7;border:1px solid #e8e8e8;border-radius:10px;padding:16px;">
                                <strong style="color:var(--green);display:block;margin-bottom:8px;">🛬 Return Flight</strong>
                                <p style="font-size:.875rem;color:#444;"><?= nl2br(e($flightData['return'])) ?></p>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>

                        <!-- Price Table -->
                        <h3 style="margin:24px 0 12px;font-size:1.1rem;">💰 Package Price (Per Person)</h3>
                        <div style="overflow-x:auto;">
                        <table class="price-table">
                            <thead><tr><th>Room Type</th><th>Sharing</th><th>Price (INR)</th><th>Action</th></tr></thead>
                            <tbody>
                            <?php foreach ($priceRows as $pr):
                                $shMsg = strtr($waMsg, [formatINR((float)$basePrice) => formatINR((float)$pr['price']), 'Double' => $pr['sharing_type']]);
                                $shWa  = waUrl($waNumber, strtr($waTemplate, [
                                    '{package_name}'   => $pkg['title'],
                                    '{departure_date}' => date('d M Y', strtotime($pkg['departure_date'])),
                                    '{price}'          => formatINR((float)$pr['price']),
                                    '{sharing}'        => $pr['sharing_type'],
                                    '{url}'            => SITE_URL . '/umrah-packages/' . $pkg['slug'],
                                ]));
                            ?>
                            <tr>
                                <td><?= $pr['sharing_type'] === 'Quad' ? '4-bed' : ($pr['sharing_type'] === 'Triple' ? '3-bed' : '2-bed') ?> Room</td>
                                <td><?= e($pr['sharing_type']) ?> Sharing</td>
                                <td class="price-cell"><?= formatINR((float)$pr['price']) ?></td>
                                <td><a href="<?= e($shWa) ?>" class="btn btn-wa btn-sm" target="_blank" rel="noopener">Send Enquiry →</a></td>
                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                        </div>
                    </div>

                    <div id="tab-itinerary" class="tab-content" role="tabpanel">
                        <h2 style="font-size:1.3rem;margin-bottom:20px;">Day-wise Itinerary</h2>
                        <?php if (!empty($itinerary)): ?>
                        <div style="display:flex;flex-direction:column;gap:16px;">
                            <?php foreach ($itinerary as $day): ?>
                            <div style="background:var(--white);border:1px solid var(--gray-200);border-radius:var(--radius);padding:20px;border-left:4px solid var(--green);">
                                <div style="display:flex;gap:12px;align-items:flex-start;">
                                    <div style="background:var(--green);color:var(--white);min-width:42px;height:42px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.85rem;flex-shrink:0;">D<?= $day['day_number'] ?></div>
                                    <div>
                                        <h3 style="font-size:1rem;margin-bottom:6px;"><?= e($day['title']) ?></h3>
                                        <p style="font-size:.875rem;color:#555;line-height:1.7;"><?= nl2br(e($day['description'] ?? '')) ?></p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php else: ?>
                        <p style="color:#666;">Detailed itinerary will be shared upon booking.</p>
                        <?php endif; ?>
                    </div>

                    <div id="tab-hotels" class="tab-content" role="tabpanel">
                        <h2 style="font-size:1.3rem;margin-bottom:20px;">Hotel Details</h2>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
                            <?php if ($pkg['makkah_hotel']): ?>
                            <div style="background:var(--white);border:1px solid var(--gray-200);border-radius:var(--radius);overflow:hidden;">
                                <?php if ($pkg['makkah_img']): ?>
                                <img src="<?= e(SITE_URL . '/public/images/hotels/' . $pkg['makkah_img']) ?>" alt="<?= e($pkg['makkah_hotel']) ?>" style="width:100%;height:150px;object-fit:cover;" loading="lazy">
                                <?php else: ?>
                                <img src="https://images.unsplash.com/photo-1564769625905-50e93615e769?w=500&q=70" alt="<?= e($pkg['makkah_hotel']) ?>" style="width:100%;height:150px;object-fit:cover;" loading="lazy">
                                <?php endif; ?>
                                <div style="padding:16px;">
                                    <h3 style="font-size:1rem;margin-bottom:6px;">🕋 <?= e($pkg['makkah_hotel']) ?></h3>
                                    <div style="color:var(--gold);margin-bottom:6px;"><?= str_repeat('★', $pkg['makkah_stars'] ?? 3) ?></div>
                                    <p style="font-size:.8rem;color:#666;">📍 <?= $pkg['makkah_dist'] ?>m from Haram · <?= $pkg['makkah_nights'] ?> Nights</p>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if ($pkg['madinah_hotel']): ?>
                            <div style="background:var(--white);border:1px solid var(--gray-200);border-radius:var(--radius);overflow:hidden;">
                                <?php if ($pkg['madinah_img']): ?>
                                <img src="<?= e(SITE_URL . '/public/images/hotels/' . $pkg['madinah_img']) ?>" alt="<?= e($pkg['madinah_hotel']) ?>" style="width:100%;height:150px;object-fit:cover;" loading="lazy">
                                <?php else: ?>
                                <img src="https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=500&q=70" alt="<?= e($pkg['madinah_hotel']) ?>" style="width:100%;height:150px;object-fit:cover;" loading="lazy">
                                <?php endif; ?>
                                <div style="padding:16px;">
                                    <h3 style="font-size:1rem;margin-bottom:6px;">🕌 <?= e($pkg['madinah_hotel']) ?></h3>
                                    <div style="color:var(--gold);margin-bottom:6px;"><?= str_repeat('★', $pkg['madinah_stars'] ?? 3) ?></div>
                                    <p style="font-size:.8rem;color:#666;">📍 <?= $pkg['madinah_dist'] ?>m from Nabawi · <?= $pkg['madinah_nights'] ?> Nights</p>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div id="tab-inclusions" class="tab-content" role="tabpanel">
                        <?php
                        $inclusions = json_decode($pkg['inclusions'] ?? '[]', true);
                        $exclusions = json_decode($pkg['exclusions'] ?? '[]', true);
                        ?>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;">
                            <div>
                                <h3 style="color:var(--green);margin-bottom:14px;">✅ What's Included</h3>
                                <?php if (!empty($inclusions)): ?>
                                <ul style="display:flex;flex-direction:column;gap:8px;">
                                    <?php foreach ($inclusions as $inc): ?>
                                    <li style="display:flex;gap:8px;align-items:flex-start;font-size:.875rem;color:#444;">
                                        <span style="color:var(--green);font-weight:700;flex-shrink:0;">✓</span> <?= e($inc) ?>
                                    </li>
                                    <?php endforeach; ?>
                                </ul>
                                <?php else: ?>
                                <p style="color:#666;font-size:.875rem;">Inclusions will be listed here.</p>
                                <?php endif; ?>
                            </div>
                            <div>
                                <h3 style="color:#e53935;margin-bottom:14px;">❌ Not Included</h3>
                                <?php if (!empty($exclusions)): ?>
                                <ul style="display:flex;flex-direction:column;gap:8px;">
                                    <?php foreach ($exclusions as $exc): ?>
                                    <li style="display:flex;gap:8px;align-items:flex-start;font-size:.875rem;color:#444;">
                                        <span style="color:#e53935;font-weight:700;flex-shrink:0;">✕</span> <?= e($exc) ?>
                                    </li>
                                    <?php endforeach; ?>
                                </ul>
                                <?php else: ?>
                                <p style="color:#666;font-size:.875rem;">Exclusions will be listed here.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div id="tab-info" class="tab-content" role="tabpanel">
                        <h2 style="font-size:1.3rem;margin-bottom:16px;">Important Information</h2>
                        <?php if ($pkg['important_info']): ?>
                        <div style="color:#444;line-height:1.8;font-size:.9rem;"><?= nl2br(e($pkg['important_info'])) ?></div>
                        <?php else: ?>
                        <p style="color:#666;">Important information will be shared by our team.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Sidebar Booking Card -->
            <aside class="detail-sidebar">
                <div class="booking-card">
                    <?php if ($pkg['cat_name']): ?>
                    <span class="badge badge-<?= strtolower($pkg['cat_name']) ?> category-label"><?= e($pkg['cat_name']) ?> Category</span>
                    <?php endif; ?>
                    <h3 style="margin-top:10px;"><?= e($pkg['title']) ?></h3>
                    <div class="booking-meta">
                        <div class="booking-meta-item">
                            <span class="meta-label">📅 Duration</span>
                            <span class="meta-value"><?= $pkg['days'] ?> Days / <?= $pkg['nights'] ?> Nights</span>
                        </div>
                        <div class="booking-meta-item">
                            <span class="meta-label">✈️ Departure</span>
                            <span class="meta-value"><?= date('d M Y', strtotime($pkg['departure_date'])) ?></span>
                        </div>
                        <div class="booking-meta-item">
                            <span class="meta-label">🛬 Return</span>
                            <span class="meta-value"><?= date('d M Y', strtotime($pkg['return_date'])) ?></span>
                        </div>
                        <div class="booking-meta-item">
                            <span class="meta-label">🏙️ Departure From</span>
                            <span class="meta-value"><?= e($pkg['departure_city']) ?></span>
                        </div>
                        <div class="booking-meta-item">
                            <span class="meta-label">✈️ Airline</span>
                            <span class="meta-value"><?= e($pkg['airline'] ?? 'Saudi Airlines') ?></span>
                        </div>
                        <?php if ($pkg['makkah_hotel']): ?>
                        <div class="booking-meta-item">
                            <span class="meta-label">🕋 Makkah</span>
                            <span class="meta-value" style="font-size:.8rem;"><?= e($pkg['makkah_hotel']) ?>, <?= $pkg['makkah_nights'] ?>N</span>
                        </div>
                        <?php endif; ?>
                        <?php if ($pkg['madinah_hotel']): ?>
                        <div class="booking-meta-item">
                            <span class="meta-label">🕌 Madinah</span>
                            <span class="meta-value" style="font-size:.8rem;"><?= e($pkg['madinah_hotel']) ?>, <?= $pkg['madinah_nights'] ?>N</span>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="booking-price">
                        <div class="from">Starting from</div>
                        <div class="amount"><?= formatINR((float)$basePrice) ?></div>
                        <div class="per">per person (Double Sharing)</div>
                    </div>
                    <a href="<?= e($waUrl) ?>" class="btn btn-wa" target="_blank" rel="noopener">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                        Enquire on WhatsApp
                    </a>
                    <!-- Callback Form -->
                    <div style="margin-top:12px;border-top:1px solid var(--gray-100);padding-top:14px;">
                        <h4 style="font-size:.9rem;margin-bottom:10px;color:var(--green-dark);">📞 Get a Call Back</h4>
                        <?php if ($callbackMsg === 'success'): ?>
                        <div class="alert alert-success">
                            ✓ Request sent! We'll call you shortly.
                            <a href="<?= e($cbWaUrl) ?>" class="btn btn-wa btn-sm" style="margin-top:8px;display:inline-flex;" target="_blank" rel="noopener">Send on WhatsApp →</a>
                        </div>
                        <?php else: ?>
                        <form method="POST" action="">
                            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                            <input type="hidden" name="callback_submit" value="1">
                            <?php if ($callbackMsg === 'error'): ?>
                            <div class="alert alert-error">Please fill in all fields.</div>
                            <?php endif; ?>
                            <div class="form-group" style="margin-bottom:10px;">
                                <input type="text" name="cb_name" class="form-control" placeholder="Your Name" required autocomplete="name">
                            </div>
                            <div class="form-group" style="margin-bottom:10px;">
                                <input type="tel" name="cb_phone" class="form-control" placeholder="Phone Number" required autocomplete="tel">
                            </div>
                            <!-- Honeypot -->
                            <input type="text" name="website" style="display:none;" tabindex="-1" autocomplete="off">
                            <button type="submit" class="btn btn-outline-green btn-sm" style="width:100%;justify-content:center;">Request Call Back</button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Share -->
                <div style="background:var(--white);border-radius:var(--radius);padding:16px;border:1px solid var(--gray-200);">
                    <h4 style="font-size:.875rem;margin-bottom:10px;color:var(--green-dark);">🔗 Share This Package</h4>
                    <div style="display:flex;gap:8px;flex-wrap:wrap;">
                        <a href="<?= e($waUrl) ?>" class="share-btn share-wa" target="_blank" rel="noopener">📱 WhatsApp</a>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?= rawurlencode($canonicalUrl) ?>" class="share-btn share-fb" target="_blank" rel="noopener">Facebook</a>
                        <button class="share-btn share-copy" onclick="copyToClipboard('<?= e($canonicalUrl) ?>',this)">📋 Copy Link</button>
                    </div>
                </div>
            </aside>
        </div>

        <!-- Related Packages -->
        <?php if (!empty($relatedPkgs)): ?>
        <div style="margin-top:60px;">
            <h2 style="font-size:1.5rem;margin-bottom:24px;">Related Packages</h2>
            <div class="packages-grid">
                <?php foreach ($relatedPkgs as $rp):
                    $rBadge   = 'badge-' . strtolower($rp['cat_name'] ?? 'budget');
                    $rPrice   = $rp['min_price'] ?? 0;
                ?>
                <div class="package-card">
                    <div class="package-card-image">
                        <img src="<?= $rp['cover_image'] ? e(SITE_URL . '/public/images/packages/' . $rp['cover_image']) : 'https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?w=600&q=70' ?>" alt="<?= e($rp['title']) ?>" loading="lazy">
                        <span class="badge <?= e($rBadge) ?>"><?= e($rp['cat_name']) ?></span>
                    </div>
                    <div class="package-card-body">
                        <h3><?= e($rp['title']) ?></h3>
                        <div class="package-meta">
                            <div class="package-meta-item">📅 Departure: <?= date('d M Y', strtotime($rp['departure_date'])) ?></div>
                        </div>
                    </div>
                    <div class="package-card-footer">
                        <div>
                            <div class="price-label">From</div>
                            <div class="price-amount"><?= formatINR((float)$rPrice) ?></div>
                        </div>
                        <a href="<?= SITE_URL ?>/umrah-packages/<?= e($rp['slug']) ?>" class="btn btn-primary btn-sm">View →</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php
$pageScripts = "document.addEventListener('DOMContentLoaded', function(){ initGallery(); initDetailTabs(); });";
require_once __DIR__ . '/../includes/footer.php';
?>

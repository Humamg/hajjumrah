<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
$db = getDB();

$slug = $_GET['slug'] ?? '';
$stmt = $db->prepare("SELECT bp.*, bc.name AS cat_name, bc.slug AS cat_slug FROM blog_posts bp LEFT JOIN blog_categories bc ON bc.id=bp.category_id WHERE bp.slug=? AND bp.status='published'");
$stmt->execute([$slug]);
$post = $stmt->fetch();

if (!$post) { http_response_code(404); $pageTitle='Not Found'; require_once __DIR__.'/../includes/header.php'; echo '<div class="container" style="padding:100px 20px;text-align:center;"><h1>Article Not Found</h1><a href="'.SITE_URL.'/blog" class="btn btn-primary" style="margin-top:16px;">Back to Blog</a></div>'; require_once __DIR__.'/../includes/footer.php'; exit; }

// Related
$related = $db->prepare("SELECT * FROM blog_posts WHERE category_id=? AND id!=? AND status='published' ORDER BY published_at DESC LIMIT 3");
$related->execute([$post['category_id'], $post['id']]);
$related = $related->fetchAll();

$pageTitle   = $post['seo_title'] ?: ($post['title'] . ' – Shahin Travels Blog');
$metaDesc    = $post['seo_description'] ?: $post['excerpt'];
$canonicalUrl= SITE_URL . '/blog/' . $post['slug'];
$ogImage     = $post['og_image'] ? SITE_URL.'/public/images/'.$post['og_image'] : ($post['featured_image'] ? SITE_URL.'/public/images/blog/'.$post['featured_image'] : SITE_URL.'/public/images/general/og-default.jpg');

$schema = json_encode(['@context'=>'https://schema.org','@type'=>'BlogPosting','headline'=>$post['title'],'description'=>$post['excerpt'],'image'=>$ogImage,'datePublished'=>$post['published_at'],'author'=>['@type'=>'Organization','name'=>'Shahin Travels'],'publisher'=>['@type'=>'Organization','name'=>'Shahin Travels']],JSON_UNESCAPED_SLASHES);
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-banner">
    <div class="container">
        <nav class="breadcrumb"><a href="<?=SITE_URL?>/">Home</a><span class="sep">›</span><a href="<?=SITE_URL?>/blog">Blog</a><?php if($post['cat_name']): ?><span class="sep">›</span><a href="<?=SITE_URL?>/blog?cat=<?=e($post['cat_slug'])?>"><?=e($post['cat_name'])?></a><?php endif; ?><span class="sep">›</span><span class="current"><?=e(mb_strimwidth($post['title'],0,40,'...'))?></span></nav>
        <h1 style="font-size:clamp(1.4rem,3vw,2.2rem);"><?=e($post['title'])?></h1>
        <p>📅 <?=date('d M Y',strtotime($post['published_at']??'now'))?><?=$post['cat_name']?' &nbsp;•&nbsp; '.$post['cat_name']:''?></p>
    </div>
</div>
<section class="section-sm">
    <div class="container">
        <div style="display:grid;grid-template-columns:1fr 280px;gap:40px;align-items:start;">
            <article>
                <?php if($post['featured_image']): ?>
                <img src="<?=e(SITE_URL.'/public/images/blog/'.$post['featured_image'])?>" alt="<?=e($post['title'])?>" style="width:100%;border-radius:var(--radius);margin-bottom:28px;max-height:420px;object-fit:cover;" loading="lazy">
                <?php endif; ?>
                <div style="font-size:.9rem;line-height:1.9;color:#333;"><?=$post['content']?></div>
                <!-- Share -->
                <div style="margin-top:32px;padding-top:20px;border-top:1px solid var(--gray-200);display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
                    <span style="font-size:.875rem;font-weight:600;color:var(--gray-800);">Share:</span>
                    <a href="https://wa.me/?text=<?=rawurlencode($post['title'].' '.SITE_URL.'/blog/'.$post['slug'])?>" class="btn btn-wa btn-sm" target="_blank" rel="noopener">📱 WhatsApp</a>
                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?=rawurlencode($canonicalUrl)?>" class="share-btn share-fb" target="_blank" rel="noopener">Facebook</a>
                    <button class="share-btn share-copy" onclick="copyToClipboard('<?=e($canonicalUrl)?>',this)">📋 Copy Link</button>
                </div>
                <!-- Back -->
                <a href="<?=SITE_URL?>/blog" style="display:inline-flex;align-items:center;gap:6px;margin-top:24px;color:var(--green);font-size:.875rem;font-weight:600;">← Back to Blog</a>

                <!-- Related -->
                <?php if(!empty($related)): ?>
                <div style="margin-top:48px;">
                    <h3 style="font-size:1.1rem;margin-bottom:18px;">Related Articles</h3>
                    <div class="blog-grid" style="grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px;">
                        <?php foreach($related as $rp): ?>
                        <a href="<?=SITE_URL?>/blog/<?=e($rp['slug'])?>" style="text-decoration:none;">
                            <div class="blog-card">
                                <div class="blog-card-image">
                                    <img src="<?=$rp['featured_image']?e(SITE_URL.'/public/images/blog/'.$rp['featured_image']):'https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?w=400&q=70'?>" alt="<?=e($rp['title'])?>" loading="lazy">
                                </div>
                                <div class="blog-card-body">
                                    <div class="blog-card-date">📅 <?=date('d M Y',strtotime($rp['published_at']??'now'))?></div>
                                    <h3 style="font-size:.9rem;"><?=e($rp['title'])?></h3>
                                </div>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </article>

            <!-- Sidebar -->
            <aside style="position:sticky;top:90px;">
                <?php $waMsg = 'Assalamualaikum, I read your article "' . $post['title'] . '" and would like to enquire about Umrah packages.'; ?>
                <div class="card" style="margin-bottom:20px;">
                    <h3 style="font-size:.95rem;margin-bottom:10px;">🕌 Planning Your Umrah?</h3>
                    <p style="font-size:.8rem;color:#666;margin-bottom:14px;">Let our experts help you plan the perfect Umrah package at the best price.</p>
                    <a href="<?=e(waUrl(getSetting('whatsapp','919911446919'),$waMsg))?>" class="btn btn-wa btn-sm" target="_blank" rel="noopener" style="width:100%;justify-content:center;">💬 Chat on WhatsApp</a>
                    <a href="<?=SITE_URL?>/umrah-packages" class="btn btn-primary btn-sm" style="width:100%;justify-content:center;margin-top:8px;">View Packages →</a>
                </div>
            </aside>
        </div>
    </div>
</section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<?php
// ============================================================
// Shahin Travels – Cancellation & Refund Policy (pages/cancellation.php)
// ============================================================
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

$db = getDB();
$pageData = $db->query("SELECT * FROM pages WHERE page_key = 'cancellation'")->fetch();

$pageTitle    = $pageData['seo_title'] ?? 'Cancellation and Refund Policy – Shahin Travels';
$metaDesc     = $pageData['seo_description'] ?? 'Cancellation and Refund Policy for Hajj and Umrah package bookings with Shahin Travels. Read timeline, deductions, and refund procedures.';
$canonicalUrl = SITE_URL . '/cancellation-policy';
$noindex      = !empty($pageData['noindex']);

$schema = json_encode([
    '@context' => 'https://schema.org',
    '@type'    => 'WebPage',
    'name'     => $pageTitle,
    'url'      => $canonicalUrl,
    'breadcrumb' => [
        '@type' => 'BreadcrumbList',
        'itemListElement' => [
            ['@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => SITE_URL . '/'],
            ['@type' => 'ListItem', 'position' => 2, 'name' => 'Cancellation Policy', 'item' => $canonicalUrl]
        ]
    ]
], JSON_UNESCAPED_SLASHES);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-banner">
    <div class="container">
        <nav class="breadcrumb" aria-label="Breadcrumb">
            <a href="<?= SITE_URL ?>/">Home</a>
            <span class="sep">/</span>
            <span class="current">Cancellation Policy</span>
        </nav>
        <h1>Cancellation & Refund Policy</h1>
        <p>Clear, transparent cancellation terms and refund timelines for all pilgrimage bookings.</p>
    </div>
</div>

<section class="section">
    <div class="container" style="max-width:860px;">
        <div style="background:var(--white); border-radius:16px; padding:40px; box-shadow:var(--shadow-sm); line-height:1.8; color:var(--gray-700);">
            
            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">1. Notice of Cancellation</h2>
            <p style="margin-bottom:20px;">
                All requests for cancellation must be communicated in writing via registered email to <strong><?= e(getSetting('email', 'info@shahintravels.in')) ?></strong> or via WhatsApp from the registered pilgrim's primary phone number. The date on which the written request is received serves as the official cancellation date.
            </p>

            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">2. Standard Cancellation Fee Schedule</h2>
            <p style="margin-bottom:16px;">Because group tickets, visas, and hotel reservations in Makkah and Madinah are pre-purchased in Saudi Riyals, cancellation deductions apply as follows:</p>

            <div style="overflow-x:auto; margin-bottom:24px;">
                <table style="width:100%; border-collapse:collapse; text-align:left; font-size:0.95rem;">
                    <thead>
                        <tr style="background:var(--green-dark); color:var(--white);">
                            <th style="padding:12px 16px; border-radius:8px 0 0 0;">Cancellation Timing</th>
                            <th style="padding:12px 16px; border-radius:0 8px 0 0;">Applicable Deductions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr style="border-bottom:1px solid var(--gray-200);">
                            <td style="padding:12px 16px;"><strong>30 days or more</strong> prior to departure</td>
                            <td style="padding:12px 16px;">Registration & administrative charge only (Rs. 5,000 per person) + non-refundable visa fees if already processed.</td>
                        </tr>
                        <tr style="border-bottom:1px solid var(--gray-200); background:var(--cream);">
                            <td style="padding:12px 16px;"><strong>29 to 15 days</strong> prior to departure</td>
                            <td style="padding:12px 16px;">25% of total package cost + air ticket airline cancellation fee.</td>
                        </tr>
                        <tr style="border-bottom:1px solid var(--gray-200);">
                            <td style="padding:12px 16px;"><strong>14 to 7 days</strong> prior to departure</td>
                            <td style="padding:12px 16px;">50% of total package cost.</td>
                        </tr>
                        <tr style="background:var(--cream);">
                            <td style="padding:12px 16px;"><strong>Less than 7 days</strong> or No-Show</td>
                            <td style="padding:12px 16px; color:#c0392b;">100% of package cost (Non-refundable).</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">3. Non-Refundable Items</h2>
            <ul style="margin-left:24px; margin-bottom:20px;">
                <li><strong>Saudi Umrah Visa Fee:</strong> Once an e-Visa or visa endorsement is processed on the Ministry portal, the fee is 100% non-refundable under Saudi government policy.</li>
                <li><strong>Group Flight Tickets:</strong> Certain special group fares or charter flights are strictly non-refundable and subject to airline rules.</li>
                <li><strong>Peak Season Hotels:</strong> Bookings for Ramadan or high-demand seasons carry 100% non-refundable hotel commitments once confirmed.</li>
            </ul>

            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">4. Refund Processing Timeline</h2>
            <p style="margin-bottom:20px;">
                Approved refunds will be processed via original payment mode (Bank Transfer / Cheque) within <strong>14 to 21 business days</strong> following completion of airline and hotel credit reconciliation.
            </p>

            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">5. Pilgrim Replacement</h2>
            <p style="margin-bottom:20px;">
                If you are unable to travel due to an emergency, you may request to transfer your hotel reservation to another direct family member, subject to visa processing time and airline name change feasibility.
            </p>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

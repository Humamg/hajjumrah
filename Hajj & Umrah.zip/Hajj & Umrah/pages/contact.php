<?php
// Contact Us Page
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

$db = getDB();
$waNumber = getSetting('whatsapp', '919911446919');
$phone    = getSetting('phone', '+91 99114 46919');
$email    = getSetting('email', 'info@shahintravels.in');
$address  = getSetting('address', 'Shaheen Bagh, New Delhi - 110025');
$hours    = getSetting('office_hours', 'Mon-Sat: 10:00 AM – 8:00 PM | Sunday: Closed');

$formMsg   = '';
$submitted = false;
$formData  = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_submit'])) {
    if (!csrf_verify()) {
        $formMsg = 'error:Security token invalid.';
    } elseif (!empty($_POST['website'])) {
        $formMsg = 'error:Bot detected.';
    } else {
        $name     = htmlspecialchars(trim($_POST['name'] ?? ''), ENT_QUOTES, 'UTF-8');
        $phn      = htmlspecialchars(trim($_POST['phone'] ?? ''), ENT_QUOTES, 'UTF-8');
        $eml      = htmlspecialchars(trim($_POST['email_field'] ?? ''), ENT_QUOTES, 'UTF-8');
        $enqType  = htmlspecialchars(trim($_POST['enquiry_type'] ?? ''), ENT_QUOTES, 'UTF-8');
        $prefMonth= htmlspecialchars(trim($_POST['preferred_month'] ?? ''), ENT_QUOTES, 'UTF-8');
        $msg      = htmlspecialchars(trim($_POST['message'] ?? ''), ENT_QUOTES, 'UTF-8');

        if ($name && $phn) {
            $ins = $db->prepare("INSERT INTO enquiries (type,name,phone,email,enquiry_type,preferred_month,message,ip_address) VALUES ('contact',?,?,?,?,?,?,?)");
            $ins->execute([$name, $phn, $eml, $enqType, $prefMonth, $msg, $_SERVER['REMOTE_ADDR']]);
            $submitted = true;
            $formData  = compact('name', 'phn', 'eml', 'enqType', 'prefMonth', 'msg');
        } else {
            $formMsg = 'error:Please fill in Name and Phone Number.';
        }
    }
}

$waContactMsg = 'Assalamualaikum, I would like to enquire about your Umrah packages. Please help me.';
$waUrl = waUrl($waNumber, $waContactMsg);

$pageTitle  = 'Contact Us – Shahin Travels';
$metaDesc   = 'Get in touch with Shahin Travels for Umrah package enquiries. Call, WhatsApp or email us. Office in Shaheen Bagh, New Delhi.';
$canonicalUrl = SITE_URL . '/contact-us';

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-banner">
    <div class="container">
        <nav class="breadcrumb" aria-label="Breadcrumb">
            <a href="<?= SITE_URL ?>/">Home</a>
            <span class="sep">›</span>
            <span class="current">Contact Us</span>
        </nav>
        <h1>Contact Us</h1>
        <p>We are here to help you. Get in touch for Umrah packages, enquiries or assistance.</p>
    </div>
</div>

<section class="section-sm">
    <div class="container">
        <div style="display:grid;grid-template-columns:1fr 420px;gap:40px;align-items:start;">
            <!-- Contact Info -->
            <div>
                <div class="card" style="margin-bottom:24px;">
                    <h2 style="font-size:1.4rem;margin-bottom:20px;color:var(--green-dark);">Get in Touch</h2>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                        <a href="tel:<?= preg_replace('/\D/', '', $phone) ?>" style="display:flex;gap:14px;align-items:center;background:var(--green-bg);border-radius:var(--radius);padding:20px;transition:all .3s;">
                            <div style="font-size:1.6rem;">📞</div>
                            <div>
                                <div style="font-size:.75rem;color:var(--green);font-weight:700;text-transform:uppercase;letter-spacing:.5px;">Phone / WhatsApp</div>
                                <div style="font-weight:700;color:var(--green-dark);font-size:.95rem;"><?= e($phone) ?></div>
                            </div>
                        </a>
                        <a href="<?= e($waUrl) ?>" target="_blank" rel="noopener" style="display:flex;gap:14px;align-items:center;background:#e8f9f0;border-radius:var(--radius);padding:20px;transition:all .3s;">
                            <div style="font-size:1.6rem;">💬</div>
                            <div>
                                <div style="font-size:.75rem;color:var(--wa-green);font-weight:700;text-transform:uppercase;letter-spacing:.5px;">WhatsApp</div>
                                <div style="font-weight:700;color:#1a7a3a;font-size:.95rem;">Chat with us</div>
                            </div>
                        </a>
                        <a href="mailto:<?= e($email) ?>" style="display:flex;gap:14px;align-items:center;background:#f0f7f4;border-radius:var(--radius);padding:20px;transition:all .3s;">
                            <div style="font-size:1.6rem;">✉️</div>
                            <div>
                                <div style="font-size:.75rem;color:var(--green);font-weight:700;text-transform:uppercase;letter-spacing:.5px;">Email</div>
                                <div style="font-weight:600;color:var(--green-dark);font-size:.875rem;"><?= e($email) ?></div>
                            </div>
                        </a>
                        <div style="display:flex;gap:14px;align-items:center;background:#f9f9f7;border-radius:var(--radius);padding:20px;">
                            <div style="font-size:1.6rem;">📍</div>
                            <div>
                                <div style="font-size:.75rem;color:var(--green);font-weight:700;text-transform:uppercase;letter-spacing:.5px;">Address</div>
                                <div style="font-size:.875rem;color:#444;"><?= e($address) ?></div>
                            </div>
                        </div>
                    </div>
                    <div style="margin-top:20px;padding-top:16px;border-top:1px solid var(--gray-100);">
                        <div style="display:flex;gap:10px;align-items:flex-start;">
                            <span style="font-size:1.2rem;">🕐</span>
                            <div>
                                <strong style="color:var(--green-dark);font-size:.875rem;">Office Hours</strong><br>
                                <span style="color:#666;font-size:.875rem;"><?= e($hours) ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Google Map placeholder -->
                <div style="background:var(--gray-100);border-radius:var(--radius);height:300px;display:flex;align-items:center;justify-content:center;overflow:hidden;">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3505.7!2d77.29!3d28.52!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjjCsDMxJzEyLjAiTiA3N8KwMTcnMjQuMCJF!5e0!3m2!1sen!2sin!4v1000000000000!5m2!1sen!2sin"
                        width="100%" height="300" style="border:0;border-radius:var(--radius);" allowfullscreen="" loading="lazy" title="Shahin Travels Office Location"></iframe>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="card">
                <h2 style="font-size:1.3rem;margin-bottom:20px;">Send us a Message</h2>

                <?php if ($submitted): ?>
                <div class="alert alert-success">
                    <span>✓</span> Your message has been sent successfully! We'll get back to you soon.
                </div>
                <?php
                // Build WhatsApp follow-up link
                $submittedWaMsg = "Assalamualaikum, I just submitted an enquiry:\nName: {$formData['name']}\nPhone: {$formData['phn']}\nType: {$formData['enqType']}\nMessage: {$formData['msg']}";
                $submittedWaUrl = waUrl($waNumber, $submittedWaMsg);
                ?>
                <a href="<?= e($submittedWaUrl) ?>" class="btn btn-wa" target="_blank" rel="noopener" style="width:100%;justify-content:center;margin-top:10px;">
                    💬 Also Send on WhatsApp
                </a>
                <a href="<?= SITE_URL ?>/contact-us" style="display:block;text-align:center;margin-top:12px;color:var(--green);font-size:.875rem;">Send another message →</a>
                <?php else: ?>

                <?php if ($formMsg && str_starts_with($formMsg, 'error:')): ?>
                <div class="alert alert-error">⚠ <?= e(substr($formMsg, 6)) ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <input type="hidden" name="contact_submit" value="1">
                    <!-- Honeypot -->
                    <input type="text" name="website" style="display:none;" tabindex="-1" autocomplete="off">

                    <div class="form-group">
                        <label class="form-group label" for="contact-name">Your Name <span style="color:red;">*</span></label>
                        <input type="text" id="contact-name" name="name" class="form-control" placeholder="Your full name" required autocomplete="name">
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="contact-phone">Phone <span style="color:red;">*</span></label>
                            <input type="tel" id="contact-phone" name="phone" class="form-control" placeholder="+91 98765 43210" required autocomplete="tel">
                        </div>
                        <div class="form-group">
                            <label for="contact-email">Email</label>
                            <input type="email" id="contact-email" name="email_field" class="form-control" placeholder="your@email.com" autocomplete="email">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="contact-type">Enquiry Type</label>
                            <select id="contact-type" name="enquiry_type" class="form-control">
                                <option value="">Select type...</option>
                                <option>Umrah Package</option>
                                <option>Hajj Package</option>
                                <option>Visa Assistance</option>
                                <option>Hotel Booking</option>
                                <option>Group Package</option>
                                <option>General Enquiry</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="contact-month">Preferred Month</label>
                            <select id="contact-month" name="preferred_month" class="form-control">
                                <option value="">Select month...</option>
                                <?php for ($i = 0; $i < 12; $i++): $m = new DateTime("+$i months"); ?>
                                <option><?= $m->format('F Y') ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="contact-msg">Message</label>
                        <textarea id="contact-msg" name="message" class="form-control" rows="4" placeholder="Tell us about your requirements..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;">
                        Send Message →
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<?php
// ============================================================
// Shahin Travels – About Us (pages/about.php)
// ============================================================
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

$db = getDB();

// Fetch dynamic content from pages table if exists
$pageData = $db->query("SELECT * FROM pages WHERE page_key = 'about'")->fetch();

$pageTitle    = $pageData['seo_title'] ?? 'About Us – Shahin Travels | Trusted Hajj & Umrah Tour Operator';
$metaDesc     = $pageData['seo_description'] ?? 'Learn about Shahin Travels, India\'s trusted Hajj and Umrah travel specialists dedicated to guiding pilgrims with honesty, premium hotels, and complete spiritual care.';
$canonicalUrl = SITE_URL . '/about-us';
$ogTitle      = $pageData['og_title'] ?? $pageTitle;
$ogDesc       = $pageData['og_description'] ?? $metaDesc;
$ogImage      = $pageData['og_image'] ?? '';
$noindex      = !empty($pageData['noindex']);

// Breadcrumb Schema
$schema = json_encode([
    '@context' => 'https://schema.org',
    '@type'    => 'AboutPage',
    'name'     => 'About Shahin Travels',
    'description' => $metaDesc,
    'url'      => $canonicalUrl,
    'breadcrumb' => [
        '@type' => 'BreadcrumbList',
        'itemListElement' => [
            ['@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => SITE_URL . '/'],
            ['@type' => 'ListItem', 'position' => 2, 'name' => 'About Us', 'item' => $canonicalUrl]
        ]
    ]
], JSON_UNESCAPED_SLASHES);

$waNumber  = getSetting('whatsapp', '919911446919');
$waUrl     = waUrl($waNumber, 'Assalamualaikum, I would like to know more about Shahin Travels and your Umrah services.');

require_once __DIR__ . '/../includes/header.php';
?>

<!-- ── Breadcrumb & Page Banner ──────────────────────────── -->
<div class="page-banner">
    <div class="container">
        <nav class="breadcrumb" aria-label="Breadcrumb">
            <a href="<?= SITE_URL ?>/">Home</a>
            <span class="sep">/</span>
            <span class="current">About Us</span>
        </nav>
        <h1>About Shahin Travels</h1>
        <p>Serving the guests of Allah (Hujjaj & Mutamireen) with devotion, transparency, and exemplary care.</p>
    </div>
</div>

<!-- ── Company Overview Section ───────────────────────────── -->
<section class="section">
    <div class="container">
        <div class="about-grid" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap:48px; align-items:center;">
            <div class="about-content fade-up">
                <span class="badge" style="background:var(--gold-light); color:var(--gold-dark); margin-bottom:14px; font-weight:600;">Since 2012</span>
                <h2 style="font-size:2.2rem; color:var(--green-dark); margin-bottom:20px; line-height:1.3;">
                    Your Spiritual Journey,<br><span style="color:var(--gold);">Our Sacred Responsibility</span>
                </h2>
                <p style="font-size:1.05rem; line-height:1.8; color:var(--gray-700); margin-bottom:18px;">
                    Shahin Travels was founded with a profound vision: to ensure that every Muslim embarking on the sacred journey of Hajj or Umrah receives the highest standard of spiritual support, logistical reliability, and heartfelt hospitality.
                </p>
                <p style="font-size:1rem; line-height:1.8; color:var(--gray-600); margin-bottom:24px;">
                    From securing confirmed direct flights and premium star-rated hotels closest to the Holy Harams in Makkah and Madinah, to meticulous visa processing and personal on-ground guidance for ziyarats, we treat every pilgrim like family.
                </p>
                
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:30px;">
                    <div style="background:var(--cream); padding:16px; border-radius:12px; border-left:4px solid var(--green);">
                        <strong style="color:var(--green-dark); display:block; margin-bottom:4px;">Direct Airline Partnerships</strong>
                        <span style="font-size:0.88rem; color:var(--gray-600);">Scheduled flights with Saudi Airlines & trusted carriers.</span>
                    </div>
                    <div style="background:var(--cream); padding:16px; border-radius:12px; border-left:4px solid var(--gold);">
                        <strong style="color:var(--green-dark); display:block; margin-bottom:4px;">Hotels Walking Distance</strong>
                        <span style="font-size:0.88rem; color:var(--gray-600);">Close to Haram courtyards for effortless daily prayers.</span>
                    </div>
                </div>

                <a href="<?= e($waUrl) ?>" class="btn btn-wa btn-lg" target="_blank" rel="noopener">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                    Talk Directly to Our Directors
                </a>
            </div>

            <div class="about-visual fade-up" style="position:relative;">
                <div style="border-radius:20px; overflow:hidden; box-shadow:var(--shadow-xl); border:4px solid var(--white);">
                    <img src="https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?w=800&q=80" alt="Holy Kaaba Makkah" style="width:100%; height:460px; object-fit:cover; display:block;">
                </div>
                <div style="position:absolute; bottom:-20px; left:-20px; background:var(--green-dark); color:var(--white); padding:24px; border-radius:16px; box-shadow:var(--shadow-lg); border:1px solid rgba(212,168,83,0.3); max-width:240px;">
                    <div style="font-size:2rem; font-weight:700; color:var(--gold);">10,000+</div>
                    <div style="font-size:0.88rem; color:var(--gray-300);">Blessed Pilgrims Guided to the Two Holy Mosques</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ── Trust Numbers Counter ──────────────────────────────── -->
<section class="section" style="background:var(--green-dark); color:var(--white); padding:60px 0;">
    <div class="container">
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:32px; text-align:center;">
            <div class="stat-card">
                <div class="counter" data-target="12" style="font-size:3rem; font-weight:700; color:var(--gold); font-family:var(--font-serif);">12+</div>
                <div style="font-size:1.05rem; font-weight:600; margin-top:8px;">Years of Excellence</div>
                <p style="font-size:0.85rem; color:var(--gray-300); margin-top:4px;">Dedicated strictly to Hajj & Umrah services</p>
            </div>
            <div class="stat-card">
                <div class="counter" data-target="10500" style="font-size:3rem; font-weight:700; color:var(--gold); font-family:var(--font-serif);">10,500+</div>
                <div style="font-size:1.05rem; font-weight:600; margin-top:8px;">Happy Pilgrims</div>
                <p style="font-size:0.85rem; color:var(--gray-300); margin-top:4px;">Families & groups from all over India</p>
            </div>
            <div class="stat-card">
                <div class="counter" data-target="50" style="font-size:3rem; font-weight:700; color:var(--gold); font-family:var(--font-serif);">50+</div>
                <div style="font-size:1.05rem; font-weight:600; margin-top:8px;">Partnered Hotels</div>
                <p style="font-size:0.85rem; color:var(--gray-300); margin-top:4px;">Direct contracts in Makkah & Madinah</p>
            </div>
            <div class="stat-card">
                <div class="counter" data-target="100" style="font-size:3rem; font-weight:700; color:var(--gold); font-family:var(--font-serif);">100%</div>
                <div style="font-size:1.05rem; font-weight:600; margin-top:8px;">Visa Assurance</div>
                <p style="font-size:0.85rem; color:var(--gray-300); margin-top:4px;">Official Saudi Ministry authorized portal</p>
            </div>
        </div>
    </div>
</section>

<!-- ── Mission & Vision ──────────────────────────────────── -->
<section class="section">
    <div class="container">
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap:32px;">
            <div style="background:var(--white); border-radius:16px; padding:36px; box-shadow:var(--shadow-md); border-top:5px solid var(--green);">
                <div style="width:54px; height:54px; background:var(--green-light); border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:1.6rem; margin-bottom:20px;">
                    🎯
                </div>
                <h3 style="font-size:1.4rem; color:var(--green-dark); margin-bottom:14px;">Our Mission</h3>
                <p style="color:var(--gray-600); line-height:1.7;">
                    To deliver seamless, transparent, and spiritually enriching Umrah and Hajj journeys for every pilgrim. We eliminate travel stress and uncertainties by providing confirmed tickets, verified walking-distance accommodations, hygienic meals, and scholarly guidance every step of the way.
                </p>
            </div>

            <div style="background:var(--white); border-radius:16px; padding:36px; box-shadow:var(--shadow-md); border-top:5px solid var(--gold);">
                <div style="width:54px; height:54px; background:var(--gold-light); border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:1.6rem; margin-bottom:20px;">
                    👁️
                </div>
                <h3 style="font-size:1.4rem; color:var(--green-dark); margin-bottom:14px;">Our Vision</h3>
                <p style="color:var(--gray-600); line-height:1.7;">
                    To be India's most cherished and dependable Islamic pilgrimage travel partner, recognized globally for ethical values, exemplary customer devotion, and making the blessed pilgrimage accessible and dignified for all.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- ── Why Pilgrims Trust Us ─────────────────────────────── -->
<section class="section" style="background:var(--cream); padding:70px 0;">
    <div class="container">
        <div class="section-header fade-up" style="text-align:center; max-width:680px; margin:0 auto 48px;">
            <span class="label">Our Guiding Principles</span>
            <h2>Why Pilgrims Choose Shahin Travels</h2>
            <p>Every itinerary is designed with deep reverence for your worship and physical peace of mind.</p>
        </div>

        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap:24px;">
            <div style="background:var(--white); padding:28px; border-radius:14px; box-shadow:var(--shadow-sm); text-align:center;">
                <div style="font-size:2.2rem; margin-bottom:14px;">🕌</div>
                <h4 style="color:var(--green-dark); font-size:1.15rem; margin-bottom:10px;">Hotels Close to Haram</h4>
                <p style="color:var(--gray-600); font-size:0.92rem; line-height:1.6;">Stay minutes away from Masjid Al-Haram and Masjid An-Nabawi so you never miss a Jama’ah prayer.</p>
            </div>

            <div style="background:var(--white); padding:28px; border-radius:14px; box-shadow:var(--shadow-sm); text-align:center;">
                <div style="font-size:2.2rem; margin-bottom:14px;">✈️</div>
                <h4 style="color:var(--green-dark); font-size:1.15rem; margin-bottom:10px;">Direct Flights</h4>
                <p style="color:var(--gray-600); font-size:0.92rem; line-height:1.6;">We prioritize nonstop and direct flights on prestigious carriers like Saudi Airlines to avoid exhausting layovers.</p>
            </div>

            <div style="background:var(--white); padding:28px; border-radius:14px; box-shadow:var(--shadow-sm); text-align:center;">
                <div style="font-size:2.2rem; margin-bottom:14px;">🤝</div>
                <h4 style="color:var(--green-dark); font-size:1.15rem; margin-bottom:10px;">Full Transparency</h4>
                <p style="color:var(--gray-600); font-size:0.92rem; line-height:1.6;">No hidden fees. Exact hotel names, distance, sharing type, and inclusions are clearly detailed in your voucher.</p>
            </div>

            <div style="background:var(--white); padding:28px; border-radius:14px; box-shadow:var(--shadow-sm); text-align:center;">
                <div style="font-size:2.2rem; margin-bottom:14px;">🎧</div>
                <h4 style="color:var(--green-dark); font-size:1.15rem; margin-bottom:10px;">24/7 Ground Support</h4>
                <p style="color:var(--gray-600); font-size:0.92rem; line-height:1.6;">Our bilingual staff in Makkah and Madinah assists with check-in, ziyarats, transport, and emergencies.</p>
            </div>
        </div>
    </div>
</section>

<!-- ── CTA Section ───────────────────────────────────────── -->
<section class="section cta-section" style="background:linear-gradient(135deg, var(--green-dark) 0%, #0d261b 100%); color:var(--white); padding:70px 0; text-align:center;">
    <div class="container">
        <h2 style="font-size:2.3rem; margin-bottom:16px; color:var(--gold);">Ready for Your Umrah Journey?</h2>
        <p style="font-size:1.1rem; max-width:640px; margin:0 auto 30px; color:var(--gray-300);">
            Have questions about dates, package pricing, or visa requirements? Connect with our dedicated team on WhatsApp today.
        </p>
        <div style="display:flex; justify-content:center; gap:16px; flex-wrap:wrap;">
            <a href="<?= e($waUrl) ?>" class="btn btn-wa btn-lg btn-wa-pulse" target="_blank" rel="noopener">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                Chat on WhatsApp
            </a>
            <a href="<?= SITE_URL ?>/umrah-packages" class="btn btn-outline-white btn-lg">
                View All Packages
            </a>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

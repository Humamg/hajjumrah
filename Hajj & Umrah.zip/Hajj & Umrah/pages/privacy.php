<?php
// ============================================================
// Shahin Travels – Privacy Policy (pages/privacy.php)
// ============================================================
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

$db = getDB();
$pageData = $db->query("SELECT * FROM pages WHERE page_key = 'privacy'")->fetch();

$pageTitle    = $pageData['seo_title'] ?? 'Privacy Policy – Shahin Travels';
$metaDesc     = $pageData['seo_description'] ?? 'Privacy Policy of Shahin Travels. Read how we collect, safeguard, and handle pilgrim personal data, passport information, and travel details.';
$canonicalUrl = SITE_URL . '/privacy-policy';
$noindex      = !empty($pageData['noindex']);

$schema = json_encode([
    '@context' => 'https://schema.org',
    '@type'    => 'WebPage',
    'name'     => $pageTitle,
    'url'      => $canonicalUrl,
    'breadcrumb' => [
        '@type' => 'BreadcrumbList',
        'itemListElement' => [
            ['@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => SITE_URL . '/'],
            ['@type' => 'ListItem', 'position' => 2, 'name' => 'Privacy Policy', 'item' => $canonicalUrl]
        ]
    ]
], JSON_UNESCAPED_SLASHES);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-banner">
    <div class="container">
        <nav class="breadcrumb" aria-label="Breadcrumb">
            <a href="<?= SITE_URL ?>/">Home</a>
            <span class="sep">/</span>
            <span class="current">Privacy Policy</span>
        </nav>
        <h1>Privacy Policy</h1>
        <p>Last updated: October 15, 2026</p>
    </div>
</div>

<section class="section">
    <div class="container" style="max-width:860px;">
        <div style="background:var(--white); border-radius:16px; padding:40px; box-shadow:var(--shadow-sm); line-height:1.8; color:var(--gray-700);">
            
            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">1. Introduction</h2>
            <p style="margin-bottom:20px;">
                Shahin Travels ("we", "our", or "us") respects your privacy and is committed to protecting the personal information you share with us. This Privacy Policy explains our practices regarding collection, usage, and protection of information gathered through our website, WhatsApp enquiries, and physical bookings.
            </p>

            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">2. Information We Collect</h2>
            <p style="margin-bottom:12px;">When you enquire or book a Hajj or Umrah package with Shahin Travels, we may collect the following details:</p>
            <ul style="margin-left:24px; margin-bottom:20px;">
                <li><strong>Contact details:</strong> Full name, phone/WhatsApp number, email address, residential address.</li>
                <li><strong>Passport and identification:</strong> Passport copies, national ID, passport expiration date, nationality, gender, and photograph (strictly required for Saudi Umrah visa issuance).</li>
                <li><strong>Pilgrimage preferences:</strong> Preferred departure city, travel month, room sharing choice (Quad, Triple, Double), dietary requirements or wheelchair assistance.</li>
                <li><strong>Form submissions:</strong> Inquiries sent via our contact forms, call-back requests, or WhatsApp chat links.</li>
            </ul>

            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">3. How We Use Your Information</h2>
            <p style="margin-bottom:12px;">We use your data solely for official and authorized pilgrimage services, including:</p>
            <ul style="margin-left:24px; margin-bottom:20px;">
                <li>Processing official Umrah e-Visas through Saudi Ministry of Hajj & Umrah authorized portals.</li>
                <li>Issuing flight tickets with Saudi Airlines and contracted airline partners.</li>
                <li>Reserving hotel rooms in Makkah and Madinah with contracted hospitality providers.</li>
                <li>Arranging local transport, ziyarat buses, and on-ground assistance.</li>
                <li>Communicating booking confirmations, flight schedules, visa updates, and travel guidelines via WhatsApp, phone, or email.</li>
            </ul>

            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">4. Data Confidentiality & Protection</h2>
            <p style="margin-bottom:20px;">
                We never sell, lease, or trade your personal or passport data to third-party marketing companies. Data is only transferred to official entities necessary to execute your pilgrimage (Saudi Ministry portals, airlines, and registered accommodation providers in Saudi Arabia). All digital records are stored securely with restricted access.
            </p>

            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">5. WhatsApp Communications</h2>
            <p style="margin-bottom:20px;">
                When you click "Enquire on WhatsApp" or "Talk on WhatsApp", you interact directly with our verified business team via the WhatsApp platform. Chat conversations are governed by WhatsApp's end-to-end encryption standards.
            </p>

            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">6. Cookies and Tracking</h2>
            <p style="margin-bottom:20px;">
                Our website uses minimal, standard cookies solely for core operational functions, session verification, CSRF security, and aggregated anonymous traffic analysis via Google Analytics.
            </p>

            <h2 style="color:var(--green-dark); font-size:1.5rem; margin-bottom:12px;">7. Contact Us Regarding Your Data</h2>
            <p style="margin-bottom:8px;">If you have any questions or wish to update or delete your information from our booking database, please contact our team:</p>
            <p>
                <strong>Shahin Travels</strong><br>
                Phone: <?= e(getSetting('phone', '+91 99114 46919')) ?><br>
                Email: <?= e(getSetting('email', 'info@shahintravels.in')) ?><br>
                Address: <?= e(getSetting('address', 'New Delhi, India')) ?>
            </p>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

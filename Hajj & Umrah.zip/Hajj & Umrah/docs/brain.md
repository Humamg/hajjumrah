# brain.md: Shahin Travels (Hajj & Umrah Website)

Project context for any AI coding assistant (Antigravity, Claude, etc.). Read this fully before changing code.

---

## 1. What this project is

A simple Hajj & Umrah package website for **Shahin Travels** (Delhi). Visitors browse packages, see details, and book by tapping a **WhatsApp** button. The team manages everything, including SEO, from a small admin panel.

**Rules (very important):**
- Keep it SIMPLE. Do **not** add features that were not asked for (no payments, no customer login, no APIs, no future-feature code).
- Plain **PHP 8 + MySQL** only. No framework, no Composer packages, no Node build step.
- Frontend must feel smooth: light animations only (see section 9).
- Owner communicates in Hinglish; keep code comments in English.

---

## 2. Tech stack

| Part | Choice |
| --- | --- |
| Backend | Plain PHP 8 with PDO (`getDB()` in `config/database.php`) |
| Database | MySQL / MariaDB, database name `shahin_travels` |
| Frontend | HTML + custom CSS (`public/css/style.css`) + vanilla JS (`public/js/main.js`) |
| Server | Apache + `.htaccess` clean URLs (XAMPP locally) |
| Admin | Custom PHP panel in `/admin` with its own CSS |

---

## 3. Folder structure

```
Hajj & Umrah/            (rename to a simple name, e.g. "umrah", see section 11)
├── .htaccess            clean URL routing, security headers, caching, gzip
├── index.php            Home page
├── sitemap.php          served as /sitemap.xml
├── robots.php           served as /robots.txt
├── config/
│   ├── config.php       constants + helper functions (see section 5)
│   ├── database.php     DB credentials + getDB()
│   └── schema.sql       all tables + sample data + default admin
├── includes/            public header.php and footer.php
├── pages/               packages, package-detail, month, category, blog,
│                        blog-article, about, contact, privacy, terms, cancellation
├── admin/               login, dashboard, packages, categories, hotels, blog,
│                        testimonials, enquiries, pages, media, seo, settings,
│                        users, redirects (+ includes/ css/ js/)
└── public/
    ├── css/style.css
    ├── js/main.js
    └── images/          blog, categories, general, hotels, packages,
                         testimonials, uploads
```

---

## 4. URLs (routing in .htaccess)

| URL | File |
| --- | --- |
| `/` | `index.php` |
| `/umrah-packages` | `pages/packages.php` |
| `/umrah-packages/{slug}` | `pages/package-detail.php` |
| `/umrah-packages/month/{month-year}` | `pages/month.php` |
| `/umrah-packages/category/{slug}` | `pages/category.php` |
| `/blog`, `/blog/{slug}` | `pages/blog.php`, `pages/blog-article.php` |
| `/about-us`, `/contact-us` | `pages/about.php`, `pages/contact.php` |
| `/privacy-policy`, `/terms-and-conditions`, `/cancellation-policy` | policy pages |
| `/sitemap.xml`, `/robots.txt` | `sitemap.php`, `robots.php` |
| `/admin` and `/admin/{section}` | admin files |

Delete in admin works through `?action=delete&id=` on the list pages.

---

## 5. Helper functions (config/config.php)

Use these instead of writing new ones:

- `getDB()` PDO connection (always use prepared statements)
- `e($str)` escape output (use on every echoed value)
- `slugify($text)`, `formatINR($amount)`
- `waUrl($number, $message)` builds the `wa.me` link
- `getSetting($key, $default)` and `setSetting($key, $value)` read and write the `settings` table
- `csrf_token()` and `csrf_verify()` for forms
- `setFlash($type, $msg)` and `getFlash()` for admin messages
- `handleUpload($file, $subfolder)` secure image upload (JPG, PNG, WEBP, GIF, max 5 MB)
- `lazyImg($src, $alt, $class)` lazy-loaded image tag
- `checkRedirects()` runs the 301 redirects from the `redirects` table
- `redirect($url)`

---

## 6. Database tables

`admin_users`, `categories`, `hotels`, `packages`, `package_prices` (sharing type: Quad, Triple, Double), `package_itinerary`, `package_images`, `blog_categories`, `blog_posts`, `testimonials`, `enquiries`, `pages`, `settings`, `redirects`, `media`.

Important settings keys (table `settings`): `site_name`, `site_tagline`, `logo`, `favicon`, `phone`, `whatsapp`, `email`, `address`, `office_hours`, social links, `google_analytics`, `search_console`, `wa_package_template`, `wa_general_template`, `wa_callback_template`, `footer_about`, `hero_title`, `hero_subtitle`, `hero_image`, `meta_title_home`, `meta_desc_home`.

---

## 7. WhatsApp booking flow (core feature)

- Number comes from setting `whatsapp` (default `919911446919`).
- Message templates are editable in admin Settings, with placeholders like `{package_name}`, `{departure_date}`, `{name}`, `{phone}`.
- Buttons appear in the header, hero, every package card, package detail page, CTA banners, contact page, and as a floating button.
- Contact form and call-back form save to the `enquiries` table, and the admin sees them in **Enquiries**.

---

## 8. SEO (managed from admin)

- Per page, package, category, blog post and month page: meta title, meta description, editable slug, Open Graph data.
- Canonical tag and JSON-LD schema in `includes/header.php`; package pages add their own schema.
- Automatic `sitemap.xml` and `robots.txt`; 301 redirect manager in admin.
- Google Analytics and Search Console codes in Settings.
- Keep one `<h1>` per page and always set image alt text.

---

## 9. Design and animation

**Brand:** deep green and gold, WhatsApp green for buttons, rounded cards, serif headings.

CSS variables in `:root` of `style.css`: `--green #1a4731`, `--green-dark #122f22`, `--green-light #2d6a4f`, `--gold #c9a227`, `--wa-green #25D366`, `--radius 12px`, `--transition 0.3s ease`, `--max-width 1240px`. Reuse these, do not hardcode new colours.

**Animations (keep light, under 0.6 s):** scroll fade-up on sections, card hover lift and image zoom, hero slow zoom, count-up numbers, soft pulse on the WhatsApp button, sticky header shadow, smooth sliders and tabs. A `prefers-reduced-motion` rule exists and must stay.

---

## 10. Coding rules

1. Prepared statements for every query; escape output with `e()`.
2. Every admin form needs `csrf_token()` and `csrf_verify()`.
3. Admin pages must check the admin session first (follow existing admin pages).
4. Use existing CSS classes and variables; no inline styles for new work.
5. Mobile-first and responsive on every page.
6. Do not add libraries or features that were not requested.

---

## 11. Known issues (fix these first)

| # | Issue | Fix |
| --- | --- | --- |
| 1 | **Admin login fails.** Seed email is `admin@shahin travels.in` (space) and the hash does not match `Admin@123` | Update `admin_users` row 1 with email `admin@shahintravels.in` and hash `$2y$12$GrywvODI7AWpR6PgK3xw6uN9GVSEIdtmfta7oTEx3creXxwzASvCq` (password `Admin@123`), and fix the seed in `schema.sql` too. Change the password after first login |
| 2 | `ADMIN_EMAIL` in `config.php` has a space (`shahintr avels.in`) | Change to `admin@shahintravels.in` |
| 3 | `public/images/` is empty and there is no fallback, so images show blank | Add a placeholder image fallback for packages, hotels, hero and blog; upload real images from admin Media |
| 4 | Folder name `Hajj & Umrah` is hardcoded in `RewriteBase`, `SITE_URL` and `checkRedirects()` | Rename the folder, then update those three places; use a config value for `SITE_URL` on live hosting |
| 5 | Package delete uses a GET link with no CSRF token | Change delete to a POST form with token (same for other admin deletes) |
| 6 | `.htaccess` has a rule for `admin/packages-delete.php`, which does not exist | Remove that rule |

---

## 12. How to run locally

1. Copy the project folder into `htdocs` (XAMPP) and start Apache and MySQL.
2. In phpMyAdmin create database `shahin_travels` and import `config/schema.sql`.
3. Apply the admin fix from known issue 1.
4. Open the site at `http://localhost/<folder-name>/` and the admin at `/admin`.
5. In admin, upload images, set Settings (logo, WhatsApp number, contact details) and check the SEO fields.

---

## 13. Definition of done

- All 8 public pages match the design mockups and work on mobile.
- Filters, sort and pagination work on the package listing.
- Every WhatsApp button opens a chat with the correct prefilled message.
- Admin can add a package and see it live immediately, and can edit SEO fields for any page.
- Animations are smooth and do not slow the site.
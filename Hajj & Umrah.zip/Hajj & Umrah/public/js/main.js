/* =============================================
   Shahin Travels – Main JavaScript
   ============================================= */

(function() {
    'use strict';

    // ── DOM Ready ────────────────────────────────
    document.addEventListener('DOMContentLoaded', function() {
        initHeader();
        initMobileNav();
        initScrollAnimations();
        initLazyImages();
        initTestimonialsSlider();
        initHotelTabs();
        initCountUp();
        initFloatingWA();
    });

    // ── Header Scroll ────────────────────────────
    function initHeader() {
        const header = document.querySelector('.site-header');
        if (!header) return;
        window.addEventListener('scroll', function() {
            header.classList.toggle('scrolled', window.scrollY > 50);
        }, { passive: true });
    }

    // ── Mobile Navigation ────────────────────────
    function initMobileNav() {
        const hamburger = document.querySelector('.hamburger');
        const nav       = document.querySelector('.main-nav');
        const overlay   = document.querySelector('.nav-overlay');
        if (!hamburger || !nav) return;

        function toggleNav() {
            const open = nav.classList.toggle('open');
            hamburger.classList.toggle('open', open);
            if (overlay) overlay.classList.toggle('show', open);
            document.body.style.overflow = open ? 'hidden' : '';
        }
        hamburger.addEventListener('click', toggleNav);
        if (overlay) overlay.addEventListener('click', toggleNav);

        // Close on link click
        nav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                nav.classList.remove('open');
                hamburger.classList.remove('open');
                if (overlay) overlay.classList.remove('show');
                document.body.style.overflow = '';
            });
        });
    }

    // ── Scroll Animations ─────────────────────────
    function initScrollAnimations() {
        const elements = document.querySelectorAll('.fade-up, .fade-in');
        if (!elements.length) return;

        const obs = new IntersectionObserver(function(entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    obs.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

        elements.forEach(el => obs.observe(el));
    }

    // ── Lazy Images ────────────────────────────────
    function initLazyImages() {
        const images = document.querySelectorAll('img[data-src]');
        if (!images.length) return;

        if ('IntersectionObserver' in window) {
            const imgObs = new IntersectionObserver(function(entries) {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                        img.addEventListener('load', () => img.classList.add('loaded'));
                        imgObs.unobserve(img);
                    }
                });
            }, { rootMargin: '200px' });

            images.forEach(img => imgObs.observe(img));
        } else {
            images.forEach(img => {
                img.src = img.dataset.src;
                img.classList.add('loaded');
            });
        }
    }

    // ── Testimonials Slider ────────────────────────
    function initTestimonialsSlider() {
        const track = document.querySelector('.testimonials-track');
        if (!track) return;

        const slides    = track.querySelectorAll('.testimonial-card');
        const dotsWrap  = document.querySelector('.slider-dots');
        const prevBtn   = document.querySelector('.slider-btn.prev');
        const nextBtn   = document.querySelector('.slider-btn.next');
        if (!slides.length) return;

        let current   = 0;
        let autoTimer = null;
        const perView = window.innerWidth >= 1024 ? 3 : window.innerWidth >= 640 ? 2 : 1;
        const total   = Math.ceil(slides.length / perView);

        // Build dots
        if (dotsWrap) {
            dotsWrap.innerHTML = '';
            for (let i = 0; i < total; i++) {
                const dot = document.createElement('button');
                dot.className = 'slider-dot' + (i === 0 ? ' active' : '');
                dot.setAttribute('aria-label', 'Go to slide ' + (i + 1));
                dot.addEventListener('click', () => goTo(i));
                dotsWrap.appendChild(dot);
            }
        }

        function goTo(index) {
            current = ((index % total) + total) % total;
            const offset = current * (100 / perView) * perView;
            track.style.transform = `translateX(-${offset / perView * 100 / slides.length}%)`;
            if (dotsWrap) {
                dotsWrap.querySelectorAll('.slider-dot').forEach((d, i) => d.classList.toggle('active', i === current));
            }
        }

        // Simpler approach: show one group at a time
        function updateSlider() {
            const cardW = slides[0].offsetWidth + 24;
            track.style.transform = `translateX(-${current * perView * cardW}px)`;
            if (dotsWrap) {
                dotsWrap.querySelectorAll('.slider-dot').forEach((d, i) => d.classList.toggle('active', i === current));
            }
        }

        if (prevBtn) prevBtn.addEventListener('click', () => { current = (current - 1 + total) % total; updateSlider(); resetAuto(); });
        if (nextBtn) nextBtn.addEventListener('click', () => { current = (current + 1) % total; updateSlider(); resetAuto(); });

        function startAuto() { autoTimer = setInterval(() => { current = (current + 1) % total; updateSlider(); }, 5000); }
        function resetAuto() { clearInterval(autoTimer); startAuto(); }
        startAuto();

        // Touch swipe
        let startX = 0;
        track.addEventListener('touchstart', e => { startX = e.touches[0].clientX; }, { passive: true });
        track.addEventListener('touchend', e => {
            const diff = startX - e.changedTouches[0].clientX;
            if (Math.abs(diff) > 50) {
                if (diff > 0) { current = (current + 1) % total; } else { current = (current - 1 + total) % total; }
                updateSlider(); resetAuto();
            }
        });
    }

    // ── Hotel Tabs ─────────────────────────────────
    function initHotelTabs() {
        const tabs = document.querySelectorAll('.hotel-tab');
        if (!tabs.length) return;
        tabs.forEach(tab => {
            tab.addEventListener('click', function() {
                const city = this.dataset.city;
                tabs.forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                document.querySelectorAll('.hotel-panel').forEach(panel => {
                    panel.style.display = panel.dataset.city === city ? 'grid' : 'none';
                });
            });
        });
    }

    // ── Count Up ───────────────────────────────────
    function initCountUp() {
        const counters = document.querySelectorAll('[data-count]');
        if (!counters.length) return;

        const obs = new IntersectionObserver(function(entries) {
            entries.forEach(entry => {
                if (!entry.isIntersecting) return;
                const el  = entry.target;
                const end = parseInt(el.dataset.count);
                const dur = 1800;
                const step= 30;
                const inc = end / (dur / step);
                let cur   = 0;
                const timer = setInterval(() => {
                    cur += inc;
                    if (cur >= end) { cur = end; clearInterval(timer); }
                    el.textContent = Math.floor(cur).toLocaleString() + (el.dataset.suffix || '');
                }, step);
                obs.unobserve(el);
            });
        }, { threshold: 0.5 });

        counters.forEach(el => obs.observe(el));
    }

    // ── Floating WA ────────────────────────────────
    function initFloatingWA() {
        const btn = document.querySelector('.floating-wa');
        if (!btn) return;
        let lastY = window.scrollY;
        window.addEventListener('scroll', function() {
            const curY = window.scrollY;
            btn.style.transform = curY > lastY && curY > 300 ? 'translateY(80px)' : 'translateY(0)';
            lastY = curY;
        }, { passive: true });
    }

    // ── Gallery (Detail Page) ─────────────────────
    window.initGallery = function() {
        const mainImg   = document.querySelector('.gallery-main img');
        const thumbs    = document.querySelectorAll('.gallery-thumb');
        const lightbox  = document.querySelector('.lightbox');
        if (!mainImg || !thumbs.length) return;

        const images = Array.from(thumbs).map(t => t.querySelector('img').src);
        let activeIdx = 0;

        thumbs.forEach((thumb, i) => {
            thumb.addEventListener('click', () => {
                thumbs.forEach(t => t.classList.remove('active'));
                thumb.classList.add('active');
                mainImg.src = images[i];
                activeIdx = i;
            });
        });

        // Lightbox
        if (lightbox) {
            const lbImg  = lightbox.querySelector('.lightbox-img');
            const lbClose= lightbox.querySelector('.lightbox-close');
            const lbPrev = lightbox.querySelector('.lightbox-prev');
            const lbNext = lightbox.querySelector('.lightbox-next');

            document.querySelector('.gallery-main').addEventListener('click', () => {
                lbImg.src = images[activeIdx];
                lightbox.classList.add('open');
                document.body.style.overflow = 'hidden';
            });

            function closeLB() { lightbox.classList.remove('open'); document.body.style.overflow = ''; }
            function showLB(idx) { activeIdx = ((idx % images.length) + images.length) % images.length; lbImg.src = images[activeIdx]; }

            if (lbClose) lbClose.addEventListener('click', closeLB);
            lightbox.addEventListener('click', e => { if (e.target === lightbox) closeLB(); });
            if (lbPrev) lbPrev.addEventListener('click', () => showLB(activeIdx - 1));
            if (lbNext) lbNext.addEventListener('click', () => showLB(activeIdx + 1));
            document.addEventListener('keydown', e => {
                if (!lightbox.classList.contains('open')) return;
                if (e.key === 'Escape') closeLB();
                if (e.key === 'ArrowLeft') showLB(activeIdx - 1);
                if (e.key === 'ArrowRight') showLB(activeIdx + 1);
            });
        }
    };

    // ── Package Detail Tabs ────────────────────────
    window.initDetailTabs = function() {
        const tabBtns   = document.querySelectorAll('.tab-btn');
        const tabPanels = document.querySelectorAll('.tab-content');
        if (!tabBtns.length) return;

        tabBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const target = this.dataset.tab;
                tabBtns.forEach(b => b.classList.remove('active'));
                tabPanels.forEach(p => p.classList.remove('active'));
                this.classList.add('active');
                const panel = document.getElementById('tab-' + target);
                if (panel) panel.classList.add('active');
            });
        });
    };

    // ── Filter Drawer (Mobile) ────────────────────
    window.initFilterDrawer = function() {
        const toggleBtn = document.querySelector('.filter-toggle-btn');
        const drawer    = document.querySelector('.filter-drawer');
        const overlay   = document.querySelector('.filter-drawer-overlay');
        const closeBtn  = document.querySelector('.filter-drawer-close');
        if (!toggleBtn || !drawer) return;

        function openDrawer() {
            drawer.classList.add('open');
            if (overlay) overlay.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
        function closeDrawer() {
            drawer.classList.remove('open');
            if (overlay) overlay.classList.remove('show');
            document.body.style.overflow = '';
        }
        toggleBtn.addEventListener('click', openDrawer);
        if (closeBtn) closeBtn.addEventListener('click', closeDrawer);
        if (overlay) overlay.addEventListener('click', closeDrawer);
    };

    // ── Share Buttons ──────────────────────────────
    window.copyToClipboard = function(text, el) {
        navigator.clipboard.writeText(text).then(() => {
            const orig = el.innerHTML;
            el.innerHTML = '✓ Copied!';
            el.style.background = '#dcfce7';
            setTimeout(() => { el.innerHTML = orig; el.style.background = ''; }, 2000);
        });
    };

    // ── Package Filters Helper ────────────────────
    window.applyFilters = function() {
        const form = document.querySelector('#filter-form');
        if (!form) return;
        const formData = new FormData(form);
        const params = new URLSearchParams();
        for (const [key, val] of formData.entries()) {
            if (val && String(val).trim() !== '') {
                params.append(key, val);
            }
        }
        const action = form.getAttribute('action') || window.location.pathname;
        const queryStr = params.toString();
        window.location.href = queryStr ? action + '?' + queryStr : action;
    };

    // Synchronize active styling on radio filter options
    document.addEventListener('change', function(e) {
        if (e.target && e.target.type === 'radio' && e.target.closest('.filter-options')) {
            const container = e.target.closest('.filter-options');
            container.querySelectorAll('.filter-option').forEach(function(opt) {
                opt.classList.remove('active');
            });
            const selectedOpt = e.target.closest('.filter-option');
            if (selectedOpt) {
                selectedOpt.classList.add('active');
            }
        }
    });

    // ── Image Preview ──────────────────────────────
    window.previewImage = function(input, previewId) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const preview = document.getElementById(previewId);
                if (preview) {
                    preview.src = e.target.result;
                    preview.parentElement.style.display = 'block';
                }
            };
            reader.readAsDataURL(input.files[0]);
        }
    };

    // ── Confirm Delete ─────────────────────────────
    window.confirmDelete = function(msg) {
        return confirm(msg || 'Are you sure you want to delete this? This action cannot be undone.');
    };

})();

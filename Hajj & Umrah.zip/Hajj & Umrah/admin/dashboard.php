<?php
// Admin Dashboard
$adminPageTitle = 'Dashboard';
require_once __DIR__ . '/includes/header.php';

$db = getDB();

// Stats
$totalPackages = $db->query("SELECT COUNT(*) FROM packages WHERE status='published'")->fetchColumn();
$totalEnquiries= $db->query("SELECT COUNT(*) FROM enquiries")->fetchColumn();
$newEnquiries  = $db->query("SELECT COUNT(*) FROM enquiries WHERE status='new'")->fetchColumn();
$totalBlog     = $db->query("SELECT COUNT(*) FROM blog_posts WHERE status='published'")->fetchColumn();
$trendingCount = $db->query("SELECT COUNT(*) FROM packages WHERE is_trending=1 AND status='published'")->fetchColumn();
$totalHotels   = $db->query("SELECT COUNT(*) FROM hotels")->fetchColumn();

// Recent enquiries
$recentEnq = $db->query("SELECT * FROM enquiries ORDER BY created_at DESC LIMIT 8")->fetchAll();

// Recent packages
$recentPkg = $db->query("
    SELECT p.*, c.name AS cat_name FROM packages p
    LEFT JOIN categories c ON c.id=p.category_id
    ORDER BY p.created_at DESC LIMIT 6
")->fetchAll();
?>

<div class="dashboard-stats">
    <div class="stat-card">
        <div class="stat-icon green">📦</div>
        <div class="stat-info">
            <span class="value"><?= $totalPackages ?></span>
            <span class="label">Live Packages</span>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon blue">📨</div>
        <div class="stat-info">
            <span class="value"><?= $newEnquiries ?> <small style="font-size:1rem;color:#9ca3af;">new</small></span>
            <span class="label">Enquiries (<?= $totalEnquiries ?> total)</span>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon gold">📝</div>
        <div class="stat-info">
            <span class="value"><?= $totalBlog ?></span>
            <span class="label">Blog Posts</span>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green">🏨</div>
        <div class="stat-info">
            <span class="value"><?= $totalHotels ?></span>
            <span class="label">Hotels Listed</span>
        </div>
    </div>
</div>

<div class="dashboard-grid">
    <!-- Recent Enquiries -->
    <div class="card">
        <div class="card-header">
            <h3>Recent Enquiries</h3>
            <a href="<?= SITE_URL ?>/admin/enquiries" class="btn-admin btn-outline btn-sm">View All</a>
        </div>
        <div class="data-table-wrap">
            <table class="data-table">
                <thead><tr><th>Name</th><th>Phone</th><th>Type</th><th>Date</th><th>Status</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($recentEnq as $enq): ?>
                <tr>
                    <td><?= e($enq['name']) ?></td>
                    <td><a href="tel:<?= e($enq['phone']) ?>" style="color:var(--green);"><?= e($enq['phone']) ?></a></td>
                    <td><?= ucfirst(e($enq['type'])) ?></td>
                    <td><?= date('d M, H:i', strtotime($enq['created_at'])) ?></td>
                    <td><span class="status-badge <?= e($enq['status']) ?>"><?= ucfirst($enq['status']) ?></span></td>
                    <td>
                        <?php
                        $waNumber = getSetting('whatsapp', '919911446919');
                        $waCb = waUrl($waNumber, 'Responding to enquiry from ' . $enq['name'] . ' (' . $enq['phone'] . ')');
                        ?>
                        <a href="<?= e($waCb) ?>" class="btn-icon" target="_blank" rel="noopener" title="WhatsApp">📱</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($recentEnq)): ?><tr><td colspan="6" style="text-align:center;color:#999;padding:30px;">No enquiries yet.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Quick Actions -->
    <div>
        <div class="card" style="margin-bottom:20px;">
            <div class="card-header"><h3>Quick Actions</h3></div>
            <div style="display:flex;flex-direction:column;gap:10px;">
                <a href="<?= SITE_URL ?>/admin/packages/add" class="btn-admin btn-primary">+ Add New Package</a>
                <a href="<?= SITE_URL ?>/admin/blog/add"     class="btn-admin btn-outline">+ Add Blog Post</a>
                <a href="<?= SITE_URL ?>/admin/enquiries"    class="btn-admin btn-outline">📨 View Enquiries <?php if($newEnquiries>0): ?><span class="badge-count"><?= $newEnquiries ?></span><?php endif; ?></a>
                <a href="<?= SITE_URL ?>/admin/settings"     class="btn-admin btn-outline">⚙️ Settings</a>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h3>Recent Packages</h3></div>
            <div style="display:flex;flex-direction:column;gap:10px;">
                <?php foreach ($recentPkg as $rp): ?>
                <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--gray-100);">
                    <div>
                        <div style="font-size:.875rem;font-weight:600;color:var(--gray-800);"><?= e($rp['title']) ?></div>
                        <div style="font-size:.75rem;color:var(--gray-400);"><?= date('d M Y', strtotime($rp['departure_date'])) ?> · <?= e($rp['cat_name'] ?? '') ?></div>
                    </div>
                    <div style="display:flex;gap:6px;">
                        <span class="status-badge <?= e($rp['status']) ?>"><?= ucfirst($rp['status']) ?></span>
                        <a href="<?= SITE_URL ?>/admin/packages/edit/<?= $rp['id'] ?>" class="btn-icon" title="Edit">✏️</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

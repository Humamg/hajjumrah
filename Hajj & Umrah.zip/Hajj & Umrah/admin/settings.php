<?php
// ============================================================
// Shahin Travels – Admin General Settings
// ============================================================
$adminPageTitle = 'General Settings';
require_once __DIR__ . '/includes/header.php';

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        setFlash('error', 'Security check failed. Please try again.');
    } else {
        $settingsToSave = [
            'site_name', 'site_tagline', 'phone', 'whatsapp',
            'email', 'address', 'office_hours',
            'wa_general_template', 'wa_package_template',
            'google_analytics', 'search_console_tag',
            'facebook_url', 'instagram_url', 'youtube_url'
        ];

        foreach ($settingsToSave as $key) {
            if (isset($_POST[$key])) {
                setSetting($key, trim($_POST[$key]));
            }
        }

        // Handle Logo Upload
        if (!empty($_FILES['logo_file']['name'])) {
            $up = handleUpload($_FILES['logo_file'], 'general');
            if ($up['success']) {
                setSetting('logo', $up['filename']);
            }
        }

        // Handle Favicon Upload
        if (!empty($_FILES['favicon_file']['name'])) {
            $up = handleUpload($_FILES['favicon_file'], 'general');
            if ($up['success']) {
                setSetting('favicon', $up['filename']);
            }
        }

        setFlash('success', 'Site settings updated successfully.');
        redirect(SITE_URL . '/admin/settings');
    }
}
?>

<div class="admin-content-inner">
    <div style="margin-bottom:24px;">
        <h2>Website & WhatsApp Settings</h2>
        <p style="color:var(--gray-500); font-size:0.9rem;">Manage WhatsApp integration, direct phone numbers, business hours, and analytics tracking.</p>
    </div>

    <form method="POST" action="" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:24px;">
            
            <!-- Column 1: WhatsApp & Contact Details -->
            <div style="display:flex; flex-direction:column; gap:24px;">
                
                <!-- WhatsApp Configuration Card -->
                <div class="admin-card">
                    <h3 class="admin-card-title">💬 WhatsApp Connect Settings</h3>
                    
                    <div class="form-group">
                        <label class="form-label">WhatsApp Number <span class="required">*</span></label>
                        <input type="text" name="whatsapp" class="form-control" placeholder="919911446919" value="<?= e(getSetting('whatsapp', '919911446919')) ?>" required>
                        <small style="color:var(--gray-500);">Country code without + or spaces (e.g. 919911446919).</small>
                    </div>

                    <div class="form-group">
                        <label class="form-label">General Enquire Template</label>
                        <textarea name="wa_general_template" class="form-control" rows="3"><?= e(getSetting('wa_general_template', 'Assalamualaikum, I would like to enquire about Umrah packages with Shahin Travels.')) ?></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Package Enquiry Template</label>
                        <textarea name="wa_package_template" class="form-control" rows="3"><?= e(getSetting('wa_package_template', 'Assalamualaikum, I am interested in {package_title} (Departure: {departure_date}, Price: Rs {price} per person, {sharing_type} sharing). Link: {url}')) ?></textarea>
                        <small style="color:var(--gray-500);">Placeholders: {package_title}, {departure_date}, {price}, {sharing_type}, {url}</small>
                    </div>
                </div>

                <!-- Contact & Office Info -->
                <div class="admin-card">
                    <h3 class="admin-card-title">📞 Office & Contact Info</h3>
                    
                    <div class="form-group">
                        <label class="form-label">Primary Phone Number</label>
                        <input type="text" name="phone" class="form-control" value="<?= e(getSetting('phone', '+91 99114 46919')) ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Email Address</label>
                        <input type="email" name="email" class="form-control" value="<?= e(getSetting('email', 'info@shahintravels.in')) ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Office Address</label>
                        <textarea name="address" class="form-control" rows="2"><?= e(getSetting('address', 'Near Jama Masjid, Main Road, New Delhi - 110006, India')) ?></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Business / Office Hours</label>
                        <input type="text" name="office_hours" class="form-control" value="<?= e(getSetting('office_hours', 'Monday - Saturday: 10:00 AM - 7:00 PM | Sunday: Closed')) ?>">
                    </div>
                </div>

            </div>

            <!-- Column 2: Identity, Scripts, Social -->
            <div style="display:flex; flex-direction:column; gap:24px;">
                
                <!-- Site Identity -->
                <div class="admin-card">
                    <h3 class="admin-card-title">🕌 Site Identity & Branding</h3>
                    
                    <div class="form-group">
                        <label class="form-label">Company / Site Name</label>
                        <input type="text" name="site_name" class="form-control" value="<?= e(getSetting('site_name', 'Shahin Travels')) ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Tagline</label>
                        <input type="text" name="site_tagline" class="form-control" value="<?= e(getSetting('site_tagline', 'Hajj & Umrah Specialists')) ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Upload Site Logo</label>
                        <input type="file" name="logo_file" class="form-control" accept="image/*">
                        <?php if ($logo = getSetting('logo')): ?>
                        <div style="margin-top:8px;">
                            <img src="<?= SITE_URL ?>/public/images/general/<?= e($logo) ?>" alt="Logo" style="max-height:40px;">
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Google Analytics & Scripts -->
                <div class="admin-card">
                    <h3 class="admin-card-title">📈 Analytics & Tracking Scripts</h3>
                    
                    <div class="form-group">
                        <label class="form-label">Google Analytics / GTM Code</label>
                        <textarea name="google_analytics" class="form-control" rows="4" placeholder="<!-- Google tag (gtag.js) -->..."><?= e(getSetting('google_analytics', '')) ?></textarea>
                        <small style="color:var(--gray-500);">Code is inserted directly into the &lt;head&gt; tag on all public pages.</small>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Google Search Console Verification Tag</label>
                        <input type="text" name="search_console_tag" class="form-control" placeholder='<meta name="google-site-verification" content="..." />' value="<?= e(getSetting('search_console_tag', '')) ?>">
                    </div>
                </div>

                <!-- Social Links -->
                <div class="admin-card">
                    <h3 class="admin-card-title">🌐 Social Media Channels</h3>
                    
                    <div class="form-group">
                        <label class="form-label">Facebook Profile / Page</label>
                        <input type="url" name="facebook_url" class="form-control" placeholder="https://facebook.com/..." value="<?= e(getSetting('facebook_url', '')) ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Instagram Profile</label>
                        <input type="url" name="instagram_url" class="form-control" placeholder="https://instagram.com/..." value="<?= e(getSetting('instagram_url', '')) ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">YouTube Channel</label>
                        <input type="url" name="youtube_url" class="form-control" placeholder="https://youtube.com/..." value="<?= e(getSetting('youtube_url', '')) ?>">
                    </div>
                </div>

                <button type="submit" class="btn-admin btn-primary" style="padding:14px; font-size:1.05rem; justify-content:center;">
                    💾 Save All Settings
                </button>

            </div>

        </div>
    </form>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

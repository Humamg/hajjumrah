<?php
$adminPageTitle = 'Write Blog Post';
$postId = null;
require __DIR__ . '/blog-form.php';

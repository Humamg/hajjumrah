<?php
// ============================================================
// Shahin Travels – Admin Static Pages & Content Management
// ============================================================
$adminPageTitle = 'Pages Content & SEO';
require_once __DIR__ . '/includes/header.php';

$db = getDB();
$tab = $_GET['tab'] ?? 'home';

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        setFlash('error', 'Security check failed. Please try again.');
    } else {
        $postedTab = $_POST['tab'] ?? 'home';

        if ($postedTab === 'home') {
            // Update settings
            setSetting('hero_title', $_POST['hero_title'] ?? '');
            setSetting('hero_subtitle', $_POST['hero_subtitle'] ?? '');
            setSetting('meta_title_home', $_POST['meta_title_home'] ?? '');
            setSetting('meta_desc_home', $_POST['meta_desc_home'] ?? '');

            if (!empty($_FILES['hero_image_file']['name'])) {
                $up = handleUpload($_FILES['hero_image_file'], 'general');
                if ($up['success']) {
                    setSetting('hero_image', $up['filename']);
                }
            } elseif (!empty($_POST['hero_image_url'])) {
                setSetting('hero_image', trim($_POST['hero_image_url']));
            }

            setFlash('success', 'Home page content and SEO updated.');
            redirect(SITE_URL . '/admin/pages?tab=home');
        } else {
            // Update pages table
            $pageKey  = $postedTab;
            $seoTitle = trim($_POST['seo_title'] ?? '');
            $seoDesc  = trim($_POST['seo_description'] ?? '');
            $content  = trim($_POST['content'] ?? '');
            $noindex  = !empty($_POST['noindex']) ? 1 : 0;

            $check = $db->prepare("SELECT id FROM pages WHERE page_key = ?");
            $check->execute([$pageKey]);
            if ($check->fetch()) {
                $sql = "UPDATE pages SET seo_title=?, seo_description=?, content=?, noindex=? WHERE page_key=?";
                $db->prepare($sql)->execute([$seoTitle, $seoDesc, $content, $noindex, $pageKey]);
            } else {
                $sql = "INSERT INTO pages (page_key, seo_title, seo_description, content, noindex) VALUES (?,?,?,?,?)";
                $db->prepare($sql)->execute([$pageKey, $seoTitle, $seoDesc, $content, $noindex]);
            }

            setFlash('success', ucfirst($pageKey) . ' page content updated.');
            redirect(SITE_URL . '/admin/pages?tab=' . $pageKey);
        }
    }
}

// Load current tab data
$homeHeroTitle    = getSetting('hero_title', 'Your Spiritual Journey, <span>Our Commitment</span>');
$homeHeroSubtitle = getSetting('hero_subtitle', "Comfortable Packages | Premium Hotels | Direct Flights");
$homeHeroImage    = getSetting('hero_image', '');
$homeMetaTitle    = getSetting('meta_title_home', 'Shahin Travels – Hajj & Umrah Packages from India');
$homeMetaDesc     = getSetting('meta_desc_home', 'Book affordable Umrah packages from India with direct flights, comfortable hotels near Haram, and complete assistance.');

$currentPageData = null;
if ($tab !== 'home') {
    $stmt = $db->prepare("SELECT * FROM pages WHERE page_key = ?");
    $stmt->execute([$tab]);
    $currentPageData = $stmt->fetch();
}
?>

<div class="admin-content-inner">
    <div style="margin-bottom:24px;">
        <h2>Static Pages & Content Editor</h2>
        <p style="color:var(--gray-500); font-size:0.9rem;">Manage text, banners, and search engine optimization for your core website pages.</p>
    </div>

    <!-- Navigation Tabs -->
    <div style="display:flex; gap:10px; margin-bottom:24px; border-bottom:2px solid var(--gray-200); padding-bottom:12px; flex-wrap:wrap;">
        <a href="<?= SITE_URL ?>/admin/pages?tab=home" class="btn-admin <?= $tab === 'home' ? 'btn-primary' : 'btn-outline' ?>">🏠 Home Page</a>
        <a href="<?= SITE_URL ?>/admin/pages?tab=about" class="btn-admin <?= $tab === 'about' ? 'btn-primary' : 'btn-outline' ?>">📖 About Us</a>
        <a href="<?= SITE_URL ?>/admin/pages?tab=privacy" class="btn-admin <?= $tab === 'privacy' ? 'btn-primary' : 'btn-outline' ?>">🔒 Privacy Policy</a>
        <a href="<?= SITE_URL ?>/admin/pages?tab=terms" class="btn-admin <?= $tab === 'terms' ? 'btn-primary' : 'btn-outline' ?>">📋 Terms & Conditions</a>
        <a href="<?= SITE_URL ?>/admin/pages?tab=cancellation" class="btn-admin <?= $tab === 'cancellation' ? 'btn-primary' : 'btn-outline' ?>">❌ Cancellation Policy</a>
    </div>

    <?php if ($tab === 'home'): ?>
    <!-- Home Page Form -->
    <form method="POST" action="" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
        <input type="hidden" name="tab" value="home">

        <div style="display:grid; grid-template-columns: 2fr 1fr; gap:24px;">
            <div class="admin-card">
                <h3 class="admin-card-title">Home Hero Banner Content</h3>
                
                <div class="form-group">
                    <label class="form-label">Hero Headline</label>
                    <input type="text" name="hero_title" class="form-control" value="<?= e($homeHeroTitle) ?>" placeholder="Your Spiritual Journey, Our Commitment">
                    <small style="color:var(--gray-400);">Use &lt;span&gt;text&lt;/span&gt; to apply gold highlight font.</small>
                </div>

                <div class="form-group">
                    <label class="form-label">Hero Subtitle / Tagline Points (One per line)</label>
                    <textarea name="hero_subtitle" class="form-control" rows="3"><?= e($homeHeroSubtitle) ?></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Hero Background Image</label>
                    <?php if ($homeHeroImage): ?>
                    <div style="margin-bottom:10px; max-width:320px; border-radius:8px; overflow:hidden;">
                        <img src="<?= e(strpos($homeHeroImage, 'http') === 0 ? $homeHeroImage : SITE_URL . '/public/images/' . $homeHeroImage) ?>" alt="Hero" style="width:100%; height:120px; object-fit:cover; display:block;">
                    </div>
                    <?php endif; ?>
                    <input type="file" name="hero_image_file" class="form-control" accept="image/*">
                </div>
            </div>

            <div class="admin-card">
                <h3 class="admin-card-title">Home Page SEO</h3>
                
                <div class="form-group">
                    <label class="form-label">Home Meta Title</label>
                    <input type="text" name="meta_title_home" class="form-control" value="<?= e($homeMetaTitle) ?>">
                </div>

                <div class="form-group">
                    <label class="form-label">Home Meta Description</label>
                    <textarea name="meta_desc_home" class="form-control" rows="4"><?= e($homeMetaDesc) ?></textarea>
                </div>

                <button type="submit" class="btn-admin btn-primary" style="width:100%; justify-content:center; margin-top:16px;">
                    💾 Save Home Settings
                </button>
            </div>
        </div>
    </form>
    <?php else: ?>
    <!-- Static Page Form -->
    <form method="POST" action="">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
        <input type="hidden" name="tab" value="<?= e($tab) ?>">

        <div style="display:grid; grid-template-columns: 2fr 1fr; gap:24px;">
            <div class="admin-card">
                <h3 class="admin-card-title"><?= ucfirst($tab) ?> Page Content</h3>
                
                <div class="form-group">
                    <label class="form-label">Custom Content / Notes</label>
                    <textarea name="content" class="form-control" rows="12" placeholder="Custom text or updates for this page..."><?= e($currentPageData['content'] ?? '') ?></textarea>
                </div>
            </div>

            <div class="admin-card">
                <h3 class="admin-card-title">SEO Settings</h3>
                
                <div class="form-group">
                    <label class="form-label">Meta SEO Title</label>
                    <input type="text" name="seo_title" class="form-control" value="<?= e($currentPageData['seo_title'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label class="form-label">Meta Description</label>
                    <textarea name="seo_description" class="form-control" rows="4"><?= e($currentPageData['seo_description'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
                        <input type="checkbox" name="noindex" value="1" <?= !empty($currentPageData['noindex']) ? 'checked' : '' ?>>
                        <span style="color:#c0392b; font-weight:600;">Hide from Search Engines (noindex)</span>
                    </label>
                </div>

                <button type="submit" class="btn-admin btn-primary" style="width:100%; justify-content:center; margin-top:16px;">
                    💾 Save <?= ucfirst($tab) ?> SEO
                </button>
            </div>
        </div>
    </form>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

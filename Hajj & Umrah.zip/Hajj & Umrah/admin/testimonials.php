<?php
// ============================================================
// Shahin Travels – Admin Testimonials Management
// ============================================================
$adminPageTitle = 'Customer Testimonials';
require_once __DIR__ . '/includes/header.php';

$db = getDB();
$action = $_GET['action'] ?? '';
$tId    = (int)($_GET['id'] ?? 0);
$editTestimonial = null;

// Delete
if ($action === 'delete' && $tId) {
    $db->prepare("DELETE FROM testimonials WHERE id = ?")->execute([$tId]);
    setFlash('success', 'Testimonial deleted.');
    redirect(SITE_URL . '/admin/testimonials');
}

// Toggle active
if ($action === 'toggle' && $tId) {
    $db->prepare("UPDATE testimonials SET is_active = NOT is_active WHERE id = ?")->execute([$tId]);
    setFlash('success', 'Status toggled.');
    redirect(SITE_URL . '/admin/testimonials');
}

// Edit pre-load
if ($action === 'edit' && $tId) {
    $stmt = $db->prepare("SELECT * FROM testimonials WHERE id = ?");
    $stmt->execute([$tId]);
    $editTestimonial = $stmt->fetch();
}

// Handle Add / Edit POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        setFlash('error', 'Security check failed. Please try again.');
    } else {
        $name     = trim($_POST['customer_name'] ?? '');
        $location = trim($_POST['location'] ?? '');
        $rating   = max(1, min(5, (int)($_POST['rating'] ?? 5)));
        $review   = trim($_POST['review'] ?? '');
        $sort     = (int)($_POST['sort_order'] ?? 0);
        $isActive = !empty($_POST['is_active']) ? 1 : 0;
        $avatar   = trim($_POST['avatar'] ?? '');

        if ($name && $review) {
            if ($tId && $editTestimonial) {
                $sql = "UPDATE testimonials SET customer_name=?, location=?, rating=?, review=?, avatar=?, is_active=?, sort_order=? WHERE id=?";
                $db->prepare($sql)->execute([$name, $location, $rating, $review, $avatar, $isActive, $sort, $tId]);
                setFlash('success', 'Testimonial updated.');
            } else {
                $sql = "INSERT INTO testimonials (customer_name, location, rating, review, avatar, is_active, sort_order) VALUES (?,?,?,?,?,?,?)";
                $db->prepare($sql)->execute([$name, $location, $rating, $review, $avatar, $isActive, $sort]);
                setFlash('success', 'Testimonial added.');
            }
            redirect(SITE_URL . '/admin/testimonials');
        } else {
            setFlash('error', 'Customer name and review are required.');
        }
    }
}

$testimonials = $db->query("SELECT * FROM testimonials ORDER BY sort_order ASC, id DESC")->fetchAll();
?>

<div class="admin-content-inner">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
        <div>
            <h2>Pilgrim Reviews & Testimonials</h2>
            <p style="color:var(--gray-500); font-size:0.9rem;">Manage reviews featured on the home page and package detail pages.</p>
        </div>
        <?php if ($editTestimonial): ?>
        <a href="<?= SITE_URL ?>/admin/testimonials" class="btn-admin btn-outline">+ Add New Review</a>
        <?php endif; ?>
    </div>

    <div style="display:grid; grid-template-columns: 2fr 1fr; gap:24px;">
        
        <!-- Left: Testimonials Table -->
        <div class="admin-card">
            <h3 class="admin-card-title">All Testimonials (<?= count($testimonials) ?>)</h3>
            <div style="overflow-x:auto;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Pilgrim</th>
                            <th>Rating</th>
                            <th>Review Snippet</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($testimonials)): ?>
                        <tr><td colspan="5" style="text-align:center; padding:30px; color:var(--gray-400);">No reviews recorded yet.</td></tr>
                        <?php else: ?>
                            <?php foreach ($testimonials as $t): ?>
                            <tr>
                                <td>
                                    <strong><?= e($t['customer_name']) ?></strong>
                                    <div style="font-size:0.75rem; color:var(--gray-500);"><?= e($t['location'] ?? 'India') ?></div>
                                </td>
                                <td>
                                    <span style="color:#f39c12;"><?= str_repeat('★', $t['rating']) ?></span>
                                </td>
                                <td>
                                    <div style="font-size:0.85rem; color:var(--gray-600); max-width:280px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">
                                        "<?= e($t['review']) ?>"
                                    </div>
                                </td>
                                <td>
                                    <a href="<?= SITE_URL ?>/admin/testimonials?action=toggle&id=<?= $t['id'] ?>" class="badge badge-<?= $t['is_active'] ? 'published' : 'draft' ?>">
                                        <?= $t['is_active'] ? 'Active' : 'Hidden' ?>
                                    </a>
                                </td>
                                <td>
                                    <div style="display:flex; gap:8px;">
                                        <a href="<?= SITE_URL ?>/admin/testimonials?action=edit&id=<?= $t['id'] ?>" class="btn-admin btn-sm btn-outline">Edit</a>
                                        <a href="<?= SITE_URL ?>/admin/testimonials?action=delete&id=<?= $t['id'] ?>" class="btn-admin btn-sm btn-danger" onclick="return confirm('Delete this testimonial?');">Delete</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Right: Add / Edit Form -->
        <div class="admin-card">
            <h3 class="admin-card-title"><?= $editTestimonial ? 'Edit Review' : 'Add Pilgrim Review' ?></h3>
            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

                <div class="form-group">
                    <label class="form-label">Pilgrim Name <span class="required">*</span></label>
                    <input type="text" name="customer_name" class="form-control" placeholder="e.g. Haji Mohammad Rafiq" value="<?= e($editTestimonial['customer_name'] ?? '') ?>" required>
                </div>

                <div class="form-group">
                    <label class="form-label">City / Location</label>
                    <input type="text" name="location" class="form-control" placeholder="e.g. Lucknow, India" value="<?= e($editTestimonial['location'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label class="form-label">Star Rating</label>
                    <select name="rating" class="form-control">
                        <option value="5" <?= ($editTestimonial['rating'] ?? 5) == 5 ? 'selected' : '' ?>>★★★★★ (5 Stars)</option>
                        <option value="4" <?= ($editTestimonial['rating'] ?? 5) == 4 ? 'selected' : '' ?>>★★★★☆ (4 Stars)</option>
                        <option value="3" <?= ($editTestimonial['rating'] ?? 5) == 3 ? 'selected' : '' ?>>★★★☆☆ (3 Stars)</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Review Testimonial Text <span class="required">*</span></label>
                    <textarea name="review" class="form-control" rows="4" placeholder="Feedback about arrangements, flights, hotel distances, and staff assistance..." required><?= e($editTestimonial['review'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Display Sort Order</label>
                    <input type="number" name="sort_order" class="form-control" value="<?= e($editTestimonial['sort_order'] ?? 0) ?>">
                </div>

                <div class="form-group">
                    <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
                        <input type="checkbox" name="is_active" value="1" <?= (!isset($editTestimonial) || !empty($editTestimonial['is_active'])) ? 'checked' : '' ?>>
                        <span style="font-weight:600; color:var(--green-dark);">Active (Show on website)</span>
                    </label>
                </div>

                <button type="submit" class="btn-admin btn-primary" style="width:100%; justify-content:center; margin-top:10px;">
                    <?= $editTestimonial ? 'Update Review' : '+ Save Review' ?>
                </button>
            </form>
        </div>

    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

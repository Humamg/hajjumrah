<?php
// ============================================================
// Shahin Travels – Admin SEO Audit & Overview
// ============================================================
$adminPageTitle = 'SEO Overview & Tools';
require_once __DIR__ . '/includes/header.php';

$db = getDB();

// Sitemap counts
$pkgCount = (int)$db->query("SELECT COUNT(*) FROM packages WHERE status='published' AND noindex=0")->fetchColumn();
$catCount = (int)$db->query("SELECT COUNT(*) FROM categories WHERE noindex=0")->fetchColumn();
$blogCount= (int)$db->query("SELECT COUNT(*) FROM blog_posts WHERE status='published' AND noindex=0")->fetchColumn();

// Packages missing SEO title or description
$missingPkgSeo = $db->query("SELECT id, title, slug FROM packages WHERE status='published' AND (seo_title IS NULL OR seo_title = '' OR seo_description IS NULL OR seo_description = '')")->fetchAll();

// Robots config
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['robots_txt'])) {
    if (csrf_verify()) {
        setSetting('robots_txt', trim($_POST['robots_txt']));
        setFlash('success', 'Robots.txt configuration updated.');
        redirect(SITE_URL . '/admin/seo');
    }
}
$currentRobots = getSetting('robots_txt', "User-agent: *\nDisallow: /admin/\nDisallow: /admin\nAllow: /\n\nSitemap: " . SITE_URL . "/sitemap.xml\n");
?>

<div class="admin-content-inner">
    <div style="margin-bottom:24px;">
        <h2>Search Engine Optimization (SEO) Hub</h2>
        <p style="color:var(--gray-500); font-size:0.9rem;">Monitor automated XML sitemaps, structured schemas, meta tags, and robots.txt crawling instructions.</p>
    </div>

    <!-- Health Cards Grid -->
    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap:20px; margin-bottom:28px;">
        <div class="admin-card" style="border-left:4px solid var(--green);">
            <div style="font-size:0.85rem; color:var(--gray-500); text-transform:uppercase;">XML Sitemap</div>
            <div style="font-size:1.8rem; font-weight:700; color:var(--green-dark); margin:6px 0;">Live & Dynamic</div>
            <div style="font-size:0.85rem; color:var(--gray-600); margin-bottom:12px;">Indexing <?= $pkgCount ?> packages, <?= $catCount ?> categories, <?= $blogCount ?> articles.</div>
            <a href="<?= SITE_URL ?>/sitemap.xml" target="_blank" class="btn-admin btn-sm btn-outline">View sitemap.xml ↗</a>
        </div>

        <div class="admin-card" style="border-left:4px solid var(--gold);">
            <div style="font-size:0.85rem; color:var(--gray-500); text-transform:uppercase;">Schema Markup</div>
            <div style="font-size:1.8rem; font-weight:700; color:var(--green-dark); margin:6px 0;">Automated</div>
            <div style="font-size:0.85rem; color:var(--gray-600); margin-bottom:12px;">Organization, Product (Package), BreadcrumbList & Article Schema.</div>
            <span class="badge" style="background:var(--gold-light); color:var(--gold-dark); font-weight:600;">Active on All Pages</span>
        </div>

        <div class="admin-card" style="border-left:4px solid #3498db;">
            <div style="font-size:0.85rem; color:var(--gray-500); text-transform:uppercase;">Canonical Tags</div>
            <div style="font-size:1.8rem; font-weight:700; color:var(--green-dark); margin:6px 0;">100% Covered</div>
            <div style="font-size:0.85rem; color:var(--gray-600); margin-bottom:12px;">Self-referencing canonical URLs implemented across all clean routes.</div>
            <span class="badge" style="background:#e8f4fc; color:#2980b9; font-weight:600;">Clean URLs</span>
        </div>

        <div class="admin-card" style="border-left:4px solid #e67e22;">
            <div style="font-size:0.85rem; color:var(--gray-500); text-transform:uppercase;">301 Redirects</div>
            <div style="font-size:1.8rem; font-weight:700; color:var(--green-dark); margin:6px 0;">Redirect Engine</div>
            <div style="font-size:0.85rem; color:var(--gray-600); margin-bottom:12px;">Safely route old URLs to new canonical pages.</div>
            <a href="<?= SITE_URL ?>/admin/redirects" class="btn-admin btn-sm btn-outline">Manage 301 Redirects →</a>
        </div>
    </div>

    <div style="display:grid; grid-template-columns: 2fr 1fr; gap:24px;">
        
        <!-- Left: SEO Audit Checklist -->
        <div class="admin-card">
            <h3 class="admin-card-title">SEO Audit Checklist</h3>
            
            <?php if (!empty($missingPkgSeo)): ?>
            <div class="alert alert-error" style="margin-bottom:16px;">
                <strong><?= count($missingPkgSeo) ?> package(s) have missing custom SEO meta tags:</strong>
                <ul style="margin-left:20px; margin-top:8px;">
                    <?php foreach ($missingPkgSeo as $mp): ?>
                    <li>
                        <a href="<?= SITE_URL ?>/admin/packages/edit/<?= $mp['id'] ?>" style="color:var(--green-dark); font-weight:600;">
                            <?= e($mp['title']) ?>
                        </a>
                        – <em>Fallback to default description</em>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php else: ?>
            <div class="alert alert-success" style="margin-bottom:16px;">
                ✓ Excellent! All published packages have custom SEO metadata configured.
            </div>
            <?php endif; ?>

            <div style="overflow-x:auto;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Page / Section</th>
                            <th>Canonical URL</th>
                            <th>SEO Title & Meta</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Home Page</strong></td>
                            <td><code>/</code></td>
                            <td><span style="color:green;">✓ Configured</span></td>
                            <td><a href="<?= SITE_URL ?>/admin/pages?tab=home" class="btn-admin btn-sm btn-outline">Edit SEO</a></td>
                        </tr>
                        <tr>
                            <td><strong>About Us</strong></td>
                            <td><code>/about-us</code></td>
                            <td><span style="color:green;">✓ Configured</span></td>
                            <td><a href="<?= SITE_URL ?>/admin/pages?tab=about" class="btn-admin btn-sm btn-outline">Edit SEO</a></td>
                        </tr>
                        <tr>
                            <td><strong>Contact Us</strong></td>
                            <td><code>/contact-us</code></td>
                            <td><span style="color:green;">✓ Configured</span></td>
                            <td><a href="<?= SITE_URL ?>/admin/settings" class="btn-admin btn-sm btn-outline">Edit SEO</a></td>
                        </tr>
                        <tr>
                            <td><strong>Umrah Packages</strong></td>
                            <td><code>/umrah-packages</code></td>
                            <td><span style="color:green;">✓ Configured</span></td>
                            <td><a href="<?= SITE_URL ?>/admin/packages" class="btn-admin btn-sm btn-outline">Manage</a></td>
                        </tr>
                        <tr>
                            <td><strong>Blog Articles</strong></td>
                            <td><code>/blog</code></td>
                            <td><span style="color:green;">✓ Configured</span></td>
                            <td><a href="<?= SITE_URL ?>/admin/blog" class="btn-admin btn-sm btn-outline">Manage</a></td>
                        </tr>
                        <tr>
                            <td><strong>Privacy Policy</strong></td>
                            <td><code>/privacy-policy</code></td>
                            <td><span style="color:green;">✓ Configured</span></td>
                            <td><a href="<?= SITE_URL ?>/admin/pages?tab=privacy" class="btn-admin btn-sm btn-outline">Edit SEO</a></td>
                        </tr>
                        <tr>
                            <td><strong>Terms & Conditions</strong></td>
                            <td><code>/terms-and-conditions</code></td>
                            <td><span style="color:green;">✓ Configured</span></td>
                            <td><a href="<?= SITE_URL ?>/admin/pages?tab=terms" class="btn-admin btn-sm btn-outline">Edit SEO</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Right: Robots.txt Editor -->
        <div class="admin-card">
            <h3 class="admin-card-title">Robots.txt Editor</h3>
            <p style="font-size:0.85rem; color:var(--gray-500); margin-bottom:12px;">Controls search engine crawlers (Googlebot, Bingbot) accessing your site.</p>
            
            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                
                <div class="form-group">
                    <textarea name="robots_txt" class="form-control" rows="10" style="font-family:monospace; font-size:0.85rem;"><?= e($currentRobots) ?></textarea>
                </div>

                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <a href="<?= SITE_URL ?>/robots.txt" target="_blank" class="btn-admin btn-outline btn-sm">View Live robots.txt ↗</a>
                    <button type="submit" class="btn-admin btn-primary">Save Robots.txt</button>
                </div>
            </form>
        </div>

    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

<?php
// ============================================================
// Shahin Travels – Admin Package Add/Edit Form
// ============================================================
require_once __DIR__ . '/includes/header.php';

$db = getDB();
$isEdit = !empty($packageId);
$pkg = null;
$prices = ['Quad' => '', 'Triple' => '', 'Double' => ''];
$itinerary = [];
$errors = [];

if ($isEdit) {
    $stmt = $db->prepare("SELECT * FROM packages WHERE id = ?");
    $stmt->execute([(int)$packageId]);
    $pkg = $stmt->fetch();
    if (!$pkg) {
        setFlash('error', 'Package not found.');
        redirect(SITE_URL . '/admin/packages');
    }

    // Load prices
    $priceRows = $db->query("SELECT sharing_type, price FROM package_prices WHERE package_id = " . (int)$packageId)->fetchAll();
    foreach ($priceRows as $pr) {
        $prices[$pr['sharing_type']] = $pr['price'];
    }

    // Load itinerary
    $itinerary = $db->query("SELECT * FROM package_itinerary WHERE package_id = " . (int)$packageId . " ORDER BY day_number ASC")->fetchAll();
}

// Fetch categories & hotels
$categories = $db->query("SELECT id, name FROM categories ORDER BY name ASC")->fetchAll();
$makkahHotels = $db->query("SELECT id, name, stars, distance_haram FROM hotels WHERE city = 'Makkah' ORDER BY name ASC")->fetchAll();
$madinahHotels = $db->query("SELECT id, name, stars, distance_haram FROM hotels WHERE city = 'Madinah' ORDER BY name ASC")->fetchAll();

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        $errors[] = 'Security token expired. Please try again.';
    } else {
        $title          = trim($_POST['title'] ?? '');
        $categoryId     = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
        $slug           = slugify(!empty($_POST['slug']) ? $_POST['slug'] : $title);
        $depDate        = trim($_POST['departure_date'] ?? '');
        $retDate        = trim($_POST['return_date'] ?? '');
        $days           = (int)($_POST['days'] ?? 0);
        $nights         = (int)($_POST['nights'] ?? 0);
        $depCity        = trim($_POST['departure_city'] ?? 'Delhi');
        $airline        = trim($_POST['airline'] ?? '');
        $flightDetails  = trim($_POST['flight_details'] ?? '');
        $makkahHotelId  = !empty($_POST['makkah_hotel_id']) ? (int)$_POST['makkah_hotel_id'] : null;
        $makkahNights   = (int)($_POST['makkah_nights'] ?? 0);
        $madinahHotelId = !empty($_POST['madinah_hotel_id']) ? (int)$_POST['madinah_hotel_id'] : null;
        $madinahNights  = (int)($_POST['madinah_nights'] ?? 0);
        $shortDesc      = trim($_POST['short_description'] ?? '');
        $overview       = trim($_POST['overview'] ?? '');
        $importantInfo  = trim($_POST['important_info'] ?? '');
        $status         = in_array($_POST['status'] ?? '', ['published', 'draft']) ? $_POST['status'] : 'draft';
        $isTrending     = !empty($_POST['is_trending']) ? 1 : 0;
        
        // Arrays stored as JSON
        $highlights     = array_values(array_filter(array_map('trim', explode("\n", $_POST['highlights'] ?? ''))));
        $inclusions     = array_values(array_filter(array_map('trim', explode("\n", $_POST['inclusions'] ?? ''))));
        $exclusions     = array_values(array_filter(array_map('trim', explode("\n", $_POST['exclusions'] ?? ''))));
        
        // SEO
        $seoTitle       = trim($_POST['seo_title'] ?? '');
        $seoDesc        = trim($_POST['seo_description'] ?? '');
        $ogTitle        = trim($_POST['og_title'] ?? '');
        $ogDesc         = trim($_POST['og_description'] ?? '');
        $noindex        = !empty($_POST['noindex']) ? 1 : 0;
        
        // Cover Image Upload
        $coverImage = $pkg['cover_image'] ?? '';
        if (!empty($_FILES['cover_image_file']['name'])) {
            $up = handleUpload($_FILES['cover_image_file'], 'packages');
            if ($up['success']) {
                $coverImage = $up['filename'];
            } else {
                $errors[] = 'Cover Image Upload Error: ' . $up['error'];
            }
        } elseif (!empty($_POST['cover_image_url'])) {
            $coverImage = trim($_POST['cover_image_url']);
        }

        // Basic validations
        if (!$title) $errors[] = 'Package title is required.';
        if (!$depDate) $errors[] = 'Departure date is required.';
        if (!$retDate) $errors[] = 'Return date is required.';

        // Check unique slug
        $checkSlug = $db->prepare("SELECT id FROM packages WHERE slug = ? " . ($isEdit ? "AND id != " . (int)$packageId : ""));
        $checkSlug->execute([$slug]);
        if ($checkSlug->fetch()) {
            $slug .= '-' . time();
        }

        if (empty($errors)) {
            $jsonHighlights = json_encode($highlights);
            $jsonInclusions = json_encode($inclusions);
            $jsonExclusions = json_encode($exclusions);

            if ($isEdit) {
                $sql = "UPDATE packages SET 
                    title=?, slug=?, category_id=?, departure_date=?, return_date=?, days=?, nights=?, 
                    departure_city=?, airline=?, flight_details=?, makkah_hotel_id=?, makkah_nights=?, 
                    madinah_hotel_id=?, madinah_nights=?, short_description=?, overview=?, highlights=?, 
                    inclusions=?, exclusions=?, important_info=?, cover_image=?, status=?, is_trending=?, 
                    seo_title=?, seo_description=?, og_title=?, og_description=?, noindex=? 
                    WHERE id=?";
                $params = [
                    $title, $slug, $categoryId, $depDate, $retDate, $days, $nights,
                    $depCity, $airline, $flightDetails, $makkahHotelId, $makkahNights,
                    $madinahHotelId, $madinahNights, $shortDesc, $overview, $jsonHighlights,
                    $jsonInclusions, $jsonExclusions, $importantInfo, $coverImage, $status, $isTrending,
                    $seoTitle, $seoDesc, $ogTitle, $ogDesc, $noindex, (int)$packageId
                ];
                $db->prepare($sql)->execute($params);
                $savedPkgId = (int)$packageId;
                setFlash('success', 'Package updated successfully!');
            } else {
                $sql = "INSERT INTO packages (
                    title, slug, category_id, departure_date, return_date, days, nights, 
                    departure_city, airline, flight_details, makkah_hotel_id, makkah_nights, 
                    madinah_hotel_id, madinah_nights, short_description, overview, highlights, 
                    inclusions, exclusions, important_info, cover_image, status, is_trending, 
                    seo_title, seo_description, og_title, og_description, noindex
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                $params = [
                    $title, $slug, $categoryId, $depDate, $retDate, $days, $nights,
                    $depCity, $airline, $flightDetails, $makkahHotelId, $makkahNights,
                    $madinahHotelId, $madinahNights, $shortDesc, $overview, $jsonHighlights,
                    $jsonInclusions, $jsonExclusions, $importantInfo, $coverImage, $status, $isTrending,
                    $seoTitle, $seoDesc, $ogTitle, $ogDesc, $noindex
                ];
                $db->prepare($sql)->execute($params);
                $savedPkgId = (int)$db->lastInsertId();
                setFlash('success', 'Package created successfully!');
            }

            // Save prices
            $db->prepare("DELETE FROM package_prices WHERE package_id = ?")->execute([$savedPkgId]);
            $priceIns = $db->prepare("INSERT INTO package_prices (package_id, sharing_type, price) VALUES (?, ?, ?)");
            foreach (['Quad', 'Triple', 'Double'] as $st) {
                $prVal = !empty($_POST['price_' . strtolower($st)]) ? (float)$_POST['price_' . strtolower($st)] : 0;
                if ($prVal > 0) {
                    $priceIns->execute([$savedPkgId, $st, $prVal]);
                }
            }

            // Save Itinerary
            $db->prepare("DELETE FROM package_itinerary WHERE package_id = ?")->execute([$savedPkgId]);
            if (!empty($_POST['itinerary_day']) && is_array($_POST['itinerary_day'])) {
                $itinIns = $db->prepare("INSERT INTO package_itinerary (package_id, day_number, title, description) VALUES (?, ?, ?, ?)");
                foreach ($_POST['itinerary_day'] as $idx => $dayNum) {
                    $itinTitle = trim($_POST['itinerary_title'][$idx] ?? '');
                    $itinDesc  = trim($_POST['itinerary_desc'][$idx] ?? '');
                    if ($itinTitle) {
                        $itinIns->execute([$savedPkgId, (int)$dayNum, $itinTitle, $itinDesc]);
                    }
                }
            }

            redirect(SITE_URL . '/admin/packages');
        }
    }
}

// Current values for fields
$fTitle        = $_POST['title'] ?? $pkg['title'] ?? '';
$fSlug         = $_POST['slug'] ?? $pkg['slug'] ?? '';
$fCategory     = $_POST['category_id'] ?? $pkg['category_id'] ?? '';
$fDepDate      = $_POST['departure_date'] ?? $pkg['departure_date'] ?? '';
$fRetDate      = $_POST['return_date'] ?? $pkg['return_date'] ?? '';
$fDays         = $_POST['days'] ?? $pkg['days'] ?? 14;
$fNights       = $_POST['nights'] ?? $pkg['nights'] ?? 13;
$fDepCity      = $_POST['departure_city'] ?? $pkg['departure_city'] ?? 'Delhi';
$fAirline      = $_POST['airline'] ?? $pkg['airline'] ?? 'Saudi Airlines';
$fFlight       = $_POST['flight_details'] ?? $pkg['flight_details'] ?? '';
$fMakkahHotel  = $_POST['makkah_hotel_id'] ?? $pkg['makkah_hotel_id'] ?? '';
$fMakkahNights = $_POST['makkah_nights'] ?? $pkg['makkah_nights'] ?? 8;
$fMadinahHotel = $_POST['madinah_hotel_id'] ?? $pkg['madinah_hotel_id'] ?? '';
$fMadinahNights= $_POST['madinah_nights'] ?? $pkg['madinah_nights'] ?? 5;
$fShortDesc    = $_POST['short_description'] ?? $pkg['short_description'] ?? '';
$fOverview     = $_POST['overview'] ?? $pkg['overview'] ?? '';
$fImportant    = $_POST['important_info'] ?? $pkg['important_info'] ?? '';
$fStatus       = $_POST['status'] ?? $pkg['status'] ?? 'published';
$fTrending     = isset($_POST['is_trending']) ? !empty($_POST['is_trending']) : (!empty($pkg['is_trending']));
$fCover        = $pkg['cover_image'] ?? '';

$fHighlights   = $_POST['highlights'] ?? (is_array(json_decode($pkg['highlights'] ?? '', true)) ? implode("\n", json_decode($pkg['highlights'], true)) : '');
$fInclusions   = $_POST['inclusions'] ?? (is_array(json_decode($pkg['inclusions'] ?? '', true)) ? implode("\n", json_decode($pkg['inclusions'], true)) : "Return Air Ticket (Saudi Airlines)\nUmrah Visa with Insurance\nHotels in Makkah and Madinah\nDaily Buffet Breakfast\nAC Luxury Bus Transfers\nGuided Ziyarats in Makkah & Madinah\n5 Liters Zamzam Water");
$fExclusions   = $_POST['exclusions'] ?? (is_array(json_decode($pkg['exclusions'] ?? '', true)) ? implode("\n", json_decode($pkg['exclusions'], true)) : "Personal room service & laundry\nExcess baggage fees\nAnything not mentioned in inclusions");

$fSeoTitle     = $_POST['seo_title'] ?? $pkg['seo_title'] ?? '';
$fSeoDesc      = $_POST['seo_description'] ?? $pkg['seo_description'] ?? '';
$fOgTitle      = $_POST['og_title'] ?? $pkg['og_title'] ?? '';
$fOgDesc       = $_POST['og_description'] ?? $pkg['og_description'] ?? '';
$fNoindex      = isset($_POST['noindex']) ? !empty($_POST['noindex']) : (!empty($pkg['noindex']));
?>

<div class="admin-content-inner">
    <div class="content-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
        <div>
            <h2><?= $isEdit ? 'Edit Package: ' . e($fTitle) : 'Add New Umrah Package' ?></h2>
            <p style="color:var(--gray-500); font-size:0.9rem;">Fill in package specifications, pricing, itinerary, and SEO settings.</p>
        </div>
        <a href="<?= SITE_URL ?>/admin/packages" class="btn-admin btn-outline">← Back to Packages</a>
    </div>

    <?php if (!empty($errors)): ?>
    <div class="alert alert-error" style="margin-bottom:20px;">
        <strong>Please correct the following:</strong>
        <ul style="margin-left:20px; margin-top:6px;">
            <?php foreach ($errors as $err): ?>
            <li><?= e($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

        <div style="display:grid; grid-template-columns: 2fr 1fr; gap:24px;">
            
            <!-- Main Details Left Column -->
            <div style="display:flex; flex-direction:column; gap:24px;">
                
                <!-- Card: Basic Info -->
                <div class="admin-card">
                    <h3 class="admin-card-title">1. Basic Information</h3>
                    <div class="form-group">
                        <label class="form-label">Package Title <span class="required">*</span></label>
                        <input type="text" name="title" id="pkg_title" class="form-control" placeholder="e.g. 14 Days Gold Umrah Package" value="<?= e($fTitle) ?>" required>
                    </div>

                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
                        <div class="form-group">
                            <label class="form-label">URL Slug</label>
                            <input type="text" name="slug" id="pkg_slug" class="form-control" placeholder="14-days-gold-umrah" value="<?= e($fSlug) ?>">
                            <small style="color:var(--gray-400);">Leave blank to generate automatically.</small>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Package Category <span class="required">*</span></label>
                            <select name="category_id" class="form-control" required>
                                <option value="">Select Category</option>
                                <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>" <?= $fCategory == $cat['id'] ? 'selected' : '' ?>><?= e($cat['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div style="display:grid; grid-template-columns: repeat(4, 1fr); gap:12px;">
                        <div class="form-group">
                            <label class="form-label">Departure Date <span class="required">*</span></label>
                            <input type="date" name="departure_date" id="dep_date" class="form-control" value="<?= e($fDepDate) ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Return Date <span class="required">*</span></label>
                            <input type="date" name="return_date" id="ret_date" class="form-control" value="<?= e($fRetDate) ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Total Days</label>
                            <input type="number" name="days" id="pkg_days" class="form-control" value="<?= e($fDays) ?>" min="1">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Total Nights</label>
                            <input type="number" name="nights" id="pkg_nights" class="form-control" value="<?= e($fNights) ?>" min="1">
                        </div>
                    </div>

                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
                        <div class="form-group">
                            <label class="form-label">Departure City</label>
                            <input type="text" name="departure_city" class="form-control" value="<?= e($fDepCity) ?>" placeholder="Delhi, Mumbai, etc.">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Airline Carrier</label>
                            <input type="text" name="airline" class="form-control" value="<?= e($fAirline) ?>" placeholder="Saudi Airlines">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Flight Details / Schedule</label>
                        <input type="text" name="flight_details" class="form-control" value="<?= e($fFlight) ?>" placeholder="Direct flight SV-757 (DEL - JED) / SV-758 (MED - DEL)">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Short Summary (Displayed on package cards)</label>
                        <textarea name="short_description" class="form-control" rows="2" placeholder="Brief summary of package highlight features..."><?= e($fShortDesc) ?></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Full Package Overview</label>
                        <textarea name="overview" class="form-control" rows="5" placeholder="Detailed description of what makes this spiritual trip unforgettable..."><?= e($fOverview) ?></textarea>
                    </div>
                </div>

                <!-- Card: Hotels & Stays -->
                <div class="admin-card">
                    <h3 class="admin-card-title">2. Hotel Accommodations</h3>
                    <div style="display:grid; grid-template-columns: 3fr 1fr; gap:16px; margin-bottom:16px;">
                        <div class="form-group">
                            <label class="form-label">Makkah Hotel</label>
                            <select name="makkah_hotel_id" class="form-control">
                                <option value="">Select Makkah Hotel</option>
                                <?php foreach ($makkahHotels as $h): ?>
                                <option value="<?= $h['id'] ?>" <?= $fMakkahHotel == $h['id'] ? 'selected' : '' ?>>
                                    <?= e($h['name']) ?> (<?= $h['stars'] ?>★ – <?= $h['distance_haram'] ?>m from Haram)
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Makkah Nights</label>
                            <input type="number" name="makkah_nights" class="form-control" value="<?= e($fMakkahNights) ?>" min="0">
                        </div>
                    </div>

                    <div style="display:grid; grid-template-columns: 3fr 1fr; gap:16px;">
                        <div class="form-group">
                            <label class="form-label">Madinah Hotel</label>
                            <select name="madinah_hotel_id" class="form-control">
                                <option value="">Select Madinah Hotel</option>
                                <?php foreach ($madinahHotels as $h): ?>
                                <option value="<?= $h['id'] ?>" <?= $fMadinahHotel == $h['id'] ? 'selected' : '' ?>>
                                    <?= e($h['name']) ?> (<?= $h['stars'] ?>★ – <?= $h['distance_haram'] ?>m from Haram)
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Madinah Nights</label>
                            <input type="number" name="madinah_nights" class="form-control" value="<?= e($fMadinahNights) ?>" min="0">
                        </div>
                    </div>
                </div>

                <!-- Card: Room Pricing Table -->
                <div class="admin-card">
                    <h3 class="admin-card-title">3. Pricing Per Person (INR)</h3>
                    <p style="font-size:0.85rem; color:var(--gray-500); margin-bottom:16px;">Enter pricing per pilgrim according to room occupancy sharing.</p>
                    
                    <div style="display:grid; grid-template-columns: repeat(3, 1fr); gap:16px;">
                        <div class="form-group">
                            <label class="form-label">Quad Sharing (4 beds)</label>
                            <div style="position:relative;">
                                <span style="position:absolute; left:12px; top:50%; transform:translateY(-50%); color:var(--gray-500); font-weight:600;">₹</span>
                                <input type="number" name="price_quad" class="form-control" style="padding-left:28px;" placeholder="e.g. 75786" value="<?= e($prices['Quad'] ?? '') ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Triple Sharing (3 beds)</label>
                            <div style="position:relative;">
                                <span style="position:absolute; left:12px; top:50%; transform:translateY(-50%); color:var(--gray-500); font-weight:600;">₹</span>
                                <input type="number" name="price_triple" class="form-control" style="padding-left:28px;" placeholder="e.g. 85786" value="<?= e($prices['Triple'] ?? '') ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Double Sharing (2 beds)</label>
                            <div style="position:relative;">
                                <span style="position:absolute; left:12px; top:50%; transform:translateY(-50%); color:var(--gray-500); font-weight:600;">₹</span>
                                <input type="number" name="price_double" class="form-control" style="padding-left:28px;" placeholder="e.g. 99786" value="<?= e($prices['Double'] ?? '') ?>">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Card: Lists & Important Info -->
                <div class="admin-card">
                    <h3 class="admin-card-title">4. Inclusions, Exclusions & Highlights</h3>
                    <div class="form-group">
                        <label class="form-label">Package Inclusions (One point per line)</label>
                        <textarea name="inclusions" class="form-control" rows="5"><?= e($fInclusions) ?></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Package Exclusions (One point per line)</label>
                        <textarea name="exclusions" class="form-control" rows="4"><?= e($fExclusions) ?></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Important Information / Travel Guidelines</label>
                        <textarea name="important_info" class="form-control" rows="4" placeholder="Passport validity rules, vaccination certificate requirements, baggage notices..."><?= e($fImportant) ?></textarea>
                    </div>
                </div>

                <!-- Card: Day-wise Itinerary -->
                <div class="admin-card">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
                        <h3 class="admin-card-title" style="margin:0;">5. Day-wise Itinerary</h3>
                        <button type="button" class="btn-admin btn-outline" id="add-itinerary-btn">+ Add Day</button>
                    </div>
                    
                    <div id="itinerary-container" style="display:flex; flex-direction:column; gap:16px;">
                        <?php if (!empty($itinerary)): ?>
                            <?php foreach ($itinerary as $it): ?>
                            <div class="itinerary-row" style="background:var(--cream); padding:16px; border-radius:12px; border:1px solid var(--gray-200);">
                                <div style="display:grid; grid-template-columns: 80px 1fr 40px; gap:12px; align-items:center; margin-bottom:10px;">
                                    <div>
                                        <label style="font-size:0.75rem; color:var(--gray-500);">Day</label>
                                        <input type="number" name="itinerary_day[]" class="form-control" value="<?= e($it['day_number']) ?>">
                                    </div>
                                    <div>
                                        <label style="font-size:0.75rem; color:var(--gray-500);">Title</label>
                                        <input type="text" name="itinerary_title[]" class="form-control" placeholder="e.g. Arrival in Jeddah & First Umrah" value="<?= e($it['title']) ?>">
                                    </div>
                                    <div>
                                        <label>&nbsp;</label>
                                        <button type="button" class="remove-itin-btn" style="background:none; border:none; color:red; cursor:pointer; font-size:1.2rem;" title="Remove Day">✕</button>
                                    </div>
                                </div>
                                <div>
                                    <textarea name="itinerary_desc[]" class="form-control" rows="2" placeholder="Activities and details for this day..."><?= e($it['description']) ?></textarea>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <!-- Default sample days -->
                            <div class="itinerary-row" style="background:var(--cream); padding:16px; border-radius:12px; border:1px solid var(--gray-200);">
                                <div style="display:grid; grid-template-columns: 80px 1fr 40px; gap:12px; align-items:center; margin-bottom:10px;">
                                    <div>
                                        <label style="font-size:0.75rem; color:var(--gray-500);">Day</label>
                                        <input type="number" name="itinerary_day[]" class="form-control" value="1">
                                    </div>
                                    <div>
                                        <label style="font-size:0.75rem; color:var(--gray-500);">Title</label>
                                        <input type="text" name="itinerary_title[]" class="form-control" placeholder="e.g. Departure from Delhi & Arrival at Jeddah" value="Departure from Delhi & Arrival in Jeddah">
                                    </div>
                                    <div>
                                        <button type="button" class="remove-itin-btn" style="background:none; border:none; color:red; cursor:pointer; font-size:1.2rem;">✕</button>
                                    </div>
                                </div>
                                <textarea name="itinerary_desc[]" class="form-control" rows="2">Board scheduled direct flight. Meet & assist at Jeddah airport and transfer to Makkah hotel in air-conditioned bus. Perform first Umrah with experienced group leader.</textarea>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>

            <!-- Sidebar Right Column (Publish, Cover, SEO) -->
            <div style="display:flex; flex-direction:column; gap:24px;">
                
                <!-- Action / Save Box -->
                <div class="admin-card" style="position:sticky; top:20px; z-index:10;">
                    <h3 class="admin-card-title">Publish Status</h3>
                    
                    <div class="form-group">
                        <label class="form-label">Visibility Status</label>
                        <select name="status" class="form-control">
                            <option value="published" <?= $fStatus === 'published' ? 'selected' : '' ?>>Published (Live)</option>
                            <option value="draft" <?= $fStatus === 'draft' ? 'selected' : '' ?>>Draft (Hidden)</option>
                        </select>
                    </div>

                    <div class="form-group" style="margin-bottom:20px;">
                        <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
                            <input type="checkbox" name="is_trending" value="1" <?= $fTrending ? 'checked' : '' ?>>
                            <span style="font-weight:600; color:var(--green-dark);">Mark as Trending Package</span>
                        </label>
                        <small style="color:var(--gray-400); display:block; margin-top:4px;">Appears on home page Trending Packages section.</small>
                    </div>

                    <button type="submit" class="btn-admin btn-primary" style="width:100%; justify-content:center; padding:14px; font-size:1rem;">
                        💾 <?= $isEdit ? 'Save Changes' : 'Publish Package' ?>
                    </button>
                </div>

                <!-- Cover Image Box -->
                <div class="admin-card">
                    <h3 class="admin-card-title">Cover Image</h3>
                    <?php if ($fCover): ?>
                    <div style="margin-bottom:14px; border-radius:8px; overflow:hidden; border:1px solid var(--gray-200);">
                        <img src="<?= e(strpos($fCover, 'http') === 0 ? $fCover : SITE_URL . '/public/images/packages/' . $fCover) ?>" alt="Cover" style="width:100%; height:160px; object-fit:cover; display:block;">
                    </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <label class="form-label">Upload New Image</label>
                        <input type="file" name="cover_image_file" class="form-control" accept="image/*">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Or Image URL</label>
                        <input type="text" name="cover_image_url" class="form-control" placeholder="https://..." value="<?= e(strpos($fCover, 'http') === 0 ? $fCover : '') ?>">
                    </div>
                </div>

                <!-- SEO Controls -->
                <div class="admin-card">
                    <h3 class="admin-card-title">🔍 SEO Controls</h3>
                    
                    <div class="form-group">
                        <label class="form-label">Meta Title</label>
                        <input type="text" name="seo_title" class="form-control" placeholder="Defaults to package title" value="<?= e($fSeoTitle) ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Meta Description</label>
                        <textarea name="seo_description" class="form-control" rows="3" placeholder="Compelling 150-160 char snippet for Google..."><?= e($fSeoDesc) ?></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Social Share (OG) Title</label>
                        <input type="text" name="og_title" class="form-control" value="<?= e($fOgTitle) ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Social Share (OG) Description</label>
                        <textarea name="og_description" class="form-control" rows="2"><?= e($fOgDesc) ?></textarea>
                    </div>

                    <div class="form-group">
                        <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
                            <input type="checkbox" name="noindex" value="1" <?= $fNoindex ? 'checked' : '' ?>>
                            <span style="color:#c0392b; font-weight:600;">Hide from Search Engines (noindex)</span>
                        </label>
                    </div>
                </div>

            </div>

        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto-calculate days between dates
    const dep = document.getElementById('dep_date');
    const ret = document.getElementById('ret_date');
    const days = document.getElementById('pkg_days');
    const nights = document.getElementById('pkg_nights');

    function updateDuration() {
        if (dep.value && ret.value) {
            const d1 = new Date(dep.value);
            const d2 = new Date(ret.value);
            const diff = Math.ceil((d2 - d1) / (1000 * 60 * 60 * 24));
            if (diff > 0) {
                days.value = diff + 1;
                nights.value = diff;
            }
        }
    }
    dep.addEventListener('change', updateDuration);
    ret.addEventListener('change', updateDuration);

    // Auto-slug from title
    const title = document.getElementById('pkg_title');
    const slug = document.getElementById('pkg_slug');
    title.addEventListener('blur', function() {
        if (!slug.value) {
            slug.value = title.value.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
        }
    });

    // Dynamic itinerary rows
    const itContainer = document.getElementById('itinerary-container');
    const addBtn = document.getElementById('add-itinerary-btn');

    addBtn.addEventListener('click', function() {
        const rowCount = itContainer.querySelectorAll('.itinerary-row').length + 1;
        const row = document.createElement('div');
        row.className = 'itinerary-row';
        row.style.cssText = 'background:var(--cream); padding:16px; border-radius:12px; border:1px solid var(--gray-200);';
        row.innerHTML = `
            <div style="display:grid; grid-template-columns: 80px 1fr 40px; gap:12px; align-items:center; margin-bottom:10px;">
                <div>
                    <label style="font-size:0.75rem; color:var(--gray-500);">Day</label>
                    <input type="number" name="itinerary_day[]" class="form-control" value="${rowCount}">
                </div>
                <div>
                    <label style="font-size:0.75rem; color:var(--gray-500);">Title</label>
                    <input type="text" name="itinerary_title[]" class="form-control" placeholder="e.g. Ziyarat in Makkah">
                </div>
                <div>
                    <label>&nbsp;</label>
                    <button type="button" class="remove-itin-btn" style="background:none; border:none; color:red; cursor:pointer; font-size:1.2rem;">✕</button>
                </div>
            </div>
            <div>
                <textarea name="itinerary_desc[]" class="form-control" rows="2" placeholder="Activities and details for this day..."></textarea>
            </div>
        `;
        itContainer.appendChild(row);
    });

    itContainer.addEventListener('click', function(e) {
        if (e.target && e.target.classList.contains('remove-itin-btn')) {
            const row = e.target.closest('.itinerary-row');
            if (row) row.remove();
        }
    });
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

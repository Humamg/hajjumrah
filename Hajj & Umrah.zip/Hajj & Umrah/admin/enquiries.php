<?php
// ============================================================
// Shahin Travels – Admin Enquiries & Leads Management
// ============================================================
$adminPageTitle = 'Enquiries & Leads';
require_once __DIR__ . '/includes/header.php';

$db = getDB();
$action = $_GET['action'] ?? '';
$enqId  = (int)($_GET['id'] ?? 0);

// Delete
if ($action === 'delete' && $enqId) {
    $db->prepare("DELETE FROM enquiries WHERE id = ?")->execute([$enqId]);
    setFlash('success', 'Enquiry deleted.');
    redirect(SITE_URL . '/admin/enquiries');
}

// Toggle status (new <-> done)
if ($action === 'toggle' && $enqId) {
    $stmt = $db->prepare("SELECT status FROM enquiries WHERE id = ?");
    $stmt->execute([$enqId]);
    $curr = $stmt->fetchColumn();
    if ($curr) {
        $next = $curr === 'new' ? 'done' : 'new';
        $db->prepare("UPDATE enquiries SET status = ? WHERE id = ?")->execute([$next, $enqId]);
        setFlash('success', 'Enquiry status marked as ' . ucfirst($next) . '.');
    }
    redirect(SITE_URL . '/admin/enquiries');
}

// Filters
$statusFilter = $_GET['status'] ?? '';
$typeFilter   = $_GET['type'] ?? '';
$where = ['1=1'];
$params = [];

if (in_array($statusFilter, ['new', 'done'])) {
    $where[] = 'e.status = ?';
    $params[] = $statusFilter;
}
if ($typeFilter) {
    $where[] = 'e.type = ?';
    $params[] = $typeFilter;
}

$whereSql = implode(' AND ', $where);
$stmt = $db->prepare("
    SELECT e.*, p.title AS package_title
    FROM enquiries e
    LEFT JOIN packages p ON p.id = e.package_id
    WHERE $whereSql
    ORDER BY e.created_at DESC
");
$stmt->execute($params);
$enquiries = $stmt->fetchAll();

// Counts
$newCount  = (int)$db->query("SELECT COUNT(*) FROM enquiries WHERE status = 'new'")->fetchColumn();
$doneCount = (int)$db->query("SELECT COUNT(*) FROM enquiries WHERE status = 'done'")->fetchColumn();
?>

<div class="admin-content-inner">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; flex-wrap:wrap; gap:16px;">
        <div>
            <h2>Pilgrim Enquiries & Leads</h2>
            <p style="color:var(--gray-500); font-size:0.9rem;">Track website form submissions, call-back requests, and package inquiries.</p>
        </div>
        <div style="display:flex; gap:10px;">
            <a href="<?= SITE_URL ?>/admin/enquiries" class="btn-admin <?= empty($statusFilter) ? 'btn-primary' : 'btn-outline' ?>">All (<?= $newCount + $doneCount ?>)</a>
            <a href="<?= SITE_URL ?>/admin/enquiries?status=new" class="btn-admin <?= $statusFilter === 'new' ? 'btn-primary' : 'btn-outline' ?>" style="background:<?= $statusFilter === 'new' ? '#c0392b' : '' ?>; border-color:#c0392b; color:<?= $statusFilter === 'new' ? '#fff' : '#c0392b' ?>;">
                🔥 New Leads (<?= $newCount ?>)
            </a>
            <a href="<?= SITE_URL ?>/admin/enquiries?status=done" class="btn-admin <?= $statusFilter === 'done' ? 'btn-primary' : 'btn-outline' ?>">Completed (<?= $doneCount ?>)</a>
        </div>
    </div>

    <div class="admin-card">
        <div style="overflow-x:auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Date & Time</th>
                        <th>Pilgrim Name</th>
                        <th>Phone / WhatsApp</th>
                        <th>Type / Interest</th>
                        <th>Message</th>
                        <th>Status</th>
                        <th>Quick Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($enquiries)): ?>
                    <tr><td colspan="7" style="text-align:center; padding:36px; color:var(--gray-400);">No enquiries found under this filter.</td></tr>
                    <?php else: ?>
                        <?php foreach ($enquiries as $enq): ?>
                        <?php
                        $cleanPhone = preg_replace('/[^0-9]/', '', $enq['phone']);
                        if (strlen($cleanPhone) === 10) $cleanPhone = '91' . $cleanPhone;
                        $replyMsg = "Assalamualaikum " . urlencode($enq['name']) . ", thank you for contacting Shahin Travels regarding your Umrah enquiry.";
                        $waReplyUrl = "https://wa.me/" . $cleanPhone . "?text=" . $replyMsg;
                        ?>
                        <tr style="<?= $enq['status'] === 'new' ? 'background:rgba(212,168,83,0.06); font-weight:500;' : '' ?>">
                            <td style="font-size:0.8rem; color:var(--gray-500); white-space:nowrap;">
                                <?= date('d M Y, h:i A', strtotime($enq['created_at'])) ?>
                            </td>
                            <td>
                                <strong style="color:var(--green-dark);"><?= e($enq['name']) ?></strong>
                                <?php if ($enq['email']): ?>
                                <div style="font-size:0.75rem; color:var(--gray-400);"><?= e($enq['email']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong style="color:var(--green); font-size:0.95rem;"><?= e($enq['phone']) ?></strong>
                            </td>
                            <td>
                                <span class="badge" style="background:var(--cream); color:var(--gray-800); text-transform:uppercase; font-size:0.75rem;">
                                    <?= e($enq['type']) ?>
                                </span>
                                <?php if (!empty($enq['package_title'])): ?>
                                <div style="font-size:0.8rem; color:var(--gray-600); margin-top:2px;">
                                    📦 <?= e($enq['package_title']) ?>
                                </div>
                                <?php endif; ?>
                                <?php if (!empty($enq['preferred_month'])): ?>
                                <div style="font-size:0.75rem; color:var(--gold-dark); margin-top:2px;">
                                    🗓 Month: <?= e($enq['preferred_month']) ?>
                                </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div style="max-width:240px; font-size:0.85rem; color:var(--gray-600); line-height:1.4;">
                                    <?= nl2br(e($enq['message'] ?? 'Call back requested')) ?>
                                </div>
                            </td>
                            <td>
                                <a href="<?= SITE_URL ?>/admin/enquiries?action=toggle&id=<?= $enq['id'] ?>" class="badge badge-<?= $enq['status'] === 'new' ? 'draft' : 'published' ?>" style="cursor:pointer;" title="Click to toggle status">
                                    <?= $enq['status'] === 'new' ? '● New' : '✓ Done' ?>
                                </a>
                            </td>
                            <td>
                                <div style="display:flex; gap:6px; align-items:center;">
                                    <?php if ($cleanPhone): ?>
                                    <a href="<?= e($waReplyUrl) ?>" class="btn-admin btn-sm" style="background:#25D366; color:#fff;" target="_blank" title="Reply on WhatsApp">
                                        💬 WhatsApp
                                    </a>
                                    <?php endif; ?>
                                    <a href="<?= SITE_URL ?>/admin/enquiries?action=delete&id=<?= $enq['id'] ?>" class="btn-admin btn-sm btn-danger" onclick="return confirm('Delete this enquiry record?');" title="Delete">✕</a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

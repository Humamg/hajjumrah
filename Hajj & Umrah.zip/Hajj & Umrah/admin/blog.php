<?php
// ============================================================
// Shahin Travels – Admin Blog Management (admin/blog.php)
// ============================================================
$adminPageTitle = 'Blog Articles';
require_once __DIR__ . '/includes/header.php';

$db = getDB();
$action = $_GET['action'] ?? '';
$postId = (int)($_GET['id'] ?? 0);

// Delete action
if ($action === 'delete' && $postId) {
    $db->prepare("DELETE FROM blog_posts WHERE id = ?")->execute([$postId]);
    setFlash('success', 'Blog article deleted.');
    redirect(SITE_URL . '/admin/blog');
}

// Toggle status action
if ($action === 'toggle' && $postId) {
    $st = $db->prepare("SELECT status FROM blog_posts WHERE id = ?");
    $st->execute([$postId]);
    $curr = $st->fetchColumn();
    if ($curr) {
        $next = $curr === 'published' ? 'draft' : 'published';
        $db->prepare("UPDATE blog_posts SET status = ? WHERE id = ?")->execute([$next, $postId]);
        setFlash('success', 'Article status updated.');
    }
    redirect(SITE_URL . '/admin/blog');
}

// Search and filter
$search = trim($_GET['q'] ?? '');
$catFilter = (int)($_GET['cat'] ?? 0);
$where = ['1=1'];
$params = [];

if ($search) {
    $where[] = '(bp.title LIKE ? OR bp.content LIKE ?)';
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($catFilter) {
    $where[] = 'bp.category_id = ?';
    $params[] = $catFilter;
}

$whereSql = implode(' AND ', $where);
$stmt = $db->prepare("
    SELECT bp.*, bc.name AS category_name
    FROM blog_posts bp
    LEFT JOIN blog_categories bc ON bc.id = bp.category_id
    WHERE $whereSql
    ORDER BY bp.published_at DESC
");
$stmt->execute($params);
$posts = $stmt->fetchAll();

$categories = $db->query("SELECT * FROM blog_categories ORDER BY name ASC")->fetchAll();
?>

<div class="admin-content-inner">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; flex-wrap:wrap; gap:16px;">
        <div>
            <h2>Blog Articles (<?= count($posts) ?>)</h2>
            <p style="color:var(--gray-500); font-size:0.9rem;">Manage pilgrim guides, visa notifications, and travel tips.</p>
        </div>
        <a href="<?= SITE_URL ?>/admin/blog/add" class="btn-admin btn-primary">+ Write New Article</a>
    </div>

    <!-- Search / Filter Bar -->
    <div class="admin-card" style="margin-bottom:20px; padding:16px;">
        <form method="GET" action="" style="display:flex; gap:12px; flex-wrap:wrap; align-items:center;">
            <input type="text" name="q" class="form-control" placeholder="Search by title or content..." value="<?= e($search) ?>" style="max-width:320px;">
            <select name="cat" class="form-control" style="max-width:200px;">
                <option value="">All Categories</option>
                <?php foreach ($categories as $c): ?>
                <option value="<?= $c['id'] ?>" <?= $catFilter == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn-admin btn-primary">Filter</button>
            <?php if ($search || $catFilter): ?>
            <a href="<?= SITE_URL ?>/admin/blog" class="btn-admin btn-outline">Reset</a>
            <?php endif; ?>
        </form>
    </div>

    <!-- Table -->
    <div class="admin-card">
        <div style="overflow-x:auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Article</th>
                        <th>Category</th>
                        <th>Author</th>
                        <th>Published Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($posts)): ?>
                    <tr><td colspan="6" style="text-align:center; padding:30px; color:var(--gray-400);">No blog articles found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($posts as $p): ?>
                        <tr>
                            <td>
                                <strong style="color:var(--green-dark);"><?= e($p['title']) ?></strong>
                                <div style="font-size:0.75rem; color:var(--gray-400);">/blog/<?= e($p['slug']) ?></div>
                            </td>
                            <td>
                                <span class="badge" style="background:var(--cream); color:var(--gray-700);">
                                    <?= e($p['category_name'] ?? 'General') ?>
                                </span>
                            </td>
                            <td><?= e($p['author']) ?></td>
                            <td><?= date('d M Y', strtotime($p['published_at'])) ?></td>
                            <td>
                                <a href="<?= SITE_URL ?>/admin/blog?action=toggle&id=<?= $p['id'] ?>" class="badge badge-<?= $p['status'] === 'published' ? 'published' : 'draft' ?>" title="Click to toggle status">
                                    <?= ucfirst($p['status']) ?>
                                </a>
                            </td>
                            <td>
                                <div style="display:flex; gap:8px;">
                                    <a href="<?= SITE_URL ?>/blog/<?= e($p['slug']) ?>" class="btn-admin btn-sm btn-outline" target="_blank">View</a>
                                    <a href="<?= SITE_URL ?>/admin/blog/edit/<?= $p['id'] ?>" class="btn-admin btn-sm btn-outline">Edit</a>
                                    <a href="<?= SITE_URL ?>/admin/blog?action=delete&id=<?= $p['id'] ?>" class="btn-admin btn-sm btn-danger" onclick="return confirm('Delete this article?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

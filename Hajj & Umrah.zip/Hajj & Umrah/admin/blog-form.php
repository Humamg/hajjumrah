<?php
// ============================================================
// Shahin Travels – Admin Blog Add/Edit Form
// ============================================================
require_once __DIR__ . '/includes/header.php';

$db = getDB();
$isEdit = !empty($postId);
$post = null;
$errors = [];

if ($isEdit) {
    $stmt = $db->prepare("SELECT * FROM blog_posts WHERE id = ?");
    $stmt->execute([(int)$postId]);
    $post = $stmt->fetch();
    if (!$post) {
        setFlash('error', 'Blog post not found.');
        redirect(SITE_URL . '/admin/blog');
    }
}

$categories = $db->query("SELECT * FROM blog_categories ORDER BY name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        $errors[] = 'Security token expired. Please try again.';
    } else {
        $title      = trim($_POST['title'] ?? '');
        $slug       = slugify(!empty($_POST['slug']) ? $_POST['slug'] : $title);
        $categoryId = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
        $author     = trim($_POST['author'] ?? 'Shahin Travels');
        $status     = in_array($_POST['status'] ?? '', ['published', 'draft']) ? $_POST['status'] : 'draft';
        $excerpt    = trim($_POST['excerpt'] ?? '');
        $content    = trim($_POST['content'] ?? '');
        $publishedAt= !empty($_POST['published_at']) ? $_POST['published_at'] : date('Y-m-d H:i:s');
        
        $seoTitle   = trim($_POST['seo_title'] ?? '');
        $seoDesc    = trim($_POST['seo_description'] ?? '');
        $ogTitle    = trim($_POST['og_title'] ?? '');
        $ogDesc     = trim($_POST['og_description'] ?? '');
        $noindex    = !empty($_POST['noindex']) ? 1 : 0;
        
        $featuredImage = $post['featured_image'] ?? '';
        if (!empty($_FILES['image_file']['name'])) {
            $up = handleUpload($_FILES['image_file'], 'blog');
            if ($up['success']) {
                $featuredImage = $up['filename'];
            } else {
                $errors[] = 'Image upload error: ' . $up['error'];
            }
        } elseif (!empty($_POST['featured_image_url'])) {
            $featuredImage = trim($_POST['featured_image_url']);
        }

        if (!$title) $errors[] = 'Blog post title is required.';
        if (!$content) $errors[] = 'Blog post content is required.';

        $check = $db->prepare("SELECT id FROM blog_posts WHERE slug = ? " . ($isEdit ? "AND id != " . (int)$postId : ""));
        $check->execute([$slug]);
        if ($check->fetch()) {
            $slug .= '-' . time();
        }

        if (empty($errors)) {
            if ($isEdit) {
                $sql = "UPDATE blog_posts SET title=?, slug=?, category_id=?, featured_image=?, excerpt=?, content=?, author=?, status=?, published_at=?, seo_title=?, seo_description=?, og_title=?, og_description=?, noindex=? WHERE id=?";
                $db->prepare($sql)->execute([$title, $slug, $categoryId, $featuredImage, $excerpt, $content, $author, $status, $publishedAt, $seoTitle, $seoDesc, $ogTitle, $ogDesc, $noindex, (int)$postId]);
                setFlash('success', 'Blog article updated successfully.');
            } else {
                $sql = "INSERT INTO blog_posts (title, slug, category_id, featured_image, excerpt, content, author, status, published_at, seo_title, seo_description, og_title, og_description, noindex) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                $db->prepare($sql)->execute([$title, $slug, $categoryId, $featuredImage, $excerpt, $content, $author, $status, $publishedAt, $seoTitle, $seoDesc, $ogTitle, $ogDesc, $noindex]);
                setFlash('success', 'Blog article created successfully.');
            }
            redirect(SITE_URL . '/admin/blog');
        }
    }
}

$fTitle     = $_POST['title'] ?? $post['title'] ?? '';
$fSlug      = $_POST['slug'] ?? $post['slug'] ?? '';
$fCategory  = $_POST['category_id'] ?? $post['category_id'] ?? '';
$fAuthor    = $_POST['author'] ?? $post['author'] ?? 'Shahin Travels';
$fStatus    = $_POST['status'] ?? $post['status'] ?? 'published';
$fExcerpt   = $_POST['excerpt'] ?? $post['excerpt'] ?? '';
$fContent   = $_POST['content'] ?? $post['content'] ?? '';
$fPubAt     = $_POST['published_at'] ?? (!empty($post['published_at']) ? date('Y-m-d\TH:i', strtotime($post['published_at'])) : date('Y-m-d\TH:i'));
$fImage     = $post['featured_image'] ?? '';
$fSeoTitle  = $_POST['seo_title'] ?? $post['seo_title'] ?? '';
$fSeoDesc   = $_POST['seo_description'] ?? $post['seo_description'] ?? '';
$fOgTitle   = $_POST['og_title'] ?? $post['og_title'] ?? '';
$fOgDesc    = $_POST['og_description'] ?? $post['og_description'] ?? '';
$fNoindex   = isset($_POST['noindex']) ? !empty($_POST['noindex']) : (!empty($post['noindex']));
?>

<div class="admin-content-inner">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
        <div>
            <h2><?= $isEdit ? 'Edit Article: ' . e($fTitle) : 'Write New Blog Article' ?></h2>
            <p style="color:var(--gray-500); font-size:0.9rem;">Publish guides, checklists, travel news, and spiritual tips for pilgrims.</p>
        </div>
        <a href="<?= SITE_URL ?>/admin/blog" class="btn-admin btn-outline">← Back to Blog</a>
    </div>

    <?php if (!empty($errors)): ?>
    <div class="alert alert-error" style="margin-bottom:20px;">
        <ul style="margin-left:20px;">
            <?php foreach ($errors as $err): ?>
            <li><?= e($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

        <div style="display:grid; grid-template-columns: 2fr 1fr; gap:24px;">
            
            <!-- Left Main Column -->
            <div style="display:flex; flex-direction:column; gap:24px;">
                <div class="admin-card">
                    <h3 class="admin-card-title">Article Details</h3>
                    
                    <div class="form-group">
                        <label class="form-label">Article Title <span class="required">*</span></label>
                        <input type="text" name="title" class="form-control" placeholder="e.g. Essential Umrah Packing Checklist for Families" value="<?= e($fTitle) ?>" required>
                    </div>

                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
                        <div class="form-group">
                            <label class="form-label">URL Slug</label>
                            <input type="text" name="slug" class="form-control" placeholder="essential-umrah-packing-checklist" value="<?= e($fSlug) ?>">
                            <small style="color:var(--gray-400);">Leave blank to generate automatically.</small>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Blog Category</label>
                            <select name="category_id" class="form-control">
                                <option value="">Select Category</option>
                                <?php foreach ($categories as $bc): ?>
                                <option value="<?= $bc['id'] ?>" <?= $fCategory == $bc['id'] ? 'selected' : '' ?>><?= e($bc['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Summary / Short Excerpt</label>
                        <textarea name="excerpt" class="form-control" rows="3" placeholder="Brief summary of the article appearing in blog card listings..."><?= e($fExcerpt) ?></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Full Article Content (HTML allowed) <span class="required">*</span></label>
                        <textarea name="content" class="form-control" rows="15" placeholder="Write the complete article content with headings, paragraphs, and bullet points..." required><?= e($fContent) ?></textarea>
                    </div>
                </div>

                <!-- SEO Card -->
                <div class="admin-card">
                    <h3 class="admin-card-title">🔍 SEO & Social Sharing</h3>
                    
                    <div class="form-group">
                        <label class="form-label">Meta SEO Title</label>
                        <input type="text" name="seo_title" class="form-control" placeholder="Custom Google title..." value="<?= e($fSeoTitle) ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Meta Description</label>
                        <textarea name="seo_description" class="form-control" rows="3" placeholder="150-160 character snippet for search results..."><?= e($fSeoDesc) ?></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">OG Title (Social Share)</label>
                        <input type="text" name="og_title" class="form-control" value="<?= e($fOgTitle) ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">OG Description</label>
                        <textarea name="og_description" class="form-control" rows="2"><?= e($fOgDesc) ?></textarea>
                    </div>

                    <div class="form-group">
                        <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
                            <input type="checkbox" name="noindex" value="1" <?= $fNoindex ? 'checked' : '' ?>>
                            <span style="color:#c0392b; font-weight:600;">Hide from Search Engines (noindex)</span>
                        </label>
                    </div>
                </div>
            </div>

            <!-- Right Sidebar Column -->
            <div style="display:flex; flex-direction:column; gap:24px;">
                <div class="admin-card">
                    <h3 class="admin-card-title">Publish Settings</h3>
                    
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-control">
                            <option value="published" <?= $fStatus === 'published' ? 'selected' : '' ?>>Published (Live)</option>
                            <option value="draft" <?= $fStatus === 'draft' ? 'selected' : '' ?>>Draft</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Author Name</label>
                        <input type="text" name="author" class="form-control" value="<?= e($fAuthor) ?>">
                    </div>

                    <div class="form-group" style="margin-bottom:24px;">
                        <label class="form-label">Publish Date & Time</label>
                        <input type="datetime-local" name="published_at" class="form-control" value="<?= e($fPubAt) ?>">
                    </div>

                    <button type="submit" class="btn-admin btn-primary" style="width:100%; justify-content:center; padding:12px;">
                        💾 <?= $isEdit ? 'Update Article' : 'Publish Article' ?>
                    </button>
                </div>

                <div class="admin-card">
                    <h3 class="admin-card-title">Featured Image</h3>
                    <?php if ($fImage): ?>
                    <div style="margin-bottom:12px; border-radius:8px; overflow:hidden;">
                        <img src="<?= e(strpos($fImage, 'http') === 0 ? $fImage : SITE_URL . '/public/images/blog/' . $fImage) ?>" alt="Featured" style="width:100%; height:160px; object-fit:cover; display:block;">
                    </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <label class="form-label">Upload Image</label>
                        <input type="file" name="image_file" class="form-control" accept="image/*">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Or Image URL</label>
                        <input type="text" name="featured_image_url" class="form-control" placeholder="https://..." value="<?= e(strpos($fImage, 'http') === 0 ? $fImage : '') ?>">
                    </div>
                </div>
            </div>

        </div>
    </form>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

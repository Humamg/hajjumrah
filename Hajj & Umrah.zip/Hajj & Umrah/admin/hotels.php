<?php
// ============================================================
// Shahin Travels – Admin Hotels Management
// ============================================================
$adminPageTitle = 'Hotels Management';
require_once __DIR__ . '/includes/header.php';

$db = getDB();
$action = $_GET['action'] ?? '';
$hotelId = (int)($_GET['id'] ?? 0);
$editHotel = null;

// Delete Hotel
if ($action === 'delete' && $hotelId) {
    // Unlink from packages
    $db->prepare("UPDATE packages SET makkah_hotel_id = NULL WHERE makkah_hotel_id = ?")->execute([$hotelId]);
    $db->prepare("UPDATE packages SET madinah_hotel_id = NULL WHERE madinah_hotel_id = ?")->execute([$hotelId]);
    $db->prepare("DELETE FROM hotels WHERE id = ?")->execute([$hotelId]);
    setFlash('success', 'Hotel deleted successfully.');
    redirect(SITE_URL . '/admin/hotels');
}

// Edit Hotel pre-load
if ($action === 'edit' && $hotelId) {
    $stmt = $db->prepare("SELECT * FROM hotels WHERE id = ?");
    $stmt->execute([$hotelId]);
    $editHotel = $stmt->fetch();
}

// Handle Add / Edit POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        setFlash('error', 'Security check failed. Please try again.');
    } else {
        $name      = trim($_POST['name'] ?? '');
        $city      = in_array($_POST['city'] ?? '', ['Makkah', 'Madinah']) ? $_POST['city'] : 'Makkah';
        $stars     = max(1, min(5, (int)($_POST['stars'] ?? 3)));
        $distance  = (int)($_POST['distance_haram'] ?? 0);
        $desc      = trim($_POST['description'] ?? '');
        $amenities = trim($_POST['amenities'] ?? '');
        $image     = trim($_POST['image'] ?? '');

        if (!empty($_FILES['image_file']['name'])) {
            $up = handleUpload($_FILES['image_file'], 'hotels');
            if ($up['success']) {
                $image = $up['filename'];
            }
        }

        if ($name) {
            if ($hotelId && $editHotel) {
                $sql = "UPDATE hotels SET name=?, city=?, stars=?, distance_haram=?, description=?, amenities=?, image=? WHERE id=?";
                $db->prepare($sql)->execute([$name, $city, $stars, $distance, $desc, $amenities, $image, $hotelId]);
                setFlash('success', 'Hotel updated successfully.');
            } else {
                $sql = "INSERT INTO hotels (name, city, stars, distance_haram, description, amenities, image) VALUES (?,?,?,?,?,?,?)";
                $db->prepare($sql)->execute([$name, $city, $stars, $distance, $desc, $amenities, $image]);
                setFlash('success', 'Hotel added successfully.');
            }
            redirect(SITE_URL . '/admin/hotels');
        } else {
            setFlash('error', 'Hotel name is required.');
        }
    }
}

// Filter by city
$cityFilter = $_GET['city'] ?? '';
$where = '1=1';
$params = [];
if (in_array($cityFilter, ['Makkah', 'Madinah'])) {
    $where = 'city = ?';
    $params[] = $cityFilter;
}

$stmt = $db->prepare("SELECT * FROM hotels WHERE $where ORDER BY city ASC, stars DESC, distance_haram ASC");
$stmt->execute($params);
$hotels = $stmt->fetchAll();
?>

<div class="admin-content-inner">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
        <div>
            <h2>Makkah & Madinah Hotels</h2>
            <p style="color:var(--gray-500); font-size:0.9rem;">Manage partnered hotel accommodations, star ratings, and walking distance to the Harams.</p>
        </div>
        <?php if ($editHotel): ?>
        <a href="<?= SITE_URL ?>/admin/hotels" class="btn-admin btn-outline">+ Add New Hotel</a>
        <?php endif; ?>
    </div>

    <!-- City Filters -->
    <div style="display:flex; gap:10px; margin-bottom:20px;">
        <a href="<?= SITE_URL ?>/admin/hotels" class="btn-admin <?= empty($cityFilter) ? 'btn-primary' : 'btn-outline' ?>">All Hotels</a>
        <a href="<?= SITE_URL ?>/admin/hotels?city=Makkah" class="btn-admin <?= $cityFilter === 'Makkah' ? 'btn-primary' : 'btn-outline' ?>">🕋 Makkah</a>
        <a href="<?= SITE_URL ?>/admin/hotels?city=Madinah" class="btn-admin <?= $cityFilter === 'Madinah' ? 'btn-primary' : 'btn-outline' ?>">🕌 Madinah</a>
    </div>

    <div style="display:grid; grid-template-columns: 2fr 1fr; gap:24px;">
        
        <!-- Left: Hotels Table -->
        <div class="admin-card">
            <h3 class="admin-card-title">Listed Hotels (<?= count($hotels) ?>)</h3>
            <div style="overflow-x:auto;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Hotel</th>
                            <th>City</th>
                            <th>Stars</th>
                            <th>Distance</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($hotels)): ?>
                        <tr><td colspan="5" style="text-align:center; padding:30px; color:var(--gray-400);">No hotels found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($hotels as $h): ?>
                            <tr>
                                <td>
                                    <strong><?= e($h['name']) ?></strong>
                                    <?php if ($h['amenities']): ?>
                                    <div style="font-size:0.75rem; color:var(--gray-500);"><?= e($h['amenities']) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge" style="background:<?= $h['city'] === 'Makkah' ? 'var(--green-light)' : 'var(--gold-light)' ?>; color:<?= $h['city'] === 'Makkah' ? 'var(--green-dark)' : 'var(--gold-dark)' ?>; font-weight:600;">
                                        <?= e($h['city']) ?>
                                    </span>
                                </td>
                                <td>
                                    <span style="color:#f39c12; letter-spacing:2px;"><?= str_repeat('★', $h['stars']) ?></span>
                                </td>
                                <td>
                                    <strong style="color:var(--green);"><?= $h['distance_haram'] ?> m</strong>
                                    <span style="font-size:0.75rem; color:var(--gray-400); display:block;">to courtyard</span>
                                </td>
                                <td>
                                    <div style="display:flex; gap:8px;">
                                        <a href="<?= SITE_URL ?>/admin/hotels?action=edit&id=<?= $h['id'] ?>" class="btn-admin btn-sm btn-outline">Edit</a>
                                        <a href="<?= SITE_URL ?>/admin/hotels?action=delete&id=<?= $h['id'] ?>" class="btn-admin btn-sm btn-danger" onclick="return confirm('Delete this hotel?');">Delete</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Right: Add / Edit Hotel Form -->
        <div class="admin-card">
            <h3 class="admin-card-title"><?= $editHotel ? 'Edit Hotel' : 'Add New Hotel' ?></h3>
            <form method="POST" action="" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

                <div class="form-group">
                    <label class="form-label">Hotel Name <span class="required">*</span></label>
                    <input type="text" name="name" class="form-control" placeholder="e.g. Swissotel Al Maqam" value="<?= e($editHotel['name'] ?? '') ?>" required>
                </div>

                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
                    <div class="form-group">
                        <label class="form-label">City <span class="required">*</span></label>
                        <select name="city" class="form-control" required>
                            <option value="Makkah" <?= ($editHotel['city'] ?? '') === 'Makkah' ? 'selected' : '' ?>>Makkah</option>
                            <option value="Madinah" <?= ($editHotel['city'] ?? '') === 'Madinah' ? 'selected' : '' ?>>Madinah</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Star Rating</label>
                        <select name="stars" class="form-control">
                            <option value="5" <?= ($editHotel['stars'] ?? 3) == 5 ? 'selected' : '' ?>>5 Star Luxury (★★★★★)</option>
                            <option value="4" <?= ($editHotel['stars'] ?? 3) == 4 ? 'selected' : '' ?>>4 Star Deluxe (★★★★)</option>
                            <option value="3" <?= ($editHotel['stars'] ?? 3) == 3 ? 'selected' : '' ?>>3 Star Comfort (★★★)</option>
                            <option value="2" <?= ($editHotel['stars'] ?? 3) == 2 ? 'selected' : '' ?>>2 Star Standard (★★)</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Distance from Haram (in meters) <span class="required">*</span></label>
                    <input type="number" name="distance_haram" class="form-control" placeholder="e.g. 50" value="<?= e($editHotel['distance_haram'] ?? 50) ?>" required min="0">
                    <small style="color:var(--gray-400);">Approximate distance from hotel exit to Haram prayer area.</small>
                </div>

                <div class="form-group">
                    <label class="form-label">Amenities (Comma separated)</label>
                    <input type="text" name="amenities" class="form-control" placeholder="Free Wi-Fi, 24/7 Room Service, Buffet Dining, Elevator" value="<?= e($editHotel['amenities'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label class="form-label">Hotel Description</label>
                    <textarea name="description" class="form-control" rows="3" placeholder="Overview of hotel features and views..."><?= e($editHotel['description'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Hotel Image URL</label>
                    <input type="text" name="image" class="form-control" placeholder="https://..." value="<?= e($editHotel['image'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label class="form-label">Or Upload Image</label>
                    <input type="file" name="image_file" class="form-control" accept="image/*">
                </div>

                <button type="submit" class="btn-admin btn-primary" style="width:100%; justify-content:center; margin-top:10px;">
                    <?= $editHotel ? 'Update Hotel' : '+ Add Hotel' ?>
                </button>
            </form>
        </div>

    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

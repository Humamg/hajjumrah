<?php
$adminPageTitle = 'Edit Blog Post';
$postId = $_GET['id'] ?? null;
require __DIR__ . '/blog-form.php';

<?php
// ============================================================
// Shahin Travels – Admin Media Library
// ============================================================
$adminPageTitle = 'Media Library';
require_once __DIR__ . '/includes/header.php';

$db = getDB();
$action = $_GET['action'] ?? '';
$mediaId = (int)($_GET['id'] ?? 0);

// Delete Media
if ($action === 'delete' && $mediaId) {
    $stmt = $db->prepare("SELECT file_path FROM media WHERE id = ?");
    $stmt->execute([$mediaId]);
    $filePath = $stmt->fetchColumn();
    if ($filePath && file_exists(UPLOAD_DIR . $filePath)) {
        @unlink(UPLOAD_DIR . $filePath);
    }
    $db->prepare("DELETE FROM media WHERE id = ?")->execute([$mediaId]);
    setFlash('success', 'Media file removed.');
    redirect(SITE_URL . '/admin/media');
}

// Upload Media POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        setFlash('error', 'Security check failed. Please try again.');
    } else {
        $subfolder = in_array($_POST['folder'] ?? '', ['packages', 'hotels', 'blog', 'general']) ? $_POST['folder'] : 'general';
        $altText   = trim($_POST['alt_text'] ?? '');

        if (!empty($_FILES['file']['name'])) {
            $up = handleUpload($_FILES['file'], $subfolder);
            if ($up['success']) {
                $ins = $db->prepare("INSERT INTO media (filename, original_name, file_path, file_type, file_size, alt_text, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $ins->execute([
                    basename($up['filename']),
                    $_FILES['file']['name'],
                    $up['filename'],
                    $_FILES['file']['type'],
                    $_FILES['file']['size'],
                    $altText,
                    $_SESSION['admin_id'] ?? 1
                ]);
                setFlash('success', 'File uploaded successfully.');
                redirect(SITE_URL . '/admin/media');
            } else {
                setFlash('error', $up['error']);
            }
        } else {
            setFlash('error', 'Please select a file to upload.');
        }
    }
}

// Fetch all media
$mediaItems = $db->query("SELECT * FROM media ORDER BY id DESC")->fetchAll();
?>

<div class="admin-content-inner">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
        <div>
            <h2>Media Library (<?= count($mediaItems) ?>)</h2>
            <p style="color:var(--gray-500); font-size:0.9rem;">Upload and manage photos for packages, hotels near Haram, blogs, and banners.</p>
        </div>
    </div>

    <div style="display:grid; grid-template-columns: 2fr 1fr; gap:24px;">
        
        <!-- Media Grid -->
        <div class="admin-card">
            <h3 class="admin-card-title">Uploaded Media Files</h3>
            <?php if (empty($mediaItems)): ?>
            <div style="text-align:center; padding:40px; color:var(--gray-400);">
                No media uploaded to library yet. Use the upload panel to upload your first image.
            </div>
            <?php else: ?>
            <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap:16px;">
                <?php foreach ($mediaItems as $m): ?>
                <?php $fullUrl = SITE_URL . '/public/images/' . $m['file_path']; ?>
                <div style="background:var(--cream); border-radius:10px; overflow:hidden; border:1px solid var(--gray-200); display:flex; flex-direction:column;">
                    <div style="height:110px; overflow:hidden; position:relative;">
                        <img src="<?= e($fullUrl) ?>" alt="<?= e($m['alt_text'] ?? '') ?>" style="width:100%; height:100%; object-fit:cover; display:block;">
                    </div>
                    <div style="padding:8px; font-size:0.75rem; flex:1; display:flex; flex-direction:column; justify-content:space-between;">
                        <div style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-weight:600; color:var(--gray-800);" title="<?= e($m['original_name']) ?>">
                            <?= e($m['original_name']) ?>
                        </div>
                        <div style="margin-top:6px; display:flex; justify-content:space-between; align-items:center;">
                            <button type="button" onclick="navigator.clipboard.writeText('<?= e($fullUrl) ?>'); alert('Image URL copied to clipboard!');" class="btn-admin btn-sm btn-outline" style="padding:2px 6px; font-size:0.7rem;">
                                Copy URL
                            </button>
                            <a href="<?= SITE_URL ?>/admin/media?action=delete&id=<?= $m['id'] ?>" onclick="return confirm('Delete image?');" style="color:red; font-size:0.85rem;" title="Delete">✕</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- Upload Form -->
        <div class="admin-card">
            <h3 class="admin-card-title">Upload New Media</h3>
            <form method="POST" action="" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

                <div class="form-group">
                    <label class="form-label">Select File <span class="required">*</span></label>
                    <input type="file" name="file" class="form-control" accept="image/jpeg,image/png,image/webp,image/gif" required>
                    <small style="color:var(--gray-400);">Max size: 5MB (JPG, PNG, WebP)</small>
                </div>

                <div class="form-group">
                    <label class="form-label">Target Category / Folder</label>
                    <select name="folder" class="form-control">
                        <option value="packages">Packages</option>
                        <option value="hotels">Hotels</option>
                        <option value="blog">Blog Articles</option>
                        <option value="general" selected>General / Website</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">SEO Alt Text Description</label>
                    <input type="text" name="alt_text" class="form-control" placeholder="e.g. Kaaba courtyard pilgrims in ihram">
                </div>

                <button type="submit" class="btn-admin btn-primary" style="width:100%; justify-content:center; margin-top:10px;">
                    📤 Upload Image
                </button>
            </form>
        </div>

    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

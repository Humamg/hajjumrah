<?php
// ============================================================
// Shahin Travels – Admin Users & Password Management
// ============================================================
$adminPageTitle = 'Admin Users';
require_once __DIR__ . '/includes/header.php';

$db = getDB();
$action = $_GET['action'] ?? '';
$userId = (int)($_GET['id'] ?? 0);

// Delete User
if ($action === 'delete' && $userId) {
    if ($userId === (int)($_SESSION['admin_id'] ?? 0)) {
        setFlash('error', 'You cannot delete your own admin account while logged in.');
    } else {
        $db->prepare("DELETE FROM admin_users WHERE id = ?")->execute([$userId]);
        setFlash('success', 'Admin user removed.');
    }
    redirect(SITE_URL . '/admin/users');
}

// Toggle status
if ($action === 'toggle' && $userId) {
    if ($userId === (int)($_SESSION['admin_id'] ?? 0)) {
        setFlash('error', 'You cannot deactivate your own account.');
    } else {
        $db->prepare("UPDATE admin_users SET is_active = NOT is_active WHERE id = ?")->execute([$userId]);
        setFlash('success', 'User status updated.');
    }
    redirect(SITE_URL . '/admin/users');
}

// Handle Form Submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        setFlash('error', 'Security check failed. Please try again.');
    } else {
        $formType = $_POST['form_type'] ?? '';

        // Add new user
        if ($formType === 'add_user') {
            $name     = trim($_POST['name'] ?? '');
            $email    = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';

            if ($name && $email && $password) {
                $check = $db->prepare("SELECT id FROM admin_users WHERE email = ?");
                $check->execute([$email]);
                if ($check->fetch()) {
                    setFlash('error', 'An admin with this email already exists.');
                } else {
                    $hash = password_hash($password, PASSWORD_BCRYPT);
                    $ins = $db->prepare("INSERT INTO admin_users (name, email, password, is_active) VALUES (?, ?, ?, 1)");
                    $ins->execute([$name, $email, $hash]);
                    setFlash('success', 'New admin user added.');
                    redirect(SITE_URL . '/admin/users');
                }
            } else {
                setFlash('error', 'Please fill in all user fields.');
            }
        }

        // Change Password for current logged in user
        if ($formType === 'change_password') {
            $currentPass = $_POST['current_password'] ?? '';
            $newPass     = $_POST['new_password'] ?? '';
            $confirmPass = $_POST['confirm_password'] ?? '';

            if ($newPass !== $confirmPass) {
                setFlash('error', 'New passwords do not match.');
            } elseif (strlen($newPass) < 6) {
                setFlash('error', 'New password must be at least 6 characters.');
            } else {
                $uStmt = $db->prepare("SELECT password FROM admin_users WHERE id = ?");
                $uStmt->execute([(int)$_SESSION['admin_id']]);
                $existingHash = $uStmt->fetchColumn();

                if ($existingHash && password_verify($currentPass, $existingHash)) {
                    $newHash = password_hash($newPass, PASSWORD_BCRYPT);
                    $db->prepare("UPDATE admin_users SET password = ? WHERE id = ?")->execute([$newHash, (int)$_SESSION['admin_id']]);
                    setFlash('success', 'Your password has been changed successfully.');
                    redirect(SITE_URL . '/admin/users');
                } else {
                    setFlash('error', 'Current password is incorrect.');
                }
            }
        }
    }
}

$users = $db->query("SELECT * FROM admin_users ORDER BY id ASC")->fetchAll();
?>

<div class="admin-content-inner">
    <div style="margin-bottom:24px;">
        <h2>Admin Team & Security</h2>
        <p style="color:var(--gray-500); font-size:0.9rem;">Manage team member access and update administrative passwords.</p>
    </div>

    <div style="display:grid; grid-template-columns: 2fr 1fr; gap:24px;">
        
        <!-- Left: Users List -->
        <div class="admin-card">
            <h3 class="admin-card-title">Admin Team Members (<?= count($users) ?>)</h3>
            <div style="overflow-x:auto;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>User Name</th>
                            <th>Email Address</th>
                            <th>Last Login</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $u): ?>
                        <tr>
                            <td>
                                <strong><?= e($u['name']) ?></strong>
                                <?php if ($u['id'] == ($_SESSION['admin_id'] ?? 0)): ?>
                                <span class="badge" style="background:var(--gold-light); color:var(--gold-dark); font-size:0.7rem; margin-left:6px;">You</span>
                                <?php endif; ?>
                            </td>
                            <td><?= e($u['email']) ?></td>
                            <td style="font-size:0.8rem; color:var(--gray-500);">
                                <?= $u['last_login'] ? date('d M Y, h:i A', strtotime($u['last_login'])) : 'Never' ?>
                            </td>
                            <td>
                                <?php if ($u['id'] != ($_SESSION['admin_id'] ?? 0)): ?>
                                <a href="<?= SITE_URL ?>/admin/users?action=toggle&id=<?= $u['id'] ?>" class="badge badge-<?= $u['is_active'] ? 'published' : 'draft' ?>">
                                    <?= $u['is_active'] ? 'Active' : 'Inactive' ?>
                                </a>
                                <?php else: ?>
                                <span class="badge badge-published">Active</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($u['id'] != ($_SESSION['admin_id'] ?? 0)): ?>
                                <a href="<?= SITE_URL ?>/admin/users?action=delete&id=<?= $u['id'] ?>" class="btn-admin btn-sm btn-danger" onclick="return confirm('Remove admin user account?');">Delete</a>
                                <?php else: ?>
                                <span style="font-size:0.8rem; color:var(--gray-400);">Current</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Right: Forms -->
        <div style="display:flex; flex-direction:column; gap:24px;">
            
            <!-- Change Password Card -->
            <div class="admin-card">
                <h3 class="admin-card-title">🔐 Change Your Password</h3>
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <input type="hidden" name="form_type" value="change_password">

                    <div class="form-group">
                        <label class="form-label">Current Password <span class="required">*</span></label>
                        <input type="password" name="current_password" class="form-control" placeholder="••••••••" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">New Password <span class="required">*</span></label>
                        <input type="password" name="new_password" class="form-control" placeholder="••••••••" minlength="6" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Confirm New Password <span class="required">*</span></label>
                        <input type="password" name="confirm_password" class="form-control" placeholder="••••••••" minlength="6" required>
                    </div>

                    <button type="submit" class="btn-admin btn-primary" style="width:100%; justify-content:center; margin-top:10px;">
                        Update Password
                    </button>
                </form>
            </div>

            <!-- Add Admin User Card -->
            <div class="admin-card">
                <h3 class="admin-card-title">👤 Add New Admin User</h3>
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <input type="hidden" name="form_type" value="add_user">

                    <div class="form-group">
                        <label class="form-label">Full Name <span class="required">*</span></label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Tariq Shahin" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Email Address <span class="required">*</span></label>
                        <input type="email" name="email" class="form-control" placeholder="tariq@shahintravels.in" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Initial Password <span class="required">*</span></label>
                        <input type="password" name="password" class="form-control" placeholder="••••••••" minlength="6" required>
                    </div>

                    <button type="submit" class="btn-admin btn-outline" style="width:100%; justify-content:center; margin-top:10px;">
                        + Create Admin User
                    </button>
                </form>
            </div>

        </div>

    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

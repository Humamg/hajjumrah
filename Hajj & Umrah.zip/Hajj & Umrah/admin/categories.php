<?php
// ============================================================
// Shahin Travels – Admin Categories Management
// ============================================================
$adminPageTitle = 'Package Categories';
require_once __DIR__ . '/includes/header.php';

$db = getDB();
$action = $_GET['action'] ?? '';
$catId  = (int)($_GET['id'] ?? 0);
$editCat = null;

// Delete Category
if ($action === 'delete' && $catId) {
    // Unlink packages first (set category_id = null)
    $db->prepare("UPDATE packages SET category_id = NULL WHERE category_id = ?")->execute([$catId]);
    $db->prepare("DELETE FROM categories WHERE id = ?")->execute([$catId]);
    setFlash('success', 'Category deleted successfully.');
    redirect(SITE_URL . '/admin/categories');
}

// Edit Category pre-load
if ($action === 'edit' && $catId) {
    $stmt = $db->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->execute([$catId]);
    $editCat = $stmt->fetch();
}

// Handle Add / Update POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        setFlash('error', 'Security check failed. Please try again.');
    } else {
        $name     = trim($_POST['name'] ?? '');
        $slug     = slugify(!empty($_POST['slug']) ? $_POST['slug'] : $name);
        $desc     = trim($_POST['description'] ?? '');
        $sort     = (int)($_POST['sort_order'] ?? 0);
        $seoTitle = trim($_POST['seo_title'] ?? '');
        $seoDesc  = trim($_POST['seo_description'] ?? '');
        $noindex  = !empty($_POST['noindex']) ? 1 : 0;
        $image    = trim($_POST['image'] ?? '');

        if (!empty($_FILES['image_file']['name'])) {
            $up = handleUpload($_FILES['image_file'], 'categories');
            if ($up['success']) {
                $image = $up['filename'];
            }
        }

        if ($name) {
            if ($catId && $editCat) {
                $sql = "UPDATE categories SET name=?, slug=?, description=?, image=?, seo_title=?, seo_description=?, noindex=?, sort_order=? WHERE id=?";
                $db->prepare($sql)->execute([$name, $slug, $desc, $image, $seoTitle, $seoDesc, $noindex, $sort, $catId]);
                setFlash('success', 'Category updated successfully.');
            } else {
                $check = $db->prepare("SELECT id FROM categories WHERE slug = ?");
                $check->execute([$slug]);
                if ($check->fetch()) $slug .= '-' . time();

                $sql = "INSERT INTO categories (name, slug, description, image, seo_title, seo_description, noindex, sort_order) VALUES (?,?,?,?,?,?,?,?)";
                $db->prepare($sql)->execute([$name, $slug, $desc, $image, $seoTitle, $seoDesc, $noindex, $sort]);
                setFlash('success', 'New category added.');
            }
            redirect(SITE_URL . '/admin/categories');
        } else {
            setFlash('error', 'Category name is required.');
        }
    }
}

// Fetch categories with package count
$categories = $db->query("
    SELECT c.*, COUNT(p.id) AS package_count
    FROM categories c
    LEFT JOIN packages p ON p.category_id = c.id
    GROUP BY c.id
    ORDER BY c.sort_order ASC, c.name ASC
")->fetchAll();
?>

<div class="admin-content-inner">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
        <div>
            <h2>Package Categories</h2>
            <p style="color:var(--gray-500); font-size:0.9rem;">Organize packages into Budget, Bronze, Silver, Gold, Ramadan, and custom tiers.</p>
        </div>
        <?php if ($editCat): ?>
        <a href="<?= SITE_URL ?>/admin/categories" class="btn-admin btn-outline">+ Add New Category</a>
        <?php endif; ?>
    </div>

    <div style="display:grid; grid-template-columns: 2fr 1fr; gap:24px;">
        
        <!-- Left: Categories List -->
        <div class="admin-card">
            <h3 class="admin-card-title">Existing Categories (<?= count($categories) ?>)</h3>
            <div style="overflow-x:auto;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Order</th>
                            <th>Category</th>
                            <th>Slug</th>
                            <th>Packages</th>
                            <th>SEO Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($categories)): ?>
                        <tr><td colspan="6" style="text-align:center; padding:30px; color:var(--gray-400);">No categories found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($categories as $c): ?>
                            <tr>
                                <td><span class="badge" style="background:var(--cream); color:var(--gray-700);"><?= $c['sort_order'] ?></span></td>
                                <td>
                                    <strong><?= e($c['name']) ?></strong>
                                    <?php if ($c['description']): ?>
                                    <div style="font-size:0.8rem; color:var(--gray-500); max-width:260px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                                        <?= e($c['description']) ?>
                                    </div>
                                    <?php endif; ?>
                                </td>
                                <td><code><?= e($c['slug']) ?></code></td>
                                <td>
                                    <span class="badge" style="background:var(--green-light); color:var(--green-dark); font-weight:600;">
                                        <?= $c['package_count'] ?> packages
                                    </span>
                                </td>
                                <td>
                                    <?= $c['noindex'] ? '<span style="color:red; font-size:0.8rem;">Noindex</span>' : '<span style="color:green; font-size:0.8rem;">Indexed</span>' ?>
                                </td>
                                <td>
                                    <div style="display:flex; gap:8px;">
                                        <a href="<?= SITE_URL ?>/admin/categories?action=edit&id=<?= $c['id'] ?>" class="btn-admin btn-sm btn-outline">Edit</a>
                                        <a href="<?= SITE_URL ?>/admin/categories?action=delete&id=<?= $c['id'] ?>" class="btn-admin btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this category? Packages in this category will become unassigned.');">Delete</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Right: Add / Edit Form -->
        <div class="admin-card">
            <h3 class="admin-card-title"><?= $editCat ? 'Edit Category' : 'Add New Category' ?></h3>
            <form method="POST" action="" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

                <div class="form-group">
                    <label class="form-label">Category Name <span class="required">*</span></label>
                    <input type="text" name="name" class="form-control" placeholder="e.g. Gold" value="<?= e($editCat['name'] ?? '') ?>" required>
                </div>

                <div class="form-group">
                    <label class="form-label">URL Slug</label>
                    <input type="text" name="slug" class="form-control" placeholder="gold" value="<?= e($editCat['slug'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label class="form-label">Display Sort Order</label>
                    <input type="number" name="sort_order" class="form-control" value="<?= e($editCat['sort_order'] ?? 0) ?>">
                </div>

                <div class="form-group">
                    <label class="form-label">Description / SEO Intro</label>
                    <textarea name="description" class="form-control" rows="3" placeholder="Category highlights shown on category landing page..."><?= e($editCat['description'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Meta SEO Title</label>
                    <input type="text" name="seo_title" class="form-control" placeholder="Gold Umrah Packages – Shahin Travels" value="<?= e($editCat['seo_title'] ?? '') ?>">
                </div>

                <div class="form-group">
                    <label class="form-label">Meta Description</label>
                    <textarea name="seo_description" class="form-control" rows="2" placeholder="Explore top Gold Umrah packages with 5-star hotels..."><?= e($editCat['seo_description'] ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
                        <input type="checkbox" name="noindex" value="1" <?= !empty($editCat['noindex']) ? 'checked' : '' ?>>
                        <span style="font-size:0.9rem;">Exclude from Sitemap / Google (noindex)</span>
                    </label>
                </div>

                <button type="submit" class="btn-admin btn-primary" style="width:100%; justify-content:center; margin-top:10px;">
                    <?= $editCat ? 'Update Category' : '+ Create Category' ?>
                </button>
            </form>
        </div>

    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

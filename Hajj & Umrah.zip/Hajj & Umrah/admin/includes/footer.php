        </div><!-- .admin-content -->
    </div><!-- .admin-main -->
</div><!-- .admin-layout -->

<script>
// Sidebar toggle (mobile)
const sidebarToggle = document.getElementById('sidebar-toggle');
const adminSidebar  = document.getElementById('admin-sidebar');
if (sidebarToggle && adminSidebar) {
    sidebarToggle.addEventListener('click', () => {
        adminSidebar.classList.toggle('open');
    });
    // Close on outside click
    document.addEventListener('click', (e) => {
        if (!adminSidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
            adminSidebar.classList.remove('open');
        }
    });
}

// Image preview
function previewImage(input, previewId) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const el = document.getElementById(previewId);
            if (el) { el.src = e.target.result; el.parentElement.style.display = 'block'; }
        };
        reader.readAsDataURL(input.files[0]);
    }
}

// Confirm delete
function confirmDelete(msg) {
    return confirm(msg || 'Delete this? This cannot be undone.');
}

// Auto-slug
function makeSlug(text) {
    return text.toLowerCase().trim().replace(/[^a-z0-9\-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
}
const titleInput = document.getElementById('pkg-title') || document.getElementById('post-title');
const slugInput  = document.getElementById('pkg-slug')  || document.getElementById('post-slug');
if (titleInput && slugInput) {
    titleInput.addEventListener('input', () => {
        if (!slugInput.dataset.edited) {
            slugInput.value = makeSlug(titleInput.value);
        }
    });
    slugInput.addEventListener('input', () => { slugInput.dataset.edited = '1'; });
}
</script>
</body>
</html>

<?php
// Admin auth guard
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/config.php';

if (empty($_SESSION['admin_id'])) {
    redirect(SITE_URL . '/admin/login');
}

$adminName  = $_SESSION['admin_name'] ?? 'Admin';
$adminEmail = $_SESSION['admin_email'] ?? '';
$currentPath= parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

function adminNav(string $href, string $label, string $icon, string $current): string {
    $active = (strpos($current, $href) !== false) ? ' active' : '';
    return '<a href="' . SITE_URL . '/' . $href . '" class="sidebar-link' . $active . '">' . $icon . ' ' . e($label) . '</a>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($adminPageTitle ?? 'Dashboard') ?> – Shahin Travels Admin</title>
    <meta name="robots" content="noindex,nofollow">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="<?= SITE_URL ?>/admin/css/admin.css">
    <?php if (!empty($adminStyles)): ?><style><?= $adminStyles ?></style><?php endif; ?>
</head>
<body>
<div class="admin-layout">
    <!-- Sidebar -->
    <aside class="admin-sidebar" id="admin-sidebar">
        <div class="sidebar-logo">
            <div class="brand">
                <div class="brand-icon">🕌</div>
                <div>
                    <div class="brand-name">Shahin Travels</div>
                    <div class="brand-sub">Admin Panel</div>
                </div>
            </div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-section-label">Main</div>
            <a href="<?= SITE_URL ?>/admin/dashboard" class="sidebar-link <?= strpos($currentPath,'dashboard') !== false ? 'active' : '' ?>">📊 Dashboard</a>

            <div class="nav-section-label">Content</div>
            <a href="<?= SITE_URL ?>/admin/packages" class="sidebar-link <?= strpos($currentPath,'packages') !== false ? 'active' : '' ?>">📦 Packages</a>
            <a href="<?= SITE_URL ?>/admin/categories" class="sidebar-link <?= strpos($currentPath,'categories') !== false ? 'active' : '' ?>">🏷️ Categories</a>
            <a href="<?= SITE_URL ?>/admin/hotels" class="sidebar-link <?= strpos($currentPath,'hotels') !== false ? 'active' : '' ?>">🏨 Hotels</a>
            <a href="<?= SITE_URL ?>/admin/blog" class="sidebar-link <?= strpos($currentPath,'blog') !== false ? 'active' : '' ?>">📝 Blog</a>
            <a href="<?= SITE_URL ?>/admin/testimonials" class="sidebar-link <?= strpos($currentPath,'testimonials') !== false ? 'active' : '' ?>">⭐ Testimonials</a>

            <div class="nav-section-label">Manage</div>
            <a href="<?= SITE_URL ?>/admin/enquiries" class="sidebar-link <?= strpos($currentPath,'enquiries') !== false ? 'active' : '' ?>">
                📨 Enquiries
                <?php
                try {
                    $db = getDB();
                    $newCount = $db->query("SELECT COUNT(*) FROM enquiries WHERE status = 'new'")->fetchColumn();
                    if ($newCount > 0) echo '<span class="badge-count">' . $newCount . '</span>';
                } catch (Exception $e) {}
                ?>
            </a>
            <a href="<?= SITE_URL ?>/admin/pages" class="sidebar-link <?= strpos($currentPath,'pages') !== false ? 'active' : '' ?>">📄 Pages</a>
            <a href="<?= SITE_URL ?>/admin/media" class="sidebar-link <?= strpos($currentPath,'media') !== false ? 'active' : '' ?>">🖼️ Media</a>

            <div class="nav-section-label">SEO & Config</div>
            <a href="<?= SITE_URL ?>/admin/seo" class="sidebar-link <?= strpos($currentPath,'seo') !== false ? 'active' : '' ?>">🔍 SEO</a>
            <a href="<?= SITE_URL ?>/admin/redirects" class="sidebar-link <?= strpos($currentPath,'redirects') !== false ? 'active' : '' ?>">🔀 Redirects</a>
            <a href="<?= SITE_URL ?>/admin/settings" class="sidebar-link <?= strpos($currentPath,'settings') !== false ? 'active' : '' ?>">⚙️ Settings</a>
            <a href="<?= SITE_URL ?>/admin/users" class="sidebar-link <?= strpos($currentPath,'users') !== false ? 'active' : '' ?>">👤 Users</a>
        </nav>
        <div class="sidebar-footer">
            <div class="sidebar-user">
                <div class="sidebar-avatar"><?= strtoupper(substr($adminName, 0, 1)) ?></div>
                <div class="sidebar-user-info">
                    <span class="name"><?= e($adminName) ?></span>
                    <span class="role">Administrator</span>
                </div>
            </div>
            <a href="<?= SITE_URL ?>/admin/logout" class="sidebar-logout">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                Logout
            </a>
        </div>
    </aside>

    <!-- Main Area -->
    <div class="admin-main">
        <!-- Topbar -->
        <div class="admin-topbar">
            <div class="topbar-left">
                <button class="sidebar-toggle" id="sidebar-toggle" aria-label="Toggle sidebar">☰</button>
                <h1 class="topbar-title"><?= e($adminPageTitle ?? 'Dashboard') ?></h1>
            </div>
            <div class="topbar-right">
                <a href="<?= SITE_URL ?>/" class="topbar-site-link" target="_blank" rel="noopener">
                    🌐 View Site
                </a>
                <a href="<?= SITE_URL ?>/admin/packages/add" class="btn-admin btn-primary btn-sm">+ Add Package</a>
            </div>
        </div>
        <!-- Flash messages -->
        <?php $flash = getFlash(); if ($flash): ?>
        <div style="padding:0 28px;padding-top:16px;">
            <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'error' ?>">
                <?= $flash['type'] === 'success' ? '✓' : '⚠' ?> <?= e($flash['msg']) ?>
            </div>
        </div>
        <?php endif; ?>
        <!-- Content -->
        <div class="admin-content">

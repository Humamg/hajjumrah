<?php
// Admin Logout
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

unset($_SESSION['admin_id'], $_SESSION['admin_name'], $_SESSION['admin_email']);
session_destroy();

redirect(SITE_URL . '/admin/login');

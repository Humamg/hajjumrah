<?php
// Admin Router / Index
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

if (!empty($_SESSION['admin_id'])) {
    redirect(SITE_URL . '/admin/dashboard');
} else {
    redirect(SITE_URL . '/admin/login');
}

<?php
// Admin Login Page
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

// Already logged in?
if (!empty($_SESSION['admin_id'])) {
    redirect(SITE_URL . '/admin/dashboard');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        $error = 'Security token invalid. Please try again.';
    } elseif (!empty($_POST['website'])) {
        // Honeypot triggered
        $error = 'Security check failed.';
    } else {
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($email && $password) {
            $db   = getDB();
            $stmt = $db->prepare("SELECT * FROM admin_users WHERE email = ? AND is_active = 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['admin_id']   = $user['id'];
                $_SESSION['admin_name'] = $user['name'];
                $_SESSION['admin_email']= $user['email'];
                $db->prepare("UPDATE admin_users SET last_login = NOW() WHERE id = ?")->execute([$user['id']]);
                redirect(SITE_URL . '/admin/dashboard');
            } else {
                $error = 'Invalid email or password. Please try again.';
            }
        } else {
            $error = 'Please enter your email and password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login – Shahin Travels</title>
    <meta name="robots" content="noindex,nofollow">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="<?= SITE_URL ?>/admin/css/admin.css">
    <style>
        body { display:flex; align-items:center; justify-content:center; min-height:100vh; background:linear-gradient(135deg,#122f22 0%,#1a4731 100%); padding:20px; }
        .login-card { background:var(--white); border-radius:16px; padding:40px; width:100%; max-width:420px; box-shadow:0 20px 60px rgba(0,0,0,0.3); }
        .login-logo { text-align:center; margin-bottom:28px; }
        .login-logo .icon { font-size:2.5rem; display:block; margin-bottom:10px; }
        .login-logo h1 { font-size:1.4rem; color:var(--green-dark); font-weight:700; }
        .login-logo p { font-size:.8rem; color:var(--gray-400); }
        .login-card h2 { font-size:1.1rem; color:var(--gray-800); margin-bottom:20px; }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="login-logo">
            <span class="icon">🕌</span>
            <h1>Shahin Travels</h1>
            <p>Admin Panel</p>
        </div>
        <h2>Sign In to Dashboard</h2>
        <?php if ($error): ?>
        <div class="alert alert-error">⚠ <?= e($error) ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <!-- Honeypot -->
            <input type="text" name="website" style="display:none;" tabindex="-1" autocomplete="off">
            <div class="form-group">
                <label class="form-label">Email Address <span class="required">*</span></label>
                <input type="email" name="email" class="form-control" placeholder="admin@shahintravels.in"
                    value="<?= e($_POST['email'] ?? '') ?>" required autocomplete="email">
            </div>
            <div class="form-group">
                <label class="form-label">Password <span class="required">*</span></label>
                <input type="password" name="password" class="form-control" placeholder="••••••••" required autocomplete="current-password">
            </div>
            <button type="submit" class="btn-admin btn-primary" style="width:100%;justify-content:center;padding:14px;">
                Sign In →
            </button>
        </form>
        <p style="text-align:center;font-size:.8rem;color:var(--gray-400);margin-top:20px;">
            <a href="<?= SITE_URL ?>/" style="color:var(--green);">← Back to Website</a>
        </p>
    </div>
</body>
</html>

<?php
$adminPageTitle = 'Edit Package';
$packageId = $_GET['id'] ?? null;
require __DIR__ . '/packages-form.php';

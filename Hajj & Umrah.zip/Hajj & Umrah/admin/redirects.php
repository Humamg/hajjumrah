<?php
// ============================================================
// Shahin Travels – Admin 301 Redirects Manager
// ============================================================
$adminPageTitle = '301 Redirects Manager';
require_once __DIR__ . '/includes/header.php';

$db = getDB();
$action = $_GET['action'] ?? '';
$redId  = (int)($_GET['id'] ?? 0);

// Delete
if ($action === 'delete' && $redId) {
    $db->prepare("DELETE FROM redirects WHERE id = ?")->execute([$redId]);
    setFlash('success', 'Redirect deleted.');
    redirect(SITE_URL . '/admin/redirects');
}

// Toggle
if ($action === 'toggle' && $redId) {
    $db->prepare("UPDATE redirects SET is_active = NOT is_active WHERE id = ?")->execute([$redId]);
    setFlash('success', 'Redirect status updated.');
    redirect(SITE_URL . '/admin/redirects');
}

// Add Redirect POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        setFlash('error', 'Security check failed. Please try again.');
    } else {
        $fromUrl = trim($_POST['from_url'] ?? '');
        $toUrl   = trim($_POST['to_url'] ?? '');

        if ($fromUrl && $toUrl) {
            // Ensure leading slash if relative
            if (strpos($fromUrl, 'http') !== 0 && strpos($fromUrl, '/') !== 0) {
                $fromUrl = '/' . $fromUrl;
            }
            if (strpos($toUrl, 'http') !== 0 && strpos($toUrl, '/') !== 0) {
                $toUrl = '/' . $toUrl;
            }

            $stmt = $db->prepare("INSERT INTO redirects (from_url, to_url, is_active) VALUES (?, ?, 1)");
            $stmt->execute([$fromUrl, $toUrl]);
            setFlash('success', '301 Permanent Redirect added.');
            redirect(SITE_URL . '/admin/redirects');
        } else {
            setFlash('error', 'Both source and target URLs are required.');
        }
    }
}

$redirects = $db->query("SELECT * FROM redirects ORDER BY id DESC")->fetchAll();
?>

<div class="admin-content-inner">
    <div style="margin-bottom:24px;">
        <h2>301 URL Redirects Manager</h2>
        <p style="color:var(--gray-500); font-size:0.9rem;">Safely preserve link equity and redirect outdated URLs to new canonical pages.</p>
    </div>

    <div style="display:grid; grid-template-columns: 2fr 1fr; gap:24px;">
        
        <!-- Table -->
        <div class="admin-card">
            <h3 class="admin-card-title">Existing 301 Redirects (<?= count($redirects) ?>)</h3>
            <div style="overflow-x:auto;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>From (Source URL)</th>
                            <th>To (Target Destination)</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($redirects)): ?>
                        <tr><td colspan="4" style="text-align:center; padding:30px; color:var(--gray-400);">No custom 301 redirects configured.</td></tr>
                        <?php else: ?>
                            <?php foreach ($redirects as $r): ?>
                            <tr>
                                <td><code><?= e($r['from_url']) ?></code></td>
                                <td>
                                    <strong><?= e($r['to_url']) ?></strong>
                                </td>
                                <td>
                                    <a href="<?= SITE_URL ?>/admin/redirects?action=toggle&id=<?= $r['id'] ?>" class="badge badge-<?= $r['is_active'] ? 'published' : 'draft' ?>">
                                        <?= $r['is_active'] ? 'Active (301)' : 'Disabled' ?>
                                    </a>
                                </td>
                                <td>
                                    <a href="<?= SITE_URL ?>/admin/redirects?action=delete&id=<?= $r['id'] ?>" class="btn-admin btn-sm btn-danger" onclick="return confirm('Delete this redirect?');">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Add Redirect Form -->
        <div class="admin-card">
            <h3 class="admin-card-title">Add 301 Redirect</h3>
            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

                <div class="form-group">
                    <label class="form-label">Old / From URL <span class="required">*</span></label>
                    <input type="text" name="from_url" class="form-control" placeholder="/old-ramadan-package" required>
                    <small style="color:var(--gray-400);">Relative path (e.g. /old-page or /package-2025)</small>
                </div>

                <div class="form-group">
                    <label class="form-label">New / Destination URL <span class="required">*</span></label>
                    <input type="text" name="to_url" class="form-control" placeholder="/umrah-packages" required>
                    <small style="color:var(--gray-400);">Relative path or full https:// URL</small>
                </div>

                <button type="submit" class="btn-admin btn-primary" style="width:100%; justify-content:center; margin-top:10px;">
                    + Create 301 Redirect
                </button>
            </form>
        </div>

    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

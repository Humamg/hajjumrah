<?php
// Admin – Packages List
$adminPageTitle = 'Packages';
require_once __DIR__ . '/includes/header.php';

$db = getDB();
$action = $_GET['action'] ?? '';

// Delete
if ($action === 'delete' && !empty($_GET['id'])) {
    $db->prepare("DELETE FROM packages WHERE id=?")->execute([(int)$_GET['id']]);
    setFlash('success', 'Package deleted successfully.');
    redirect(SITE_URL . '/admin/packages');
}

// Toggle publish
if ($action === 'toggle' && !empty($_GET['id'])) {
    $pkg = $db->prepare("SELECT status FROM packages WHERE id=?");
    $pkg->execute([(int)$_GET['id']]);
    $pkg = $pkg->fetch();
    if ($pkg) {
        $newStatus = $pkg['status'] === 'published' ? 'draft' : 'published';
        $db->prepare("UPDATE packages SET status=? WHERE id=?")->execute([$newStatus, (int)$_GET['id']]);
        setFlash('success', 'Package status updated.');
    }
    redirect(SITE_URL . '/admin/packages');
}

// Toggle trending
if ($action === 'trending' && !empty($_GET['id'])) {
    $db->prepare("UPDATE packages SET is_trending = NOT is_trending WHERE id=?")->execute([(int)$_GET['id']]);
    redirect(SITE_URL . '/admin/packages');
}

// Duplicate
if ($action === 'duplicate' && !empty($_GET['id'])) {
    $orig = $db->prepare("SELECT * FROM packages WHERE id=?");
    $orig->execute([(int)$_GET['id']]);
    $orig = $orig->fetch();
    if ($orig) {
        $newSlug = $orig['slug'] . '-copy-' . time();
        $ins = $db->prepare("INSERT INTO packages (title,slug,category_id,departure_date,return_date,days,nights,departure_city,airline,makkah_hotel_id,makkah_nights,madinah_hotel_id,madinah_nights,short_description,overview,highlights,inclusions,exclusions,important_info,cover_image,status,flight_details) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'draft',?)");
        $ins->execute(['Copy of '.$orig['title'],$newSlug,$orig['category_id'],$orig['departure_date'],$orig['return_date'],$orig['days'],$orig['nights'],$orig['departure_city'],$orig['airline'],$orig['makkah_hotel_id'],$orig['makkah_nights'],$orig['madinah_hotel_id'],$orig['madinah_nights'],$orig['short_description'],$orig['overview'],$orig['highlights'],$orig['inclusions'],$orig['exclusions'],$orig['important_info'],$orig['cover_image'],$orig['flight_details']]);
        $newId = $db->lastInsertId();
        $prices = $db->prepare("SELECT * FROM package_prices WHERE package_id=?")->execute([$orig['id']]);
        $prices = $db->query("SELECT * FROM package_prices WHERE package_id={$orig['id']}")->fetchAll();
        foreach ($prices as $p) {
            $db->prepare("INSERT INTO package_prices (package_id,sharing_type,price) VALUES (?,?,?)")->execute([$newId,$p['sharing_type'],$p['price']]);
        }
        setFlash('success', 'Package duplicated.');
        redirect(SITE_URL . '/admin/packages/edit/' . $newId);
    }
}

// Search/filter
$search = $_GET['q'] ?? '';
$status = $_GET['status'] ?? '';
$catFilter = $_GET['cat'] ?? '';
$page   = max(1, (int)($_GET['page'] ?? 1));
$perPage= 15;

$where = ['1=1'];
$params = [];
if ($search) { $where[] = '(p.title LIKE ? OR p.slug LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; }
if ($status) { $where[] = 'p.status=?'; $params[] = $status; }
if ($catFilter) { $where[] = 'p.category_id=?'; $params[] = (int)$catFilter; }

$whereStr = implode(' AND ', $where);
$total = $db->prepare("SELECT COUNT(*) FROM packages p WHERE $whereStr");
$total->execute($params);
$total = (int)$total->fetchColumn();
$totalPages = ceil($total / $perPage);
$offset = ($page-1)*$perPage;

$stmt = $db->prepare("
    SELECT p.*, c.name AS cat_name FROM packages p
    LEFT JOIN categories c ON c.id=p.category_id
    WHERE $whereStr
    ORDER BY p.created_at DESC
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$packages = $stmt->fetchAll();

$cats = $db->query("SELECT id, name FROM categories ORDER BY name")->fetchAll();
?>

<div class="page-header">
    <div>
        <h2>Packages</h2>
        <p>Manage all Umrah packages – add, edit, publish or duplicate.</p>
    </div>
    <a href="<?= SITE_URL ?>/admin/packages/add" class="btn-admin btn-primary">+ Add Package</a>
</div>

<!-- Filters -->
<div class="card" style="margin-bottom:20px;padding:16px 24px;">
    <form method="GET" style="display:flex;gap:14px;align-items:center;flex-wrap:wrap;">
        <input type="text" name="q" value="<?= e($search) ?>" class="form-control" placeholder="Search packages..." style="max-width:240px;">
        <select name="status" class="form-control" style="width:auto;">
            <option value="">All Status</option>
            <option value="published" <?= $status==='published'?'selected':''?>>Published</option>
            <option value="draft"     <?= $status==='draft'?'selected':''?>>Draft</option>
        </select>
        <select name="cat" class="form-control" style="width:auto;">
            <option value="">All Categories</option>
            <?php foreach ($cats as $c): ?>
            <option value="<?= $c['id'] ?>" <?= $catFilter==$c['id']?'selected':''?>><?= e($c['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn-admin btn-primary btn-sm">Search</button>
        <a href="<?= SITE_URL ?>/admin/packages" class="btn-admin btn-outline btn-sm">Clear</a>
    </form>
</div>

<div class="card">
    <div class="card-header">
        <h3>All Packages <span style="font-weight:400;color:var(--gray-400);font-size:.9rem;">(<?= $total ?>)</span></h3>
    </div>
    <div class="data-table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Departure</th>
                    <th>Status</th>
                    <th>Trending</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($packages as $pkg): ?>
            <tr>
                <td>
                    <?php if ($pkg['cover_image']): ?>
                    <img src="<?= e(SITE_URL . '/public/images/packages/' . $pkg['cover_image']) ?>" class="thumb" alt="<?= e($pkg['title']) ?>">
                    <?php else: ?>
                    <div style="width:48px;height:36px;background:var(--green-bg);border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;">🕌</div>
                    <?php endif; ?>
                </td>
                <td>
                    <div style="font-weight:600;color:var(--gray-800);"><?= e($pkg['title']) ?></div>
                    <div style="font-size:.75rem;color:var(--gray-400);"><?= e($pkg['slug']) ?></div>
                </td>
                <td><?= e($pkg['cat_name'] ?? '—') ?></td>
                <td><?= date('d M Y', strtotime($pkg['departure_date'])) ?></td>
                <td>
                    <a href="<?= SITE_URL ?>/admin/packages?action=toggle&id=<?= $pkg['id'] ?>" title="Click to toggle">
                        <span class="status-badge <?= e($pkg['status']) ?>"><?= ucfirst($pkg['status']) ?></span>
                    </a>
                </td>
                <td>
                    <a href="<?= SITE_URL ?>/admin/packages?action=trending&id=<?= $pkg['id'] ?>" title="Toggle trending">
                        <span style="font-size:1.2rem;"><?= $pkg['is_trending'] ? '🔥' : '☆' ?></span>
                    </a>
                </td>
                <td>
                    <div class="actions">
                        <a href="<?= SITE_URL ?>/umrah-packages/<?= e($pkg['slug']) ?>" class="btn-icon" target="_blank" title="View">👁️</a>
                        <a href="<?= SITE_URL ?>/admin/packages/edit/<?= $pkg['id'] ?>" class="btn-icon" title="Edit">✏️</a>
                        <a href="<?= SITE_URL ?>/admin/packages?action=duplicate&id=<?= $pkg['id'] ?>" class="btn-icon" title="Duplicate">📋</a>
                        <a href="<?= SITE_URL ?>/admin/packages?action=delete&id=<?= $pkg['id'] ?>" class="btn-icon danger" title="Delete"
                           onclick="return confirmDelete('Delete this package? This cannot be undone.')">🗑️</a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($packages)): ?>
            <tr><td colspan="7" style="text-align:center;padding:40px;color:var(--gray-400);">No packages found. <a href="<?= SITE_URL ?>/admin/packages/add" style="color:var(--green);">Add your first package →</a></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
    <div style="display:flex;gap:8px;padding:16px;justify-content:flex-end;flex-wrap:wrap;">
        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
        <a href="?<?= http_build_query(array_merge($_GET, ['page'=>$p])) ?>" style="padding:6px 12px;border:1px solid var(--gray-200);border-radius:6px;font-size:.8rem;<?= $p===$page?'background:var(--green);color:#fff;border-color:var(--green);':'' ?>"><?= $p ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
